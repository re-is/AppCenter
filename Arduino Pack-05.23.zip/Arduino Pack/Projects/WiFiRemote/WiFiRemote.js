((w,d)=>{
	HTMLElement.prototype.resultAttribute=function(v){this.setAttribute('result',v)};
	w.S=(n)=>{return d.querySelector(n)};
	w.android||={xhrError:()=>{},lightLimits:(x,y)=>{}};
	w.pingTime=0;
	w.setResult=(()=>{
		let x=0,t=0;
		return function(z){
			if(x)return;
			let p=new Date().getTime(),u=z.split('-'),i=u[0],v=u[1];
			if(i==0)return;
			x=new XMLHttpRequest();
			x.open('GET','/'+i+(v?'/'+v:''),true);
			x.onload=()=>{
				w.pingTime=(new Date().getTime()-p);
				if(t)clearTimeout(t);
				new Function(x.responseText)();
				x=0
			};
			x.send();
			t=setTimeout(()=>{x.abort();x=0;android.xhrError();t=0},2000)
		}
	})();
	d.onclick=(e)=>{let r=e.target.getAttribute('result');if(r)w.setResult(r)}
})(window,document);



(()=>{android.lightLimits(" + String(min_lux) + "," + String(max_lux) + ")})();
