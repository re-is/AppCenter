#ifndef __IRFRemote_h__
#define __IRFRemote_h__ 1

class IRFRemote {

private:

	uint8_t _Remote_pin = 0;
	bool _Set_code = false;

	struct Get {
		uint32_t signal_mcrs = 0, end_mcrs = 0, code = 0;
		uint8_t signal = 0, bit_counter = 32, started_state = 2;
	};	Get _Get;

	struct Set {
		uint32_t signal_mcrs = 0, last_code = -1, pulse_mcrs = 0;
		uint8_t signal = 0, bit_counter = 32, send_counter = 0;
	};	Set _Set;

	struct Sfty {
		uint32_t end_mcrs = 0, long_mcrs = 0, last_mcrs = 0, last_code = 0, long_return_code = 0;
		uint8_t counter = 0, once = 0;
	};	Sfty _Sfty;


public:


	void init(uint8_t pin, uint8_t mode)
	{
		pinModeFast(pin, mode);
		_Set_code = (mode == OUTPUT);
		_Remote_pin = pin;
	}


	//-----------------------------------------------------------------------------------//


	IRFRemote(uint8_t pin = 0, uint8_t mode = 0)
	{
		if (pin > 0) init(pin, mode);
	}


	//-----------------------------------------------------------------------------------//


	void setCode(uint32_t mcrs, uint32_t &code, uint8_t limit = 1)
	{
		if (!_Set_code) return;

		// Változáskor reset:
		if (_Set.last_code != code)
		{
			fastWrite(_Remote_pin, 0);
			_Set.signal_mcrs	= 0;
			_Set.pulse_mcrs		= 500;
			_Set.bit_counter	= 32;
			_Set.send_counter	= 0;
			_Set.signal			= 0;
			_Set.last_code		= code;
		}

		// Továbbengedés, ha van kód:
		if (code == 0) return;

		// Ha a pulse nagyobb, mint a szélesség:
		if (uint32_t(mcrs - _Set.signal_mcrs) < _Set.pulse_mcrs) return;
		_Set.signal_mcrs = mcrs;

		if (_Set.signal)
		{
			// Az utolsó   pulse_mcrs:500  és  bit_counter:255 !
			if (_Set.bit_counter > 32)
			{
				// Ha a számláló elérte a limitet:
				if ((++_Set.send_counter) == limit)
				{
					code = 0;
					_Set.send_counter = 0;
				}
				// Vagy újrakezdés, mintha 32 lenne:
				else
				{
					_Set.pulse_mcrs = 10000;
					_Set.bit_counter = 31;
				}
			}
			else
			{
				// Kezdőérték:
				if (_Set.bit_counter == 32) _Set.pulse_mcrs = 10000;
				else
				{
					// Encoding:
					uint8_t bit = bitRead(_Set.last_code, _Set.bit_counter);
					_Set.pulse_mcrs = (bit ? 1400 : 400);
				}
				_Set.bit_counter--; // 255
			}

			_Set.signal = 0;
		}
		else
		{
			_Set.pulse_mcrs = 500;
			_Set.signal = 1;
		}

		fastWrite(_Remote_pin, _Set.signal);
	}


	//-----------------------------------------------------------------------------------//


	uint32_t getCode(uint32_t mcrs)
	{
		if (_Set_code) return 0;

		uint8_t state = fastRead(_Remote_pin);
		uint32_t return_code = 0, pulse_mcrs = (mcrs - _Get.signal_mcrs);

		// IR -------------------------------------------- IR
		if (state == 0)
		{
			if (!_Get.signal)
			{
				if (pulse_mcrs > 3000)
				{
					if (_Get.started_state == 2) _Get.started_state = 1;
					if (_Get.started_state == 1)
					{
						_Get.end_mcrs = mcrs;
						if (_Get.bit_counter <= 8) return_code = _Get.code;
					}
				}
				// Decoding:
				else if (_Get.started_state == 1)
				{
					// Reset on RF noise:
					if (pulse_mcrs < 200)
					{
						_Get.bit_counter	= 32;
						_Get.code			= 0;
					}
					else if (pulse_mcrs < 2000 and _Get.bit_counter > 0)
					{
						bitWrite(_Get.code, (--_Get.bit_counter), (pulse_mcrs > 1000));
					}
				}

				_Get.signal_mcrs = mcrs;
				_Get.signal = 1;
			}
		}
		// RF -------------------------------------------- RF
		else if (_Get.signal)
		{
				if (pulse_mcrs > 3000)
				{
					if (_Get.started_state == 2) _Get.started_state = 0;
					if (_Get.started_state == 0)
					{
						_Get.end_mcrs = mcrs;
						if (_Get.bit_counter <= 8) return_code = _Get.code;
						_Get.bit_counter	= 32;
						_Get.code			= 0;
					}
				}
				else if (_Get.started_state == 0)
				{
					// Reset on RF noise:
					if (pulse_mcrs < 200)
					{
						_Get.bit_counter	= 32;
						_Get.code			= 0;
						_Get.end_mcrs		= 0;
					}
					// Decoding:
					else if (pulse_mcrs < 2000 and _Get.bit_counter > 0)
					{
						bitWrite(_Get.code, (--_Get.bit_counter), (pulse_mcrs > 550));
					}
				}

				_Get.signal_mcrs = mcrs;
				_Get.signal = 0;
		}

		// Gomb felengedése után: (120ms)
		if (_Get.end_mcrs and uint32_t(mcrs - _Get.end_mcrs) > 120000)
		{
			if (_Get.bit_counter <= 8)
				return_code		= _Get.code;
			_Get.bit_counter	= 32;
			_Get.code			= 0;
			_Get.started_state	= 2;
			_Get.end_mcrs		= 0;
		}

		return return_code;
	}


	//-----------------------------------------------------------------------------------//


	uint32_t safetyCode(uint32_t mcrs, bool long_press = false, uint32_t code = 1)
	{
		// Ha nincs kód, akkor megadás:
		if (code == 1) code = getCode(mcrs);

		uint32_t return_code = 0, runtime_mcrs = (mcrs - _Sfty.last_mcrs);
		_Sfty.last_mcrs = mcrs;

		// Ha nincs semmi, akkor kilépés, hogy kevesebb legyen a futásidő:
		if (code == 0 and _Sfty.end_mcrs == 0) return 0;


		// Gomb nyomásakor:
		if (code)
		{
			_Sfty.end_mcrs += uint32_t(mcrs - _Sfty.end_mcrs);

			if (_Sfty.counter < 3)
			{
				if (_Sfty.last_code != code)
				{
					_Sfty.counter = 0;
					_Sfty.last_code = code;
				}
				if (_Sfty.counter == 2)
				{
					if (long_press)
					{
						if (!_Sfty.once)
						{
							_Sfty.long_mcrs += uint32_t(mcrs - _Sfty.long_mcrs);
							_Sfty.once = 1;
						}
						_Sfty.long_return_code = code;
					}
					else
					{
						_Sfty.long_mcrs = 0;
						return_code = code;
					}
				}
				_Sfty.counter++;
			}
			// Hosszúnál nullázni kell, hogy a legutóbbi kód érvényesüljön:
			if (_Sfty.counter == 3 and long_press) _Sfty.counter = 0;
		}


		// Futásidő hozzáadása:
		if (runtime_mcrs > 100)
		{
			if (_Sfty.end_mcrs) _Sfty.end_mcrs += uint32_t(mcrs - _Sfty.end_mcrs);
			if (_Sfty.long_mcrs) _Sfty.long_mcrs += uint32_t(mcrs - _Sfty.long_mcrs);
		}


		// Gomb felengedése után: (120ms)
		if (_Sfty.end_mcrs and uint32_t(mcrs - _Sfty.end_mcrs) > 120000)
		{
			_Sfty.once				= 0;
			_Sfty.counter			= 0;
			_Sfty.long_return_code	= 0;
			_Sfty.last_code			= 0;
			_Sfty.long_mcrs			= 0;
			_Sfty.end_mcrs			= 0;
		}
		// Gomb hosszú nyomása közben: (400ms)
		else if (_Sfty.long_mcrs and uint32_t(mcrs - _Sfty.long_mcrs) > 400000)
		{
			return_code				= _Sfty.long_return_code;
			_Sfty.long_return_code	= 0;
			_Sfty.long_mcrs			= 0;
		}

		return return_code;
	}

};

#endif
