class Fast {
private:

	uint8_t bit, port;
	volatile uint8_t *reg, *out;

public:

	void mode(uint8_t pin, uint8_t mode) {
		bit = digitalPinToBitMask(pin);
		port = digitalPinToPort(pin);

		if (port == 0) return;

		reg = portModeRegister(port);
		out = portOutputRegister(port);

		if (mode == INPUT) {
			*reg &= ~bit;
			*out &= ~bit;
		} else if (mode == INPUT_PULLUP) {
			*reg &= ~bit;
			*out |= bit;
		} else {
			*reg |= bit;
		}
	}

	void write(uint8_t state) {
		(state ? (*out |= bit) : (*out &= ~bit));
	}

	uint8_t read() {
		return (*out > bit);
	}
};
