((w,d)=>{
	w.S=function(n,r){let e=d.querySelector(n);if(e&&r)e.setAttribute('result',r);return e};
	w.android||={xhrError:()=>{},lightLimits:(x,y)=>{}};
	w.pingTime=0;
	w.setResult=(()=>{
		let x=0,t=0;
		return function(r){
			if(x)return'x';
			let p=new Date().getTime(),u=r.split('-'),i=u[0],v=u[1];
			if(i==0)return'x';
			x=new XMLHttpRequest();
			x.open('GET','/'+i+(v?'/'+v:''),true);
			x.onload=()=>{
				w.pingTime=(new Date().getTime()-p);
				if(t)clearTimeout(t);
				new Function(x.responseText)();
				x=0;
			};
			x.send();
			t=setTimeout(()=>{x.abort();x=0;android.xhrError();t=0},2000);
			return'';
		}
	})();
	d.onclick=(e)=>{let r=e.target.getAttribute('result');if(r)w.setResult(r)};
})(window,document);
