/*******************************
	WiFiRemote JS library
	2025.09.22, István Reich
*******************************/

((w, d)=> {

	//  R"html(   törlése a HTML fájlból:
	d.body?.firstChild.remove();

	w.websocket = new WebSocket(`ws://${w.location.hostname}/ws`);
	w.websocket.addEventListener('open', ()=> { w.websocket.send('first trigger') });
	w.websocket.addEventListener('message', (e)=> {
		const m = e.data;
		if (m.indexOf('js:') === 0) new Function(m.substring(3))();
	});

	w.S = (sel, res)=> {
		const e = d.querySelector(sel);
		if (e && res) e.setAttribute('result', res);
		return e;
	};

	w.android ||= {
		lightLimits: (x,y)=> {},
		orientation: ()=> {},
		rssiSwitch: (x)=> {}
	};

	w.addEventListener('click', (e)=> {
		const res = (e.target.getAttribute('result') || '');
		if (res === '') return;
		// Ha megszakadt a kapcsolat, reload:
		if (w.websocket.readyState !== 1) return w.location.reload(true);
		// Vagy küldés:
		w.websocket.send(`${e.target.id||'no-id'} ${res}`);
	});

})(window, document);
