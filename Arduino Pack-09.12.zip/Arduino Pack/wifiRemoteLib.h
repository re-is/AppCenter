#ifndef __WiFiRemote_h__
#define __WiFiRemote_h__ 1

#include <WiFi.h>

//-----------------------------------------------//

#define WFR_LIGHT_ID -10000
#define WFR_LIGHT_MIN 0
#define WFR_LIGHT_MAX 1
#define WFR_LIGHT_MID 2
#define WFR_ORIENTATION_ID -20000
#define WFR_PORTRAIT 1
#define WFR_LANDSCAPE 0

NetworkClient wifiremote_client;
NetworkServer wifiremote_server(80);
IPAddress wifiremote_server_ip(192, 168, 0, 100);
IPAddress wifiremote_subnet_ip(255, 255, 255, 0);
IPAddress wifiremote_reset_ip(0, 0, 0, 0);

//-----------------------------------------------//

class WiFiRemote {
private:

	uint32_t reconnect_ms = 0, result_ms = 0;
	uint16_t lux_limit_a = 0, lux_limit_b = 0;
	bool disconnected = true, station_mode = false, enable_orientation = false;
	const char *base_style, *base_body, *base_js;

public:

	long resultID = 0, resultValue = 0;

	// --- Access Point mode
	// Create Hotspot: 192.168.10.100
	void create(const char *ssid, const char *password) {
		WiFi.mode(WIFI_AP);
		wifiremote_server_ip[2] = 10;
		WiFi.softAPConfig(wifiremote_server_ip, wifiremote_server_ip, wifiremote_subnet_ip);
		WiFi.softAP(ssid, password);
		wifiremote_server.begin();
		Serial.print(F("WebServer IP: "));Serial.println(WiFi.softAPIP());
	}

	// --- Station mode
	// Connect to Hotspot: 192.168.dynamic.100
	void connect(const char *ssid, const char *password) {
		WiFi.mode(WIFI_STA);
		WiFi.begin(ssid, password);
		wifiremote_server.begin();
		station_mode = true;
	}

	//-----------------------------------------------//



	// HTML page content:
	void html(const char *html_style, const char *html_body) {
		base_style = html_style;
		base_body = html_body;
		base_js = "((w,d)=>{w.S=function(n,r){let e=d.querySelector(n);if(e&&r)e.setAttribute('resu"
				"lt',r);return e};w.android||={xhrError:()=>{},lightLimits:(x,y)=>{},orientation:"
				"()=>{}};w.pingTime=0;w.setResult=(()=>{let x=0,t=0;return function(r){if(x)retur"
				"n'x';let p=new Date().getTime(),u=r.split('_'),i=u[0],v=u[1];if(i==0)return'x';x"
				"=new XMLHttpRequest();x.open('GET','/'+i+(v?'/'+v:''),true);x.onload=()=>{w.ping"
				"Time=(new Date().getTime()-p);if(t)clearTimeout(t);new Function(x.responseText)("
				");x=0};x.send();t=setTimeout(()=>{x.abort();x=0;android.xhrError();t=0},2000);re"
				"turn''}})();d.onclick=(e)=>{let r=e.target.getAttribute('result');if(r)w.setResu"
				"lt(r)}})(window,document);";
	}



	// Sensors for MobileApp:
	void lightSensor(uint16_t limitA = 0, uint16_t limitB = 0) {
		if (limitA == 0) {
			lux_limit_a = 1;
			return;
		}
		lux_limit_a = limitA;
		lux_limit_b = limitB;
	}

	void orientationSensor() {
		enable_orientation = true;
	}



	// Switch by RSSI, STA mode only !
	// return: 0, 1, 2
	/*uint8_t switchByRSSI(int limit = -20) {
		if (!station_mode) return 0;
		static uint32_t last_ms = 0, counter = 0;
		static int avg_rssi = 0;
		static uint8_t state = 0, c_state = 0;
		uint32_t ms = millis();
		if (last_ms != ms) {
			avg_rssi += WiFi.RSSI();
			counter++;
			last_ms = ms;
		}
		if (counter < 200) return 0;
		int rssi = (avg_rssi / 200);
		avg_rssi = 0;
		counter = 0;
		if (rssi == 0 or (rssi / 1.5) < limit) c_state = 1;else if (rssi > limit) c_state = 2;
		if (state == c_state) return 0;
		state = c_state;
		return state;
	}*/


	bool rssi_switch = false;
	int rssi_limit = 0, rssi_avg = 0;
	uint8_t rssi_counter = 0;

	void rssiSwitch(int rssiLimit = 0) {
		rssi_switch = true;
		rssi_limit = rssiLimit;
	}



	// Result of XMLHttpRequest()
	bool getResult() {
		uint32_t ms = millis();
		// Save the Board !!!
		// Result only in 10 milliseconds:
		if (uint32_t(ms - result_ms) < 10) return false;
		result_ms = ms;
		// STA mode:
		if (station_mode) {													// 0 - 2000 mcrs

			if (rssi_switch) {
				rssi_avg += WiFi.RSSI();
				// 500ms:
				if (++rssi_counter == 50) {
					int rssi = (rssi_avg / rssi_counter);
					//Serial.println(rssi);
					//resultID = -200;
					//resultValue = rssi;
					rssi_avg = 0;
					rssi_counter = 0;
					//return true;
				}
			}





			// CONNECTION LOST:
			if (WiFi.status() != WL_CONNECTED) {							// 3 mcrs
				// Reset IP, if your phone has a dynamic hotspot:
				if (!disconnected) {
					WiFi.config(wifiremote_reset_ip, wifiremote_reset_ip, wifiremote_reset_ip);
					Serial.print(F("WebServer IP, reset: "));Serial.println(WiFi.localIP());
					disconnected = true;
				}
				// Reconnect by 5 seconds interval:
				if (uint32_t(ms - reconnect_ms) >= 5000) {
					if (WiFi.gatewayIP()[2] == 0) WiFi.reconnect();			// 400 mcrs
					reconnect_ms = ms;
				}
				return false;
			}
			else if (disconnected) {
				// After reconnect, set new IP:
				uint8_t w[3];
				for (uint8_t i = 0; i < 3; ++i) w[i] = WiFi.gatewayIP()[i];
				// Connected:
				if (w[2] > 0) {
					wifiremote_server_ip[0] = w[0];
					wifiremote_server_ip[1] = w[1];
					wifiremote_server_ip[2] = w[2];
					WiFi.config(wifiremote_server_ip);
					Serial.print(F("WebServer IP: "));Serial.println(WiFi.localIP());
					reconnect_ms = 0;
					disconnected = false;
				}
			}
		}
		// Saved client by current:											// 40 - 400 mcrs
		if (!wifiremote_client) wifiremote_client = wifiremote_server.accept();
		// Wait for available:												//  0 - 800 mcrs
		else if (wifiremote_client.connected() and wifiremote_client.available()) {
			uint32_t slash = 0;
			char chr = 0;
			bool neg_id = false, neg_value = false;
			while (chr = wifiremote_client.read()) {
				if (chr == '\n') break;
				else if (chr == '/') slash++;
				else if (slash > 0) {
					if (chr == ' ' or slash == 3) break;
					// ID:
					if (slash == 1) {
						if (chr == '-') neg_id = true;
						else {
							resultID *= 10;
							resultID += uint8_t(chr - '0');
						}
					}
					// VALUE:
					else if (slash == 2) {
						if (chr == '-') neg_value = true;
						else {
							resultValue *= 10;
							resultValue += uint8_t(chr - '0');
						}
					}
				}
			}
			// Negatives:
			if (neg_id) resultID *= -1;
			if (neg_value) resultValue *= -1;
			return true;
		}
		return false;
	}



	// Evaluate JavaScript or send HTML at first loading.
	// favicon is disabled.
	void evalJs(String data) {

		// Page build:
		if (resultID == 0) data =
			"<!DOCTYPE html>\n"
			"<html><head><title>WebServer</title>\n"
			"<link rel=\"icon\" href=\"data:image/png;base64,iVBORw0KGgo=\">\n"
			"<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">\n"
			"<meta name=\"viewport\" content=\"width=device-width,initial-scale=1,user-scalable=no\">\n"
			"<style>" + String(base_style) + "</style>\n"
			"<script>" + String(base_js) +
			(lux_limit_a ? "android.lightLimits(" + String(lux_limit_a) + "," + String(lux_limit_b) + ");" : "") +
			(enable_orientation ? "android.orientation();" : "") + "</script>\n"
			"</head><body>" + String(base_body) + "<script id=\"to-remove\">" + data + "S('#to-remove').remove();</script></body></html>\n";

		wifiremote_client.println("HTTP/1.1 200 OK\nConnection:close\nContent-type:text/html\n\n" + data);
		wifiremote_client.stop();
		wifiremote_client = 0;
		// Reset results:
		resultID = 0;
		resultValue = 0;
	}

};

#endif
