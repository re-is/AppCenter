#ifndef __WiFiRemote_h__

#include <WiFi.h>

//------------------------------------------------------------------------------------//

NetworkClient wifiremote_client;
NetworkServer wifiremote_server(80);
IPAddress wifiremote_local_ip(192, 168, 0, 100);
IPAddress wifiremote_subnet_ip(255, 255, 255, 0);
IPAddress wifiremote_reset_ip(0, 0, 0, 0);
const char *wifiremote_ssid, *wifiremote_password;
uint8_t wifiremote_mode;

void wifiremote_sta_event(WiFiEvent_t event) {
	if (event == ARDUINO_EVENT_WIFI_STA_DISCONNECTED) {
		if (wifiremote_local_ip[2] == 0) return;
		wifiremote_local_ip[2] = 0;
		WiFi.config(wifiremote_reset_ip, wifiremote_reset_ip, wifiremote_reset_ip);
		Serial.println(F("WebServer IP: 0.0.0.0"));
	}
	else if (event == ARDUINO_EVENT_WIFI_STA_GOT_IP) {
		if (wifiremote_local_ip[2] == WiFi.gatewayIP()[2]) return;
		wifiremote_local_ip[2] = WiFi.gatewayIP()[2];
		WiFi.config(wifiremote_local_ip);
		Serial.print(F("WebServer IP: "));Serial.println(WiFi.localIP());
	}
}




struct WiFiRemote {

	//--- SETUP
	//--- HOTSPOT handling -----------------------------------------------//

	void cssCompression(String &css) {
		css.replace("\t", "");
		css.replace("\n", "");
		css.replace("  ", " ");
		css.replace(" {", "{");
		css.replace("{ ", "{");
		css.replace(" }", "}");
		css.replace("} ", "}");
		css.replace(" (", "(");
		css.replace("( ", "(");
		css.replace(" )", ")");
		css.replace(") ", ")");
		css.replace(" :", ":");
		css.replace(": ", ":");
		css.replace(" ,", ",");
		css.replace(", ", ",");
		css.replace(" ;", ";");
		css.replace("; ", ";");
		css.replace(";}", "}");
	}

	//  192.168.10.100
	void create(const char *ssid, const char *password) {
		wifiremote_mode = 2;
		WiFi.mode(WIFI_AP);
		wifiremote_local_ip[2] = 10;
		WiFi.softAPConfig(wifiremote_local_ip, wifiremote_local_ip, wifiremote_subnet_ip);
		WiFi.softAP(ssid, password);
		wifiremote_server.begin();
		Serial.print(F("WebServer IP: "));Serial.println(WiFi.softAPIP());
	}

	//  192.168.dynamic.100
	void connect(const char *ssid, const char *password) {
		wifiremote_mode = 1;
		WiFi.mode(WIFI_STA);
		WiFi.begin(ssid, password);
		WiFi.onEvent(wifiremote_sta_event);
		wifiremote_ssid = ssid;
		wifiremote_password = password;
		wifiremote_server.begin();
	}





	//--- LOOP
	//--------------------------------------------------------------------//

	class WRClient {
	private:
		uint32_t reconnect_millis = 0, minLux = 0, maxLux = 0, savedLightValue = 0;
	public:




		bool result(uint32_t *res) {
			if (wifiremote_mode == 1 and WiFi.status() != WL_CONNECTED) {		// 3 mcrs
				uint32_t diff = (millis() - reconnect_millis);
				if (diff > 5000) {
					if (WiFi.gatewayIP()[2] == 0) WiFi.reconnect();				// 380 mcrs
					reconnect_millis += diff;
				}
				return false;
			}
			if (res[0]) res[0] = 0;
			if (res[1]) res[1] = 0;
			NetworkClient current_client = wifiremote_server.accept();			// 800 mcrs
			// Set saved client by current:
			if (current_client) wifiremote_client = current_client;
			// Wait for available:
			if (wifiremote_client and wifiremote_client.connected() and wifiremote_client.available()) {
				uint8_t slash = 0;												// 330 mcrs
				char chr = 0;
				while (chr = wifiremote_client.read()) {
					if (chr == '\n') break;
					else if (chr == '/') ++slash;
					else if (slash > 0) {
						if (chr == ' ' or slash == 3) break;
						res[slash-1] *= 10;
						res[slash-1] += int(chr - '0');
					}
				}
				return true;
			}
			return false;
		}




		void lightSensor(uint32_t *res, uint32_t min, uint32_t max = 0) {
			if (res[0] == 999998) savedLightValue = res[1];
			minLux = min;
			if (max) maxLux = (max < min ? min : max);
		}




		void create(String css, String body, uint8_t reloadSeconds = 0) {
			bool script = (reloadSeconds or minLux or maxLux);
			String html = "";													// 3000 mcrs +/- 500 !!

			html += "HTTP/1.1 200 OK\n";
			html += "Content-type:text/html\n\n";
			html += "<!DOCTYPE html>\n";
			html += "<html><head><title>WebServer</title>\n";
			html += "<link rel=\"icon\" href=\"data:image/png;base64,iVBORw0KGgo=\">\n";
			html += "<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">\n";
			html += "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1,user-scalable=no\">\n";
			html += "<style>html{user-select:none}body{margin:0px}" + css + "</style>";
			html += "</head><body>" + body;
			html += (script ? "<script>" : "</body></html>\n");
			if (reloadSeconds)	html += "setTimeout(function(){location.href='/999999'}," + String(reloadSeconds * 1000) + ");";
			if (maxLux)			html += "setInterval(function(){let v=window.lightSensorValue||0;if(v<" + String(minLux) + "){if(" + String(savedLightValue) + "!==0)location.href='/999998/0'}else if(v>=" + String(maxLux) + "){if(" + String(savedLightValue) + "!==2)location.href='/999998/2'}else if(" + String(savedLightValue) + "!==1)location.href='/999998/1'},300);";
			else if (minLux)	html += "setInterval(function(){let v=window.lightSensorValue||0;if(v<" + String(minLux) + "){if(" + String(savedLightValue) + "!==0)location.href='/999998/0'}else if(" + String(savedLightValue) + "!==1)location.href='/999998/1'},300);";
			if (script)			html += "</script></body></html>\n";

			wifiremote_client.println(html);
			wifiremote_client.stop();
		}


	}; // WRClient



	WRClient client;
};




#define __WiFiRemote_h__ 1
#endif
