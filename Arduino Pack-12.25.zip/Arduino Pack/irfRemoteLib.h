#ifndef __IRFRemote_h__

class IRFRemote {

private:

	uint8_t remote_pin = 0, default_state = 0;
	uint16_t starter_time = 0, separator_time = 0;
	bool set_code = false;

public:

	void init(uint8_t pin, uint8_t mode) {

		// pin init:
		if (remote_pin == 0) {
			pinModeFast(remote_pin, mode);
			set_code = (mode == OUTPUT);
			remote_pin = pin;
		}

		// Jelküldéskor kilépés:
		if (set_code) return;

		// Ez kell, ha a Vin a táp !
		delay(500);

		uint32_t mcrs = micros(), step = mcrs, first_mcrs = mcrs, last_mcrs = 0, pulse_counter = 0, state_summary = 0, state_counter = 0;
		bool signal = false;

		while (mcrs - first_mcrs < 500000) {
			mcrs = micros();

			// Csak 20 mikrononként:
			if (mcrs < step) continue;
			step = (mcrs + 20);

			uint8_t state = digitalReadFast(pin);

			if (state == 0) {
				if (signal) {
					last_mcrs = mcrs;
					signal = false;
				}
			}
			else if (!signal) {
				uint32_t pulse = (mcrs - last_mcrs);
				if (pulse < 200) ++pulse_counter;
				signal = true;
			}

			state_summary += state;
			++state_counter;
		}

		state_counter /= 2;	// -> ~ 10000
		default_state = ((pulse_counter > 100 or state_summary < state_counter) ? 0 : 1);
		separator_time = (default_state ? 1000 : 550);
		starter_time = (default_state ? 2000 : 3000);
		//Serial.println(String(pulse_counter) + " > 100 or " + String(state_summary) + " < " + String(state_counter) + ": " + String(default_state));
	}


	//-----------------------------------------------------------------------------------//


	IRFRemote(uint8_t pin = 0, uint8_t mode = 0) {
		if (pin > 0) init(pin, mode);
	}


	//-----------------------------------------------------------------------------------//


	void setCode(uint32_t mcrs, uint32_t &code, uint8_t limit = 1) {
		if (!set_code) return;

		static uint32_t last_code = 0, last_mcrs = 0;
		static uint16_t width = 0;
		static uint8_t bit_counter = 33, send_counter = 0;
		static bool signal = true;

		// Változáskor:
		if (last_code != code) {
			digitalWriteFast(remote_pin, 0);
			bit_counter = 33;
			send_counter = 0;
			last_code = code;
		}

		// Továbbengedés, ha van kód:
		if (code == 0) return;

		// Reset:
		if (bit_counter == 0) {
			last_mcrs = mcrs;
			digitalWriteFast(remote_pin, 1);
			width = 400;
			signal = true;
			++send_counter;
			bit_counter = 33;
		}

		if (send_counter > limit) {
			code = 0;
			send_counter = 0;
		}
		// Ha a pulse nagyobb, mint a szélesség:
		else if ((mcrs - last_mcrs) >= width) {

			if (signal) {
				last_mcrs = mcrs;
				digitalWriteFast(remote_pin, 0);
				if (bit_counter > 0) --bit_counter;
				// Kezdőérték:
				if (bit_counter == 32) {
					width = 10000;
				}
				// Encoding:
				else {
					uint8_t bit = bitRead(last_code, bit_counter);
					width = (bit ? 1000 : 400);
				}
				signal = false;
			}
			else {
				last_mcrs = mcrs;
				digitalWriteFast(remote_pin, 1);
				width = 400;
				signal = true;
			}
		}
	}


	//-----------------------------------------------------------------------------------//


	uint32_t getCode(uint32_t mcrs) {
		if (set_code) return 0;

		static bool signal = true, started = false;
		static uint32_t last_mcrs = 0, end_mcrs = 0, code = 0;
		static uint8_t bit_counter = 32;

		uint32_t rtrn = 0;

		if (digitalReadFast(remote_pin) == default_state) {
			if (signal) {
				last_mcrs = mcrs;
				signal = false;
			}
		}
		else if (!signal) {
			uint32_t width = (mcrs - last_mcrs);

			if (width > starter_time) {
				end_mcrs = mcrs;
				rtrn = code;
				bit_counter = 32;
				started = true;
			}
			// Decoding:
			else if (started and BETWEEN(width, 200, 2000) and bit_counter > 0) {
				if (bit_counter == 32) code = 0;
				bitWrite(code, (--bit_counter), (width > separator_time ? 1 : 0));
			}

			signal = true;
		}

		if (started and uint32_t(mcrs - end_mcrs) > 100000) {
			rtrn = code;
			code = 0;
			started = false;
		}

		return rtrn;
	}


	//-----------------------------------------------------------------------------------//


	bool findCode(uint32_t mcrs, uint32_t code, uint32_t found = 0, uint8_t limit = 3) {

		static uint32_t end_mcrs = 0, last_code = 0;
		static uint8_t counter = 0;

		if (code > 0) {
			if (found == code) {
				end_mcrs = mcrs;
				// Ha többször van használatban, több kódot is találhat !
				if (last_code != code) {
					counter = 0;
					last_code = code;
				}
				if (counter <= limit) ++counter;
				return (counter == limit);
			}
			else if (found == 0) {
				Serial.println(code);
				return false;
			}
		}
		else if (counter > 0 and uint32_t(mcrs - end_mcrs) > 200000) counter = 0;

		return false;
	}
};

#define __IRFRemote_h__ 1
#endif
