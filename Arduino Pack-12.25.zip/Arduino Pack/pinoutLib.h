#ifndef __PinoutLib_h__

#include "C:\Program Files\Apps\Arduino pack\digitaLib.h"

#define BETWEEN(x, y, z) (x > y and x < z)
#define FROMTO(x, y, z) (x >= y and x < z)
#define MINMAX(x, y, z) ((x < y) ? y : (x > z) ? z : x)
#define ever ;;

#define Nano_D2 2
#define Nano_D3 3
#define Nano_D4 4
#define Nano_D5 5
#define Nano_D6 6
#define Nano_D7 7
#define Nano_D8 8
#define Nano_D9 9
#define Nano_D10 10
#define Nano_D11 11
#define Nano_D12 12
#define Nano_A0 14
#define Nano_A1 15
#define Nano_A2 16
#define Nano_A3 17
#define Nano_A4 18
#define Nano_A5 19
#define Nano_A6 20
#define Nano_A7 21

void loop() {}

#define __PinoutLib_h__ 1
#endif
