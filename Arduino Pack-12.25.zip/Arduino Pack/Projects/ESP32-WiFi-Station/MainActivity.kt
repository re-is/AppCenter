package com.example.espwebserver

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import java.net.NetworkInterface

@Suppress("unused")
fun print(text: Any) { Log.i("#blu", text.toString()) }

class MainActivity : AppCompatActivity() {

    private fun espWebServerIP(): String {
        val list = NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }.toString()
        val arr = list.split(",")
        val ip = arr[arr.size-1].split("/")[1].split(".")
        return "${ip[0]}.${ip[1]}.${ip[2]}.100"
    }

    @SuppressLint("JavascriptInterface", "SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //---- WebView
        val wv: WebView = findViewById(R.id.webview)
        wv.apply {
            settings.javaScriptEnabled = true
            webViewClient = WebViewClient()
            addJavascriptInterface(this,"android")
            loadUrl("http://${espWebServerIP()}")
        }
    }

    @JavascriptInterface
    fun fgdgd() {

    }
}
