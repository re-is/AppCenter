#ifndef __WiFiRemote_h__

#include <WiFi.h>

// Global variables:
//------------------------------------------------------------------------------------//

WiFiClient wifiremote_client;
WiFiServer wifiremote_server(80);
IPAddress wifiremote_local_ip(192, 168, 0, 100);
IPAddress wifiremote_subnet_ip(255, 255, 255, 0);
const char *wifiremote_ssid, *wifiremote_password;

void wifiremote_event(WiFiEvent_t event) {
	if (event == ARDUINO_EVENT_WIFI_STA_DISCONNECTED) {
		if (wifiremote_local_ip[2] == 0) return;
		wifiremote_local_ip[2] = 0;
		Serial.println("Disconnected!");
		WiFi.disconnect(true, true);
		delay(500);
		WiFi.mode(WIFI_STA);
		WiFi.begin(wifiremote_ssid, wifiremote_password);
	}
	else if (event == ARDUINO_EVENT_WIFI_STA_GOT_IP) {
		if (wifiremote_local_ip[2] == WiFi.gatewayIP()[2]) return;
		wifiremote_local_ip[2] = WiFi.gatewayIP()[2];
		WiFi.config(wifiremote_local_ip);
		Serial.print("ESP STA WebServer IP: ");Serial.println(WiFi.localIP());
	}
}

class WiFiRemote {
private:
public:

	//--- SETUP
	//--- HOTSPOT handling -----------------------------------------------//

	void cssTextMinimize(String &css) {
		css.replace("\t", "");
		css.replace("\n", "");
		css.replace("  ", " ");
		css.replace(" {", "{");
		css.replace("{ ", "{");
		css.replace(" }", "}");
		css.replace("} ", "}");
		css.replace(" :", ":");
		css.replace(": ", ":");
		css.replace(" ;", ";");
		css.replace("; ", ";");
		css.replace(";}", "}");
	}

	void createHotspot(const char *ssid, const char *password) {
		WiFi.mode(WIFI_AP);
		wifiremote_local_ip[2] = 10;
		WiFi.softAPConfig(wifiremote_local_ip, wifiremote_local_ip, wifiremote_subnet_ip);
		WiFi.softAP(ssid, password);
		wifiremote_server.begin();
		Serial.print("ESP AP WebServer IP: ");Serial.println(WiFi.softAPIP());
	}

	void connectToHotspot(const char *ssid, const char *password) {
		WiFi.mode(WIFI_STA);
		WiFi.begin(ssid, password);
		wifiremote_ssid = ssid;
		wifiremote_password = password;
		wifiremote_server.begin();
		WiFi.onEvent(wifiremote_event);
	}

	//--- LOOP
	//--------------------------------------------------------------------//

	bool clientHTML_href(String *href) {
		if (href[0] != "") href[0] = "";
		if (href[1] != "") href[1] = "";
		bool ok = false;
		wifiremote_client = wifiremote_server.accept();
		if (wifiremote_client) {
			uint8_t i = 0;
			while (wifiremote_client.connected()) {
				// GET /name/123
				if (wifiremote_client.available()) {
					ok = true;
					uint8_t slash = 0;
					for (ever) {
						char chr = wifiremote_client.read();
						if (chr == '\n') break;
						else if (chr == '/') ++slash;
						else if (slash > 0) {
							if (chr == ' ' or slash == 3) break;
							href[slash-1] += chr;
						}
					}
					break;
				}
				// Wait for available() 2 seconds:
				else if (i > 20) break;
				else {
					delay(100);
					++i;
				}
			}
		}
		return ok;
	}

	void clientHTML_create(String css, String body) {
		wifiremote_client.println("HTTP/1.1 200 OK\nContent-type:text/html\nConnection:close\n\n<!DOCTYPE html>\n<html>\n<head>\n<title>ESP32 WebServer</title>\n<link rel=\"icon\" type=\"image/x-icon\" href=\"https://cdn-icons-png.flaticon.com/512/689/689360.png\">\n<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width,initial-scale=1,user-scalable=no\">\n<style>html{display:inline-block;user-select:none}body{margin:0px}" + css + "</style>\n</head>\n<body>\n" + body + "\n</body>\n</html>\n");
	}
};

#define __WiFiRemote_h__ 1
#endif
