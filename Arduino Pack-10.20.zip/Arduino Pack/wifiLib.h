#include <WiFi.h>

WiFiClient wifilib_client;
WiFiServer wifilib_server(80);
IPAddress wifilib_local_ip(192, 168, 0, 100);
const char *wifilib_ssid, *wifilib_password;

void wifilib_disconnected(WiFiEvent_t event, WiFiEventInfo_t info) {
	if (wifilib_local_ip[2] == 0) return;
	wifilib_local_ip[2] = 0;
	WiFi.disconnect(true, true);
	delay(1000);
	WiFi.mode(WIFI_STA);
	WiFi.begin(wifilib_ssid, wifilib_password);
}

void wifilib_connected(WiFiEvent_t event, WiFiEventInfo_t info) {
	if (wifilib_local_ip[2] == WiFi.gatewayIP()[2]) return;
	wifilib_local_ip[2] = WiFi.gatewayIP()[2];
	WiFi.config(wifilib_local_ip);
	Serial.print("ESP STA WebServer IP: ");Serial.println(WiFi.localIP());
}

class WiFiLib {
private:
public:

	//--- SETUP
	//--- HOTSPOT handling -----------------------------------------------//

	void createHotspot(const char *ssid, const char *password) {
		WiFi.softAP(ssid, password);
		wifilib_server.begin();
		Serial.print("ESP AP WebServer IP: ");Serial.println(WiFi.softAPIP());
	}

	void connectToHotspot(const char *ssid, const char *password) {
		WiFi.mode(WIFI_STA);
		WiFi.begin(ssid, password);
		wifilib_ssid = ssid;
		wifilib_password = password;
		WiFi.onEvent(wifilib_connected, WiFiEvent_t::ARDUINO_EVENT_WIFI_STA_GOT_IP);
		delay(1000);
		WiFi.onEvent(wifilib_disconnected, WiFiEvent_t::ARDUINO_EVENT_WIFI_STA_DISCONNECTED);
		wifilib_server.begin();
	}

	//--- LOOP
	//--------------------------------------------------------------------//

	char clientHrefValue() {
		char value = 0;
		wifilib_client = wifilib_server.accept();
		if (wifilib_client) {
			uint32_t i = 0;
			while (wifilib_client.connected()) {
				if (wifilib_client.available()) {
					bool chr_sw = false;
					value = '0';
					for (ever) {
						char chr = wifilib_client.read();
						if (chr == '\n') break;
						else if (chr == '/') chr_sw = true;
						else if (chr_sw and chr != ' ') {
							value = chr; // -> /x
							break;
						}
					}
					break;
				}
				else if (i > 200) break;
				else {
					delay(1);
					++i;
				}
			}
		}
		return value;
	}

	void clientHtml(String bodyInnerHTML) {
		wifilib_client.println("HTTP/1.1 200 OK\nContent-type:text/html\nConnection:close\n\n<!DOCTYPE html>\n<html><head><title>ESP32 WebServer</title><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1, user-scalable=no\"><link rel=\"icon\" type=\"image/x-icon\" href=\"https://raw.githubusercontent.com/re-is/shl.min/refs/heads/main/server.ico\"><style>html{display:inline-block;user-select:none}body{margin:0px}</style></head><body>" + bodyInnerHTML + "</body></html>\n");
	}

};
