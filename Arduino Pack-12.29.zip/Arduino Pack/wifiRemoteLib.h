#ifndef __WiFiRemote_h__

#include <WiFi.h>

// Global variables:
//------------------------------------------------------------------------------------//

NetworkClient wifiremote_client;
NetworkServer wifiremote_server(80);
IPAddress wifiremote_local_ip(192, 168, 0, 100);
IPAddress wifiremote_subnet_ip(255, 255, 255, 0);
const char *wifiremote_ssid, *wifiremote_password;

void wifiremote_event(WiFiEvent_t event) {
	if (event == ARDUINO_EVENT_WIFI_STA_DISCONNECTED) {
		if (wifiremote_local_ip[2] == 0) return;
		wifiremote_local_ip[2] = 0;
		Serial.println("Disconnected!");
		WiFi.disconnect(true, true);
		delay(500);
		WiFi.mode(WIFI_STA);
		WiFi.begin(wifiremote_ssid, wifiremote_password);
	}
	else if (event == ARDUINO_EVENT_WIFI_STA_GOT_IP) {
		if (wifiremote_local_ip[2] == WiFi.gatewayIP()[2]) return;
		wifiremote_local_ip[2] = WiFi.gatewayIP()[2];
		// 192.168.x.100
		WiFi.config(wifiremote_local_ip);
		Serial.print("WebServer IP: ");Serial.println(WiFi.localIP());
	}
}

class WiFiRemote {
private:
public:

	//--- SETUP
	//--- HOTSPOT handling -----------------------------------------------//

	void cssCompression(String &css) {
		css.replace("\t", "");
		css.replace("\n", "");
		css.replace("  ", " ");
		css.replace(" {", "{");
		css.replace("{ ", "{");
		css.replace(" }", "}");
		css.replace("} ", "}");
		css.replace(" (", "(");
		css.replace("( ", "(");
		css.replace(" )", ")");
		css.replace(") ", ")");
		css.replace(" :", ":");
		css.replace(": ", ":");
		css.replace(" ,", ",");
		css.replace(", ", ",");
		css.replace(" ;", ";");
		css.replace("; ", ";");
		css.replace(";}", "}");
	}

	void createHotspot(const char *ssid, const char *password) {
		WiFi.mode(WIFI_AP);
		wifiremote_local_ip[2] = 10;
		//  192.168.10.100
		WiFi.softAPConfig(wifiremote_local_ip, wifiremote_local_ip, wifiremote_subnet_ip);
		WiFi.softAP(ssid, password);
		wifiremote_server.begin();
		Serial.print("WebServer IP: ");Serial.println(WiFi.softAPIP());
	}

	void connectToHotspot(const char *ssid, const char *password) {
		WiFi.mode(WIFI_STA);
		WiFi.begin(ssid, password);
		wifiremote_ssid = ssid;
		wifiremote_password = password;
		wifiremote_server.begin();
		WiFi.onEvent(wifiremote_event);
	}

	//--- LOOP
	//--------------------------------------------------------------------//

	bool clientHTML_result(long *res) {
		if (res[0]) res[0] = 0;
		if (res[1]) res[1] = 0;
		NetworkClient client = wifiremote_server.accept();
		// Set saved client by current:
		if (client) wifiremote_client = client;
		// Wait for available:
		if (wifiremote_client and wifiremote_client.connected() and wifiremote_client.available()) {
			String _id, _value;
			uint8_t slash = 0;
			char chr = 0;
			while (chr = wifiremote_client.read()) {
				if (chr == '\n') break;
				else if (chr == '/') ++slash;
				else if (slash > 0) {
					if (chr == ' ' or slash == 3) break;
					if (slash-1 == 0) _id += chr;
					else _value += chr;
				}
			}
			res[0] = _id.toInt();
			res[1] = _value.toInt();
			return true;
		}
		return false;
	}

	void clientHTML_create(String css, String body) {
		String html = "";

		html += "HTTP/1.1 200 OK\n";
		html += "Content-type:text/html\n";
		html += "Connection:close\n\n";
		html += "<!DOCTYPE html>\n";
		html += "<html><head><title>ESP32 WebServer</title>\n";
		html += "<link rel=\"icon\" href=\"data:image/png;base64,iVBORw0KGgo=\">\n";
		html += "<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">\n";
		html += "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1,user-scalable=no\">\n";
		html += "<style>html{user-select:none}body{margin:0px}" + css + "</style>";
		html += "</head><body>" + body + "</body></html>\n";

		wifiremote_client.println(html);
		wifiremote_client.stop();
	}
};

#define __WiFiRemote_h__ 1
#endif
