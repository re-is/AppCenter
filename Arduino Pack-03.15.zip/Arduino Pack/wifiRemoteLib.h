#ifndef __WiFiRemote_h__
#define __WiFiRemote_h__ 1

#include <WiFi.h>
#include <ESPmDNS.h>
#include <ESPAsyncWebServer.h>

AsyncWebServer wifiremote_server(80);
AsyncWebSocket wifiremote_socket("/ws");

const char wifiremote_js[] PROGMEM = R"js(((w)=>{document.body?.firstChild.remove();w.websocket=new WebSocket(`ws://${w.location.hostname}/ws`);w.websocket.addEventListener('open',()=>{w.websocket.send('first trigger')});w.websocket.addEventListener('message',(e)=>{let m=e.data;if(m.indexOf('js:')===0)new Function(m.substring(3))()});w.S=(sel,res)=>{let e=document.querySelector(sel);if(e&&res)e.setAttribute('result',res);return e};w.android||={lightLimits:(x,y)=>{},orientation:()=>{},rssiSwitch:(x)=>{}};w.addEventListener('click',(e)=>{let res=(e.target.getAttribute('result')||'');if(res==='')return;if(w.websocket.readyState!==1)return w.location.reload(true);w.websocket.send(`${e.target.id} ${res}`)},{passive:false})})(window);)js";
const char wifiremote_html[] PROGMEM =
#include "index.html"
;

class WiFiRemote {
private:

	uint32_t reconnect_ms = 0, message_ms = 0;
	uint16_t lux_limit_a = 0, lux_limit_b = 0;
	bool disconnected = true, station_mode = false, enable_orientation = false, result_bool = false, rssi_s = false;
	int rssi_limit = 1, rssi_avg[20], rssi_counter = 0;

	void initServer() {

		wifiremote_socket.onEvent([this](AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type, void *arg, uint8_t *data, size_t len) {
			switch (type) {
			case WS_EVT_CONNECT:
				Serial.printf("WebSocket client #%u connected from %s\n", client->id(), client->remoteIP().toString().c_str());
				break;
			case WS_EVT_DISCONNECT:
				Serial.printf("WebSocket client #%u disconnected\n", client->id());
				break;
			case WS_EVT_DATA:
				AwsFrameInfo *info = (AwsFrameInfo*)arg;
				if (info->opcode == WS_TEXT && info->final && info->index == 0 && info->len == len && len > 0 && len < 32) {
					char msg[32], i[16], r[16];
					size_t l = min(len, sizeof(msg) - 1);
					memcpy(msg, data, l);
					msg[l] = 0;
					if (sscanf(msg, "%15s %15s", i, r) == 2) {
						id = i;
						result = r;
					}
				}
				break;
			}
		});

		wifiremote_server.addHandler(&wifiremote_socket);

		wifiremote_server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
			request->send_P(200, "text/html", wifiremote_html);
		});

		wifiremote_server.on("/wifiremote.js", HTTP_GET, [this](AsyncWebServerRequest *request){

			AsyncResponseStream *response = request->beginResponseStream("application/javascript");

			response->print(FPSTR(wifiremote_js));
			response->print("\n");

			if (lux_limit_a) {
				response->print("android.lightLimits(");
				response->print(lux_limit_a);
				response->print(",");
				response->print(lux_limit_b);
				response->print(");");
			}

			if (enable_orientation) {
				response->print("android.orientation();");
			}

			if (station_mode && rssi_limit < 1) {
				response->print("android.rssiSwitch(");
				response->print(rssi_limit);
				response->print(");");
			}

			request->send(response);
		});

		wifiremote_server.begin();

		id.reserve(16);
		result.reserve(16);
	}

public:

	String id, result;

	// --- Access Point mode,
	// Create Access Point. IP: 192.168.100.1
	void create(const char *ssid, const char *password) {
		WiFi.mode(WIFI_AP);
		IPAddress ip1(192, 168, 100, 1);
		IPAddress ip2(255, 255, 255, 0);
		WiFi.softAPConfig(ip1, ip1, ip2);
		WiFi.softAP(ssid, password);
		initServer();
		MDNS.begin("esp");
		Serial.printf("WebServer\n  - Host: http://esp.local\n  - IP: http://%s\n", ip1.toString().c_str());
	}

	// --- Station mode,
	// Connect to Access Point. IP: dynamic.dynamic.dynamic.1
	void connect(const char *ssid, const char *password) {
		WiFi.mode(WIFI_STA);
		WiFi.begin(ssid, password);
		station_mode = true;
		initServer();
	}

	//-----------------------------------------------//



	// Send websocket Response-message to all clients:
	void send(const String& text) {
		wifiremote_socket.textAll(text);
	}



	// JavaScript evaluation in all clients:
	void evalJS(const String& javascript) {
		send("js:" + javascript);
	}



	// Client websocket message:
	bool onMessage() {
		wifiremote_socket.cleanupClients();

		// STA mode:
		if (station_mode) {
			uint32_t ms = millis();
			if (uint32_t(ms - message_ms) >= 100) {
				// CONNECTION LOST:
				if (WiFi.status() != WL_CONNECTED) {
					if (!disconnected) {
						//WFR_ID = "";
						IPAddress ip(0, 0, 0, 0);
						WiFi.config(ip);
						MDNS.end();
						Serial.println(F("WiFi connection lost !"));
						disconnected = true;
					}
					// Reconnect by 5 seconds interval:
					if (uint32_t(ms - reconnect_ms) >= 5000) {
						WiFi.reconnect();
						reconnect_ms = ms;
					}
				}
				else if (disconnected) {
					IPAddress gw = WiFi.gatewayIP();
					IPAddress ip(gw[0], gw[1], gw[2], 1);
					WiFi.config(ip);
					MDNS.begin("esp");
					Serial.printf("WebServer\n  - Host: http://esp.local\n  - IP: http://%s\n", ip.toString().c_str());
					disconnected = false;
				}
				// RSSI
				if (rssi_limit < 1) {

					rssi_avg[rssi_counter] = WiFi.RSSI();

					if (++rssi_counter == 20) rssi_counter = 0;

					int avg = 0;
					for (int i = 0; i < 20; ++i) {
						if (rssi_avg[i] < 0) avg += rssi_avg[i];
					}
					avg /= 20;

					if (rssi_limit == 0) {
						id = "RSSI_ID";
						result = String(avg);
					}
					else if (avg > rssi_limit) {
						if (!rssi_s) {
							id = "RSSI_ID";
							result = "ON";
							rssi_s = true;
						}
					}
					else if (avg < rssi_limit * 1.2) {
						if (rssi_s) {
							id = "RSSI_ID";
							result = "OFF";
							rssi_s = false;
						}
					}
				}

				message_ms = ms;
			}
		}

		if (id != "") {
			if (result_bool) {
				id = "";
				result = "";
				result_bool = false;
			}
			else result_bool = true;
		}

		return result_bool;
	}



	// Light-sensor for MobileApp:
	void lightSensor(uint16_t limitA = 0, uint16_t limitB = 0) {
		if (limitA == 0) {
			lux_limit_a = 1;
			return;
		}
		lux_limit_a = limitA;
		lux_limit_b = limitB;
	}

	// Gravity-sensor for MobileApp:
	void orientationSensor() {
		enable_orientation = true;
	}

	// Switch by RSSI:
	void rssiSwitch(int limit = 0) {
		rssi_limit = (limit > 0 ? 0 : limit);
	}

};

#endif
