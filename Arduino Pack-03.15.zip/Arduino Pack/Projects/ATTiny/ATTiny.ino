#include "C:/Program Files/Apps/Arduino Pack/pinoutLib.h"
#include "C:/Program Files/Apps/Arduino Pack/generaLib.h"

GeneraLib::PWM <NANO_D2> left;
GeneraLib::PWM <NANO_D3> right;

void setup() {

	left.init();
	right.init();

	Serial.begin(1000000);

	uint32_t m = 0;

	for (ever) {

		m = micros();

		//right.run(m, 2000, 0.05);

	}
}
