(function js_min() {

	var js_file = 'wifiremote.js';
	var fso = new ActiveXObject('Scripting.FileSystemObject');
	var opened_text_file = fso.OpenTextFile(js_file, 1);
	var text = opened_text_file.ReadAll(); opened_text_file.Close();

	text = text.replace(/\r\n|\t/g, '');
	text = text.replace(/[/][*].*[*][/]/g, '');
	text = text.replace(/\B\s|\s\B/g, '');
	text = text.replace(/\;\}/g, '}');
	text = text.replace(/\}\$/g, '\} \$');

	var ch = text.split('');
	var max_lines = parseInt(Math.round(ch.length / 80));
	var new_line = 0;
	var js_text = 'const char wifiremote_js[] PROGMEM = R"js(' + text + ')js";';

	var min = fso.CreateTextFile('w-----------------------temp.txt', true);
	min.Write(js_text);
	min.Close();

})();
