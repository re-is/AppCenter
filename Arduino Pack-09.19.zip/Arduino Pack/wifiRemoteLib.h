#ifndef __WiFiRemote_h__
#define __WiFiRemote_h__ 1

#include <WiFi.h>
#include <ESPmDNS.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <LittleFS.h>

//-----------------------------------------------//

#define WFR_LIGHT_ID "-10000"
#define WFR_ORIENTATION_ID "-20000"

AsyncWebServer wifiremote_server(80);
AsyncWebSocket wifiremote_socket("/ws");

//-----------------------------------------------//

String wifiremote_index_html, WFR_ID, WFR_RESULT;
void wifiremote_event_handler(AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type, void *arg, uint8_t *data, size_t length) {
	switch (type) {
	case WS_EVT_CONNECT:
		Serial.printf("WebSocket client #%u connected from %s\n", client->id(), client->remoteIP().toString().c_str());
		break;
	case WS_EVT_DISCONNECT:
		Serial.printf("WebSocket client #%u disconnected\n", client->id());
		break;
	case WS_EVT_PONG:
		break;
	case WS_EVT_ERROR:
		break;
	case WS_EVT_DATA:
		AwsFrameInfo *info = (AwsFrameInfo *)arg;
		if (info->final && info->index == 0 && info->len == length && info->opcode == WS_TEXT) {
			data[length] = 0;
			bool res = false;
			for (int i = 0; i < length; i++) {
				char chr = data[i];
				if (chr == ' ') res = true;
				else if (res) WFR_RESULT += chr;
				else WFR_ID += chr;
			}
		}
		break;
	}
}

//-----------------------------------------------//

class WiFiRemote {
private:

	uint32_t reconnect_ms = 0, message_ms = 0;
	uint16_t lux_limit_a = 0, lux_limit_b = 0;
	bool disconnected = true, station_mode = false, enable_orientation = false;

	void initServer() {

		LittleFS.begin(true);
		File file = LittleFS.open("/index.html");

		delay(1000);

		wifiremote_index_html = file.readString();
		wifiremote_index_html.replace("</head>", "<script>"
			"((w)=>{w.websocket=new WebSocket(`ws://${w.location.hostname}/ws`);w.websocket.a"
			"ddEventListener('open',()=>{websocket.send('onOpen')});w.websocket.addEventListe"
			"ner('message',function(e){let m=e.data;if(m.indexOf('js:')!==0)return;w.pingTime"
			"=(w.pingTime?new Date().getTime()-w.pingTime:0);new Function(m.substring(3))();w"
			".pingTime=0});w.S=(id,res)=>{let e=document.querySelector(id);if(e&&res)e.setAtt"
			"ribute('result',res);return e};w.android||={xhrError:()=>{},lightLimits:(x,y)=>{"
			"},orientation:()=>{}};w.addEventListener('click',function(e){let res=(e.target.g"
			"etAttribute('result')||'');if(res==='')return;if(w.websocket.readyState!==1)retu"
			"rn w.location.reload(true);w.pingTime=new Date().getTime();w.websocket.send(`${e"
			".target.id} ${res}`)},{passive:false})})(window);" +
			(lux_limit_a ? "android.lightLimits(" + String(lux_limit_a) + "," + String(lux_limit_b) + ");" : "") +
			(enable_orientation ? "android.orientation();" : "") +
			"</script>\n</head>");

		wifiremote_socket.onEvent(wifiremote_event_handler);
		wifiremote_server.addHandler(&wifiremote_socket);

		wifiremote_server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
			request->send(200, "text/html", wifiremote_index_html);
		});

		wifiremote_server.begin();

		MDNS.begin("esp");
	}

public:

	// --- Access Point mode,
	// Create Hotspot. IP: 192.168.100.1
	void create(const char *ssid, const char *password) {
		WiFi.mode(WIFI_AP);
		IPAddress ip1(192, 168, 100, 1);
		IPAddress ip2(255, 255, 255, 0);
		WiFi.softAPConfig(ip1, ip1, ip2);
		WiFi.softAP(ssid, password);
		initServer();
		Serial.print(F("WebServer\n  - Host: http://esp.local\n  - IP: http://"));Serial.println(ip1);
	}

	// --- Station mode,
	// Connect to Hotspot. IP: dynamic.dynamic.dynamic.1
	void connect(const char *ssid, const char *password) {
		WiFi.mode(WIFI_STA);
		WiFi.begin(ssid, password);
		initServer();
		station_mode = true;
	}

	//-----------------------------------------------//



	// Send websocket Response-message to all clients:
	void send(String text) {
		wifiremote_socket.textAll(text);
		WFR_ID = "";
		WFR_RESULT = "";
	}



	// JavaScript evaluation in all clients:
	void evalJS(String javascript) {
		send("js:" + javascript);
	}



	// Client websocket Request:
	bool onMessage() {
		wifiremote_socket.cleanupClients();

		// STA mode:
		if (station_mode) {
			uint32_t ms = millis();
			if (uint32_t(ms - message_ms) >= 100) {
				// CONNECTION LOST:
				if (WiFi.status() != WL_CONNECTED) {
					if (!disconnected) {
						WFR_ID = "";
						IPAddress ip(0, 0, 0, 0);
						WiFi.config(ip);
						Serial.println("WiFi connection lost !");
						disconnected = true;
					}
					// Reconnect by 5 seconds interval:
					if (uint32_t(ms - reconnect_ms) >= 5000) {
						WiFi.reconnect();
						reconnect_ms = ms;
					}
				}
				else if (disconnected) {
					IPAddress gw = WiFi.gatewayIP();
					IPAddress ip(gw[0], gw[1], gw[2], 1);
					WiFi.config(ip);
					Serial.print(F("WebServer\n  - Host: http://esp.local\n  - IP: http://"));Serial.println(ip);
					disconnected = false;
				}
				message_ms = ms;
			}
		}

		return (WFR_ID != "");
	}



	// Light-sensor for MobileApp:
	void lightSensor(uint16_t limitA = 0, uint16_t limitB = 0) {
		if (limitA == 0) {
			lux_limit_a = 1;
			return;
		}
		lux_limit_a = limitA;
		lux_limit_b = limitB;
	}

	// Gravity-sensor for MobileApp:
	void orientationSensor() {
		enable_orientation = true;
	}
};

#endif
