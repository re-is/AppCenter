((w)=>{
	w.websocket=new WebSocket(`ws://${w.location.hostname}/ws`);
	w.websocket.addEventListener('open',()=>{websocket.send('onOpen')});
	w.websocket.addEventListener('message',function(e){
		let m=e.data;
		if(m.indexOf('js:')!==0)return;
		w.pingTime=(w.pingTime?new Date().getTime()-w.pingTime:0);
		new Function(m.substring(3))();
		w.pingTime=0;
	});
	w.S=(id,res)=>{let e=document.querySelector(id);if(e&&res)e.setAttribute('result',res);return e};
	w.android||={xhrError:()=>{},lightLimits:(x,y)=>{},orientation:()=>{}};
	w.addEventListener('click',function(e){
		let res=(e.target.getAttribute('result')||'');if(res==='')return;
		if(w.websocket.readyState!==1)return w.location.reload(true);
		w.pingTime=new Date().getTime();
		w.websocket.send(`${e.target.id} ${res}`);
	},{passive:false});
})(window);
