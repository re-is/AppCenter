class IRFcontrol {

private:

	uint8_t defaultState(uint8_t pin) {
		static uint8_t default_state = 2;
		if (default_state == 2 and millis() > 500) {
			uint8_t avg_state = 0;
			for (uint8_t i = 0; i < 20; i++) {
				delay(10);
				avg_state += uint8_t(digitalReadFast(pin));
			}
			default_state = (avg_state < 10 ? 0 : 1);
		}
		return default_state;
	}

public:

	void setCodeFast(uint32_t mcrs, uint8_t pin, uint32_t &code, uint8_t limit = 1) {

		static uint32_t last_code = 0, last_mcrs = 0;
		static uint16_t width = 0;
		static uint8_t bit_counter = 0, send_counter = 0;
		static bool signal = true;

		// Változáskor:
		if (last_code != code) {
			digitalWriteFast(pin, 0);
			bit_counter = 0;
			send_counter = 0;
			last_code = code;
		}

		// Továbbengedés, ha van kód:
		if (code == 0) return;

		// Reset:
		if (bit_counter == 0) {
			last_mcrs = mcrs;
			digitalWriteFast(pin, 1);
			width = 400;
			signal = true;
			send_counter++;
			bit_counter = 33;
		}

		if (send_counter > limit) {
			code = 0;
			send_counter = 0;
		}
		// Ha a pulse nagyobb, mint a szélesség:
		else if ((mcrs - last_mcrs) > width) {

			if (signal) {
				last_mcrs = mcrs;
				digitalWriteFast(pin, 0);
				bit_counter--;
				// Kezdőérték:
				if (bit_counter == 32) {
					width = 10000;
				}
				// Encoding:
				else {
					uint8_t bit = bitRead(last_code, bit_counter);
					width = (bit ? 1000 : 500);
				}
				signal = false;
			}
			else {
				last_mcrs = mcrs;
				digitalWriteFast(pin, 1);
				width = 400;
				signal = true;
			}
		}
	}


	//-----------------------------------------------------------------------------------//


	void setCodeSlow(uint8_t pin, uint32_t &code, uint8_t limit = 1) {

		static uint8_t send_counter = 0;

		if (code > 0) {
			send_counter++;
			// Ha már elküldte a limit értékét:
			if (send_counter > limit) {
				digitalWriteFast(pin, 1);
				delayMicroseconds(400);
				digitalWriteFast(pin, 0);
				code = 0;
				send_counter = 0;
			}
			else {
				uint8_t bit_counter = 33;
				while (bit_counter > 0) {
					digitalWriteFast(pin, 1);
					delayMicroseconds(400);
					digitalWriteFast(pin, 0);
					bit_counter--;
					// Kezdőérték:
					if (bit_counter == 32) {
						delayMicroseconds(10000);
					}
					// Encoding:
					else {
						uint8_t bit = bitRead(code, bit_counter);
						delayMicroseconds(bit ? 1000 : 500);
					}
				}
			}
		}
	}


	//-----------------------------------------------------------------------------------//


	uint32_t getCodeFast(uint32_t mcrs, uint8_t pin) {

		static bool signal = true;
		static uint32_t last_mcrs = 0, code = 0;
		static uint8_t bit_counter = 0;

		uint32_t rtrn = 0;

		if (digitalReadFast(pin) == defaultState(pin)) {
			if (signal) {
				last_mcrs = mcrs;
				signal = false;
			}
			// Ha vége:
			else if (bit_counter > 0 and (mcrs - last_mcrs) > 20000) {
				rtrn = code;
				code = 0;
				bit_counter = 0;
			}
		}
		else if (!signal) {
			uint32_t pulse = (mcrs - last_mcrs);

			// Bináris kód, decoding:
			if (pulse < 2000) {
				if (bit_counter < 32) {
					bitWrite(code, (31 - bit_counter), (pulse > 700 ? 1 : 0));
					bit_counter++;
				}
			}
			// Azonkívül reset:
			else if (pulse < 20000 and bit_counter > 0) {
				rtrn = code;
				code = 0;
				bit_counter = 0;
			}

			signal = true;
		}

		return rtrn;
	}


	//-----------------------------------------------------------------------------------//


	uint32_t getCodeSlow(uint32_t mcrs, uint8_t pin) {

		static bool signal = false;
		static uint32_t last_mcrs = 0;

		if (digitalReadFast(pin) == defaultState(pin)) {
			if (signal) {
				last_mcrs = mcrs;
				signal = false;
			}
			return 0;
		}

		uint32_t code = 0, rtrn = 0;
		uint8_t bit_counter = 0;

		for (ever) {

			mcrs = micros();

			uint32_t pulse = (mcrs - last_mcrs);

			if (digitalReadFast(pin) == defaultState(pin)) {
				if (signal) {
					last_mcrs = mcrs;
					signal = false;
				}
				// Ha vége:
				else if (pulse > 20000) {
					rtrn = code;
					break;
				}
			}
			else if (!signal) {

				// Bináris kód:
				if (pulse < 2000) {
					if (bit_counter < 32) {
						bitWrite(code, (31 - bit_counter), (pulse > 700 ? 1 : 0));
						bit_counter++;
					}
				}
				// Azonkívül:
				else if (pulse < 20000 and bit_counter > 0) rtrn = code;

				signal = true;
			}

			if (rtrn > 0) break;
		}

		return rtrn;
	}


	//-----------------------------------------------------------------------------------//


	bool findCode(uint32_t mcrs, uint32_t code, uint32_t found = 0, uint8_t limit = 3) {

		static uint32_t code_mcrs = 0, last_mcrs = 0;
		static uint8_t counter = 0;

		uint32_t diff = (mcrs - last_mcrs);
		if (diff > 1000) code_mcrs += diff;
		last_mcrs = mcrs;

		if (code > 0) {
			if (found == code) {
				code_mcrs = mcrs;
				if (counter <= limit) counter++;
				return (counter == limit);
			}
			if (found == 0) {
				Serial.println(code);
				return false;
			}
		}
		else if (counter > 0 and (mcrs - code_mcrs) > 300000) counter = 0;

		return false;
	}
};
