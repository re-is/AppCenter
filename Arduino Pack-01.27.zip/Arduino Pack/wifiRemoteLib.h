#ifndef __WiFiRemote_h__

#include <WiFi.h>

//-------------------------------------------------------------------------------------//

NetworkClient wifiremote_client;
NetworkServer wifiremote_server(80);
IPAddress wifiremote_server_ip(192, 168, 0, 100);
IPAddress wifiremote_subnet_ip(255, 255, 255, 0);
IPAddress wifiremote_reset_ip(0, 0, 0, 0);
bool wifiremote_station = false;

struct WiFiRemote {

	//---------------------------------------------------------------------------------//

	//  192.168.10.100
	void create(const char *ssid, const char *password) {
		WiFi.mode(WIFI_AP);
		wifiremote_server_ip[2] = 10;
		WiFi.softAPConfig(wifiremote_server_ip, wifiremote_server_ip, wifiremote_subnet_ip);
		WiFi.softAP(ssid, password);
		wifiremote_server.begin();
		Serial.print(F("WebServer IP: "));Serial.println(WiFi.softAPIP());
	}

	//  192.168.dynamic.100
	void connect(const char *ssid, const char *password) {
		WiFi.mode(WIFI_STA);
		WiFi.begin(ssid, password);
		wifiremote_server.begin();
		wifiremote_station = true;
	}






	//---------------------------------------------------------------------------------//

	class WRClient {
	private:
		uint32_t reconnect_millis = 0, min_lux = 0, max_lux = 0, reload_seconds = 0;
		bool disconnected = true;

		void compression(String &css) {
			css.replace("\t", "");
			css.replace("\n", "");
			css.replace("  ", " ");
			css.replace(" {", "{");
			css.replace("{ ", "{");
			css.replace(" }", "}");
			css.replace("} ", "}");
			css.replace(" (", "(");
			css.replace("( ", "(");
			css.replace(" )", ")");
			css.replace(") ", ")");
			css.replace(" :", ":");
			css.replace(": ", ":");
			css.replace(" ,", ",");
			css.replace(", ", ",");
			css.replace(" ;", ";");
			css.replace("; ", ";");
			css.replace(";}", "}");
		}

	public:

		String style, body;

		void lightSensor(uint32_t min, uint32_t max = 0) {
			min_lux = min;
			max_lux = max;
		}

		void reloadInterval(uint8_t seconds) {
			reload_seconds = seconds;
		}




		bool result(uint32_t *res) {
			// STA mode:
			if (wifiremote_station) {											// 0 - 2000 mcrs
				if (WiFi.status() != WL_CONNECTED) {							// 3 mcrs
					// Reset IP, if your phone has a dynamic hotspot:
					if (!disconnected) {
						wifiremote_server_ip[2] = 0;
						WiFi.config(wifiremote_reset_ip, wifiremote_reset_ip, wifiremote_reset_ip);
						Serial.println(F("WebServer IP: 0.0.0.0"));
						disconnected = true;
					}
					// Reconnect by 5 seconds interval:
					uint32_t diff = (millis() - reconnect_millis);
					if (diff > 5000) {
						if (WiFi.gatewayIP()[2] == 0) WiFi.reconnect();			// 400 mcrs
						reconnect_millis += diff;
					}
					return false;
				}
				else if (disconnected) {
					// After reconnect, add new IP, if it's changed:
					uint8_t w = WiFi.gatewayIP()[2];
					if (w > 0) {
						wifiremote_server_ip[2] = w;
						WiFi.config(wifiremote_server_ip);
						Serial.print(F("WebServer IP: "));Serial.println(WiFi.localIP());
						disconnected = false;
					}
				}
			}
			NetworkClient current_client = wifiremote_server.accept();			// 40 - 800 mcrs
			// Set saved client by current:
			if (current_client) wifiremote_client = current_client;
			// Wait for available:												// 0 - 1500 mcrs
			if (wifiremote_client and wifiremote_client.connected() and wifiremote_client.available()) {
				// Reset results:
				res[0] = 0;
				res[1] = 0;
				uint32_t slash = 0;
				char chr = 0;
				while (chr = wifiremote_client.read()) {
					if (chr == '\n') break;
					else if (chr == '/') slash++;
					else if (slash > 0) {
						if (chr == ' ' or slash == 3) break;
						res[slash-1] *= 10;
						res[slash-1] += uint8_t(chr - '0');
					}
				}
				return true;
			}
			return false;
		}




		void evalJs(uint32_t *res, String script) {

			// Page build:
			if (res[0] == 0) {

				compression(style);

				String html = "HTTP/1.1 200 OK\nContent-type:text/html\n\n";

				html += "<!DOCTYPE html>\n";
				html += "<html><head><title>WebServer</title>\n";
				html += "<link rel=\"icon\" href=\"data:image/png;base64,iVBORw0KGgo=\">\n";
				html += "<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">\n";
				html += "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1,user-scalable=no\">\n";
				html += "<style>html{user-select:none}body{margin:0px}" + style + "</style>";
				html += "</head><body>" + body + "<script>";
				html += R"(window.result=(function(){let x=null,timer=0,a=window.android||{xhrLoadingError:function(){}};return function(data){let p=new Date().getTime(),d=data.split('-'),id=d[0],v=d[1];if(x){clearTimeout(timer);x.abort()}x=new XMLHttpRequest();x.onreadystatechange=function(){if(this.readyState==4&&this.status==200){clearTimeout(timer);window.pingTime=(new Date().getTime()-p);new Function(this.responseText)();x=null}};x.open('GET',(location.href.match(/http:\/\/\d+\.\d+\.\d+\.\d+/)+'/'+id+(v?'/'+v:'')),true);x.send();timer=setTimeout(function(){x.abort();x=null;a.xhrLoadingError()},2000)}})();document.onclick=function(e){let d=e.target.getAttribute('result');if(d)result(d)};)";

				if (reload_seconds)	html += "setInterval(function(){result('9999')}," + String(reload_seconds * 1000) + ");";
				if (min_lux)		html += "(function(){let a=window.android||{lightLimits:function(x,y){}};a.lightLimits(" + String(min_lux) + "," + String(max_lux) + ")})();";

				html += script + "</script></body></html>\n";

				wifiremote_client.println(html);
			}
			// Evaluate JavaScript:
			else wifiremote_client.println(script);

			wifiremote_client.stop();
		}


	}; // WRClient


	WRClient client;
};


#define __WiFiRemote_h__ 1
#endif
