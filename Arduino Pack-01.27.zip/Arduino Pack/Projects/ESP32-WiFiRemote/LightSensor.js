window.result=(function(){
	let x=null,timer=0,a=window.android||{xhrLoadingError:function(){}};
	return function(data){
		let p=new Date().getTime(),d=data.split('-'),id=d[0],v=d[1];
		if(x){clearTimeout(timer);x.abort()}
		x=new XMLHttpRequest();
		x.onreadystatechange=function(){
			if(this.readyState==4&&this.status==200){
				clearTimeout(timer);
				window.pingTime=(new Date().getTime()-p);
				new Function(this.responseText)();
				x=null;
			}
		};
		x.open('GET',(location.href.match(/http:\/\/\d+\.\d+\.\d+\.\d+/)+'/'+id+(v?'/'+v:'')),true);
		x.send();
		timer=setTimeout(function(){x.abort();x=null;a.xhrLoadingError()},2000);
	}
})();
document.onclick=function(e){let d=e.target.getAttribute('result');if(d)result(d)};




(function(){let a=window.android||{lightLimits:function(x,y){}};a.lightLimits(" + String(min_lux) + "," + String(max_lux) + ")})();
