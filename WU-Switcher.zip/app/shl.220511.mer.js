/*--------------------------------//////////////////////////////////////

	Super HTA Library
	_____________________________
	Creator: István Reich, 2016
	Version: 220511
	Latest update: 2022.09.20

//--------------------------------////////////////////////////////////*/

(function(_Win, _Doc) {

	// Érték lekérése:
	String.prototype.getValue = function(name) {
		let s = this.toString(), f = new RegExp('\\b' + name), n = new RegExp('(.*\\b' + name + '\\s*)|\\s|;');
		return ((s.search(f) > -1) ? s.split(n)[2] : '');
	};

	// Érték megadása:
	// noinspection JSUnusedGlobalSymbols
	String.prototype.setValue = function(name, value) {
		value = value.replace(/\s\s*/g, '_');
		let s = this.toString(), f = new RegExp('\\b' + name), n = new RegExp('(.*\\b' + name + '\\s*)|\\s|;'), length = s.search(f);
		if (length > -1) {
			length += name.length;
			return (s.slice(0, length) + value + s.slice((length + s.split(n)[2].length), s.length));
		}
		return s;
	};

	HTMLElement.prototype.getAttr = function(attr, incl) {
		let a = this.getAttribute(attr);
		return (incl ? (a === null ? false : (a.search(incl) > -1)) : (a === null ? '' : a));
	};

	HTMLElement.prototype.setAttr = function(attr, value) {
		this.setAttribute(attr, (typeof value === 'object' ? JSON.stringify(value) : String(value)));
	};

	HTMLElement.prototype.elemIs = function(value) {
		let a = this.getAttribute('shl-elem');
		return (a === null ? false : (a.search(value) > -1));
	};

	// -- attr:		'marked|deactivated|item'		<= string
	// -- value:	state							<= true|false|undefined|number
	HTMLElement.prototype.change = function(attr, value) {
		if (!this.elemIs(/(cb-input|rb-input|sr-input)/)) return;
		if (attr === 'deactivated') this.setAttr('deactivated', (value === true) ? 'true' : 'false');
		// Ha nincs letiltva:
		else if (!this.getAttr('deactivated', 'true')) {
			if (this.elemIs(/(cb-input|rb-input)/) && (attr === 'marked')) {
				let marked = this.getAttr('marked', 'true');

				// RB -------------------------------------------------------->
				if (this.elemIs('rb-input')) {
					if (!marked) {
						let func = this.getAttr('func');
						if (func !== '') new Function('(' + func + ')("' + this.getAttr('id') + '")')();
					}
					// A csoporthoz tartozó összes RB kiürítése:
					let group = this.getAttr('group');
					_LoopIn(_ShlElems('rb-input'), function(key, elem) {
						if (elem.getAttr('group', group)) elem.setAttr('marked', 'false');
					});
					this.setAttr('marked', 'true');
				}

				// CB -------------------------------------------------------->
				else {
					let cb = ((value === undefined) ? !marked : value).toString();
					// Csak változáskor:
					if (marked !== value) {
						let func = this.getAttr('func');
						if (func !== '') new Function('(' + func + ')(' + cb + ')')();
					}
					this.setAttr('marked', cb);
				}
			}

			// Selector ------------------------------------------------------>
			else if (attr === 'item') {
				let items = JSON.parse(this.getAttr('items'));
				// Csak változáskor:
				if (!_Find(this.innerHTML, items[value])) {
					let func = this.getAttr('func');
					if (func !== '') new Function("(" + func + ")('" + items[value].replace(/[']/g, "\\'") + "')")();
					this.innerHTML = items[value];
				}
			}
		}
	};

	HTMLElement.prototype.func = function(func) {
		if (this.elemIs(/(cb-input|rb-input|sr-input)/)) this.setAttr('func', func);
	};

	HTMLElement.prototype.marked = function(func) {
		return (this.getAttr('marked', 'true'));
	};

	HTMLElement.prototype.deactivated = function(func) {
		return (this.getAttr('deactivated', 'true'));
	};

	// Helyi változók:
	//----------------------------------------------------------------//
	// noinspection JSUnusedGlobalSymbols
	let _Offset = [0,0],
		_OuterSize = [0,0],
		_Border = [0,0],
		_Opened = false,
		_IsOpen = false,
		_IsLoaded = false,
		_IsFaded = false,
		_TimerA = -1,
		_TimerB = -1,
		_LightMode = true,
		_LastMsg = 0,
		_MsgArray = [],
		_LogRows = 0,
		_LogRefresh = 20,
		_LoglineText = '',
		_LoglineEnabled = true,
		_TitleBarClicked = false,
		_PowerTime = {},
		_CssObject = {},
		_MPowerTime = (new Date().getTime()),
		_Fso = (new ActiveXObject('Scripting.FileSystemObject')),
		_Wss = (new ActiveXObject('WScript.Shell')),
		_Sap = (new ActiveXObject('Shell.Application')),
		_Req = (new ActiveXObject('Microsoft.XMLHTTP')),
		_HTAtag = _Doc.createElement('HTA:APPLICATION'),
		_Hun = function() { let h; try { h = (_Wss['RegRead']('HKLM\\SYSTEM\\ControlSet001\\Control\\Nls\\Language\\InstallLanguage').toLowerCase() === '040e') } catch(e) { h = false } return h }(),
		_LoopIn = function(obj, func) {
			let key, index = 0;
			for (key in obj) {
				if (!obj.hasOwnProperty(key)) continue;
				if (func(key, obj[key], index)) break;
				index++;
			}
		},
		_LoopPlus = function(length, func) {
			for (let index = 0; index < length; index++) if (func(index)) break;
		},
		_LoopMinus = function(length, func) {
			for (let index = (length-1); index >= 0; index--) if (func(index)) break;
		},
		// Ha tartalmazza a szöveg:
		// -- srch	: forrás			<= string | number | array
		// -- find	: /regex/			<= string
		// return	: true-false		=> boolean
		_Find = function(srch, find) {
			if (typeof srch === 'object') {
				let b = false;
				_LoopIn(srch, function(key, value) { if (value === find) b = true });
				return b;
			}
			else return (String(srch).search(find) > -1);
		},
		// Engedélyezett tag-ek:
		_AllowedElems = function(func) {
			let e, all = _Doc.getElementsByTagName('*'), escaped = 'html head style script title link meta area base br col embed img source track wbr object param hta:application';
			for (e in all) {
				if (all.hasOwnProperty(e) && all[e].elemIs && escaped.indexOf(all[e].tagName.toLowerCase()) === -1) func(all[e]);
			}
		},
		_ShlElems = function(name) { return _Doc.querySelectorAll('[shl-elem~="' + name + '"]') },
		_ShlElem = function(name) { let e = _Doc.querySelectorAll('[shl-elem~="' + name + '"]'); return (e.length === 0 ? {none: true} : e[0]) },
		_Class = function(name) { let e = _Doc.getElementsByClassName(name); return (e.length === 0 ? { none: true, change: function(a,b) {}, func: function(a) {} } : e.length === 1 ? e[0] : e) },
		_Id = function(id) { return (_Doc.getElementById(id) || { none: true, change: function(a,b) {}, func: function(a) {} }) },
		_Parent = function(target, attr, value, func) {
			let a = null;
			_LoopPlus(5, function() {
				a = target.getAttribute(attr);
				if (a !== null) {
					if (a.search(value) === -1) a = null;
					else return true;
				}
				if (target.parentElement) target = target.parentElement;
				else return true;
			});
			if (a !== null) func(target);
		},
		// Méret átalakítása:
		// -- s			: méret			<= string  ( "640px", "50%" )
		// -- dir		: irány			<= string  ( "width", "height" )
		// return		: új méret		=> integer ( 640 )
		_ConvertSize = function(s, dir) {
			// Ha nincs megadva:
			if (s === undefined) s = 0;
			// Ha szám, akkor ez az eredmény:
			if (typeof s === 'number') return s;
			// Ha string és hiányoznak az azonosítók, akkor riasztás:
			if (!_Find(s, /px|%|vh|vw/)) {
				_Win.alert(".wnd .open() .setSize() .setOffset()\n\nWrong size parameters !\n\n•  '200px'\n•  '50%'\n•  '50vh'\n•  '50vw'\n");
				s = '50%';
			}
			// Átalakítás:
			if (_Find(s, 'px')) s = s.split('px')[0];
			else if (_Find(s, '%')) s = (_Win.screen[dir] * (parseFloat(s.split('%')[0]) / 100));
			else if (_Find(s, 'vw')) s = (_Win.screen.width * (parseFloat(s.split('vw')[0]) / 100));
			else if (_Find(s, 'vh')) s = (_Win.screen.height * (parseFloat(s.split('vh')[0]) / 100));
			return Math.round(s);
		},
		// Funkció futtatása animált frame-en:
		// -- func		: funkció		<= function(frame)
		// -- frame		: keret			<= number
		_DoOnFrame = function(func, frame) {
			let i = -1;
			if (frame !== undefined) {
				if (frame < 0) frame = 0;
				(function a() {
					if ((i > -1) && (frame === i)) { func(i); return null }
					i++; _Win.requestAnimationFrame(a);
				})();
			}
			else {
				(function b() {
					if ((i > -1) && func(i)) return null;
					i++; _Win.requestAnimationFrame(b);
				})();
			}
		},
		// Js transition:
		// -- ms		: millisec		<= number
		// -- func		: funkció		<= function(0 -> 1)
		_JsTransition = function(ms, func) {
			ms = parseInt(ms);
			if (ms < 100) return func(1);
			let max_frame = Math.round(ms / (1000 / 60)), cur_frame = -1, value = 0;
			(function a() {
				if (cur_frame < 0) func(value);
				else {
					value += (((1 - (cur_frame / max_frame)) * 2) / max_frame);
					if (value > 1) value = 1;
					func(value);
				}
				cur_frame++;
				if (value < 1) _Win.requestAnimationFrame(a);
			})();
		},
		// Ha a rendszer 64-bites:
		// return		: true-false	=> boolean
		_X64 = function() {
			function envr(s) { return _Wss['ExpandEnvironmentStrings'](s) }
			return _Find(envr('%PROCESSOR_ARCHITECTURE%') + ' ' + envr('%PROCESSOR_ARCHITEW6432%'), '64');
		},
		//▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬//
		//		Message box																			 //
		//▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬//
		_ReadArray = function() {
			let msgLayer = _ShlElem('msgbox-layer');
			// Kilépés, ha már megjelent a box:
			if (msgLayer.style.display === 'block') return;
			// Ha van új üzenet:
			if (_LastMsg < _MsgArray.length) {
				// Megjelenítés:
				_JsTransition(200, function(v) {
					if (v === 0) msgLayer.style.display = 'block';
					msgLayer.style.opacity = v.toString();
				});
				// Box lekérése:
				let box = _MsgArray[_LastMsg];
				// Többi elem:
				let dialog = _ShlElem('msgbox-dialog'),
					tarea = _ShlElem('msgbox-textarea'),
					bBlock = _ShlElem('msgbox-buttons-block'),
					msgLink = _ShlElem('msgbox-update-link'),
					btn1 = _ShlElem('msgbox-button-1'),
					btn2 = _ShlElem('msgbox-button-2');

				// - layer elrejtése; - ha van funkció, akkor futtatás; - és újra:
				function hide(b) {
					if (b && box[2]) box[2]();		// func1
					if (!b && box[4]) box[4]();		// func2
					_JsTransition(200, function(v) {
						msgLayer.style.opacity = (1 - v).toString();
						if (v === 1) {
							if (msgLayer.style.display === 'none') return;
							msgLink.style.display = 'none';
							msgLayer.style.display = 'none';
							_ReadArray();
						}
					});
				}
				// Gombok beállítása:
				//--------------------------------------------------------------------+
				btn1.style.display = 'none';
				btn2.style.display = 'none';
				// Ok-Yes gomb:
				btn1.textContent = (box[3] ? box[3] : ((box[0] === 'ok') ? 'Ok' : (_Hun ? 'Igen' : 'Yes')));
				btn1.style.display = 'inline-block';
				btn1.onclick = function() { hide(true) };
				// Ha 2 gombos:
				if (box[0] === 'confirm') {
					// Mégse (b2):
					btn2.textContent = (box[5] ? box[5] : (_Hun ? 'Mégse' : 'Cancel'));
					btn2.style.display = 'inline-block';
					btn2.onclick = function() { hide() };
					// Frissítési link megjelenítése:
					if (box[6]) {
						msgLink.style.display = 'inline-block';
						msgLink.style.visibility = 'visible';
						msgLink.style.opacity = '1';
						msgLink.style.color = '#999';
						msgLink.href = box[6];
					}
				}
				//--------------------------------------------------------------------+
				// Alaphelyzetbe állítás:
				tarea.value = String(box[1]);
				tarea.setAttr('wrap', 'off');
				tarea.style.overflowX = 'hidden';
				tarea.style.overflowY = 'scroll';
				tarea.style.width = '0px';
				tarea.style.height = '0px';
				dialog.style.marginTop = '0px';
				dialog.style.marginLeft = '0px';
				let dialog_padding = (dialog.offsetWidth - bBlock.offsetWidth), scroll_bar = tarea.offsetWidth;
				tarea.style.marginBottom = (dialog_padding + 'px');
				//--------------------------------------------------------------------+
				let inner = { w: _Win.innerWidth, h: _Win.innerHeight }, margin = (inner.w * 0.05);
				let limit = { w: (inner.w - margin - dialog_padding), h: (inner.h - margin - dialog.offsetHeight) };
				// Sortörés, ha szélesebb, mint a limit:
				if (tarea.scrollWidth > limit.w) {
					tarea.setAttr('wrap', 'on');
					tarea.style.width = (limit.w + 'px');
				}
				else tarea.style.width = (((tarea.scrollHeight > limit.h) ? (tarea.scrollWidth + scroll_bar) : (tarea.scrollWidth > bBlock.offsetWidth ? tarea.scrollWidth : bBlock.offsetWidth)) + 'px');
				// Ha magasabb, mint a limit:
				if (tarea.scrollHeight > limit.h) {
					tarea.style.height = (limit.h + 'px');
				}
				else {
					tarea.style.overflowY = 'hidden';
					tarea.style.height = (tarea.scrollHeight + 'px');
				}
				// Dialog középre igazítása:
				dialog.style.marginTop = (((inner.h * 0.5) - (dialog.offsetHeight * 0.5)) + 'px');
				dialog.style.marginLeft = (((inner.w * 0.5) - (dialog.offsetWidth * 0.5)) + 'px');
				//--------------------------------------------------------------------+
				// Törlés és léptetés:
				_MsgArray[_LastMsg] = false;
				_LastMsg++;
			}
		},
		// -- type		: Típus				<= string	( 'ok', 'confirm' )
		// -- text		: Szöveg			<= string
		// -- func1		: Ok, Igen			<= function()
		// -- b1		: func1 szöveg		<= string
		// -- func2		: Nem, Mégse		<= function()
		// -- b2		: func2 szöveg		<= string
		_ShowMsg = function(type, text, func1, b1, func2, b2, link) {
			// Megnyitás, ha az ablak kész:
			if (!_IsFaded) { setTimeout(function() { _ShowMsg(type, text, func1, b1, func2, b2, link) }, 15); return }
			// Tömbbe rakás:
			_MsgArray.push([type, text, func1, b1, func2, b2, link]);
			// Kiolvasás:
			_ReadArray();
		},
		// OK gomb:
		_OkMsg = function(t, f, b) { _ShowMsg('ok', t, f, b) },
		// Igen - Mégse gombok:
		_ConfirmMsg = function(t, f1, b1, f2, b2) { _ShowMsg('confirm', t, f1, b1, f2, b2) },
		//▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬//
		//		Object																				 //
		//▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬//
		// Alkalmazások azonnali bezárása:
		// -- file		: fájlnév.exe	<= string | array
		_TaskKill = function(file) {
			if (typeof file === 'string') _Wss['Run']('cmd.exe /c taskkill /f /im "' + file + '"', 0, true);
			else _LoopIn(file, function(key, f_le) { _Wss['Run']('cmd.exe /c taskkill /f /im "' + f_le + '"', 0, true) });
		},
		// Környezetiből normál elérési út:
		_Env = function(pn) {
			let s = (_Find(pn, '%') ? pn.split('%') : []);
			// Ha van %var%:
			if (s.length === 3) {
				s[1] = s[1].toLowerCase();
				// Ha 32-bites a rendszer és programfiles(x86), akkor (x86) levágása:
				if (!_X64() && _Find(s[1], '(x86)')) s[1] = s[1].substring(0, s[1].length-5);
				// Asztal:
				if (s[1] === 'desktop') s[1] = (_Wss['ExpandEnvironmentStrings']('%userprofile%') + '\\Desktop');
				// Kibontás:
				else s[1] = _Wss['ExpandEnvironmentStrings']('%' + s[1] + '%');
				pn = s.join('');
			}
			// Ha fájl, akkor a teljes út megadása: ('aaa.txt' => 'C:\Users\Admin\Desktop\aaa.txt')
			try { return String(_Fso['GetFile'](pn)) } catch(e) {}
			// Ha nem fájl, akkor a mappa út megadása:
			try { pn = String(_Fso['GetFolder'](pn)); if (pn.substring(pn.length-1, pn.length) !== '\\') pn += '\\'; return pn } catch(e) {}
			// Ha nem létezik, akkor az eredeti pathname
			return String(pn);
		},
		// Ha van ilyen fájl vagy mappa, az eredmény útvonal:
		// -- pn		: elérési út	<= string
		// return		: true-false	=> boolean
		_Exist = function(pn) {
			pn = _Env(pn);
			return (_Fso['FileExists'](pn) || _Fso['FolderExists'](pn));
		},
		// Szövegfájl készítés:
		// -- pn		: elérési út	<= string
		// -- text		: text			<= string
		// -- ow		: felülírás		<= boolean
		// -- uc		: unicode		<= boolean
		_CreateFile = function(pn, text, ow, uc) {
			pn = _Env(pn);
			// Ha van felülírás, akkor az előző törlése:
			if (_Exist(pn) && ((ow === undefined) ? true : ow)) _Fso['DeleteFile'](pn);
			// Új készítése, ha nincs:
			if (!_Exist(pn)) {
				let tf = _Fso['CreateTextFile'](pn, true, true);
				tf['WriteLine'](text);
				tf['Close']();
				if ((uc === undefined) ? true : !uc) {
					// Átalakítás UTF-8 -ra cmd-vel:
					_Wss['Run']('cmd.exe /c chcp 65001 & cmd.exe /c type "' + pn + '"> "' + pn + '.txt"', 0, true);
					// Törlés és átnevezés:
					_Fso['DeleteFile'](pn);
					_Fso['MoveFile'](pn + ".txt", pn);
				}
				return _Env(pn);
			}
		},
		// Mappa készítés:
		// -- pn		: elérési út	<= string
		// -- ow		: felülírás		<= boolean
		_CreateFolder = function(pn, ow) {
			pn = _Env(pn);
			// Az utolsó \ levágása:
			if (pn[pn.length-1] === '\\') pn = pn.substring(0, pn.length-1);
			if (_Exist(pn) && ((ow === undefined) ? true : ow)) _Fso['DeleteFolder'](pn);
			if (!_Exist(pn)) _Fso['CreateFolder'](pn);
			return _Env(pn);
		},
		// Zip fájl kibontása:
		// -- zf	: zip fájl			<= string
		// -- ef	: kibontási mappa	<= string
		// return	: kibontási mappa	=> string
		_UnZip = function(zf, ef) {
			zf = _Env(zf);
			ef = _Env(ef);
			function tk() { _TaskKill(['cmd.exe', 'mshta.exe']) }
			_Win.addEventListener('beforeunload', tk);
			try { zf = String(_Fso['GetFile'](zf)) }
			catch(e) { _Win.alert("obj.unZip()\n\nCannot find the ZIP file !\n\n" + zf); return '' }
			if (_Fso['FolderExists'](ef)) _Fso['DeleteFolder'](String(_Fso['GetFolder'](ef)));
			ef = String(_Fso['CreateFolder'](ef));
			_Sap['NameSpace'](ef)['CopyHere'](_Sap['NameSpace'](zf)['Items']());
			_Win.removeEventListener('beforeunload', tk);
			return _Env(ef);
		},
		// Fájl letöltése direkt-link megadásával:
		// -- url		: direct link		<= string
		// -- tgt		: target path		<= string
		// return		: target path		=> string
		_Download = function(url, tgt) {
			tgt = _Env(tgt);
			function tk() { _TaskKill(['powershell.exe', 'cmd.exe', 'mshta.exe']) }
			_Win.addEventListener('beforeunload', tk);
			_ShlElem('download-bar').style.display = 'block';
			_Wss['Run']('cmd.exe /c powershell -command (New-Object System.Net.WebClient).DownloadFile(\\"' + url + '\\",\\"' + tgt + '\\")', 0, true);
			_ShlElem('download-bar').style.display = '';
			_Win.removeEventListener('beforeunload', tk);
			return tgt;
		},
		// Szövegfájl beolvasása unicode-ként:
		// return		: szöveg		=> string
		/*_ReadInUnicode = function(pn) {
			function tk() { _TaskKill(['cmd.exe', 'mshta.exe']) }
			_Win.addEventListener('beforeunload', tk);
			_Wss['Run']('cmd.exe /c chcp 65001 & cmd.exe /u /c type "' + pn + '"> "' + pn + '.uni"', 0, true);
			let unicode_file = _Fso['OpenTextFile'](pn + '.uni', 1, 0, -1), text = unicode_file['ReadAll']();
			unicode_file['Close']();
			_Fso['DeleteFile'](pn + '.uni');
			_Win.removeEventListener('beforeunload', tk);
			return text;
		},*/
		// Online szövegfájl betöltése és olvasása:
		// -- link	: url				<= string
		_ReadFile = function(link) {
			link = link.replace('file:///', '');
			// Ha a link egy fájl, akkor a teljes elérési út lekérése:
			// Ha egy webhely, akkor Cache kijátszása:
			link = (_Fso['FileExists'](link) ? String(_Fso['GetFile'](link)) : (link + '?_=' + new Date().getTime()));
			let text = '404';
			try {
				_Req.onreadystatechange = (function() {
					if ((_Req.readyState === 4) && ((_Req.status === 200) || (_Req.status === 0))) text = _Req.responseText;
				});
				_Req.open('GET', link, false);
				_Req.send(null);
			} catch(e) {}
			return text;
		},
		// Fájl / Mappa műveletek:
		// -- operation = {
		//		cmd			: parancs		<= string			( 'copy', 'move', 'del', 'rename', 'visibility' )
		//		source		: objektumok	<= string | array	( fájl, mappa )
		//		target		: célmappa		<= string			( 'copy', 'move' )
		//		newname		: új név		<= string			( 'rename' )
		//		overwrite	: true-false	<= boolean			( 'copy', 'move' )
		//		visible		: true-false	<= boolean			( 'visibility' )
		// }
		_Operation = function(op) {
			let a = "obj." + op.cmd + "(", t_folder = '';
			// Ha hiányzik a forrás:
			if (op.source === undefined) return _Win.alert(a + "source, ...)\n\nThe - source - parameter is missing !\n");
			// Másoláskor vagy mozgatáskor célmappa ellenőrzése:
			if (_Find(op.cmd, /copy|move/)) {
				if (op.overwrite === undefined) op.overwrite = true;
				if (op.target) {
					t_folder = _Env(op.target);
					if (!_Fso['FolderExists'](t_folder)) _Fso['CreateFolder'](t_folder);
				}
				else return _Win.alert(a + "source, target, overwrite)\n\nThe - target - parameter is missing !\n");
			}
			// Törléskor vagy átnevezéskor nem kell target és overwrite:
			else {
				if (op.target) return _Win.alert(a + "source, target, overwrite)\n\nExcept for copy and move,\n\nyou don't need the - target - parameter.\n");
				if (op.overwrite) return _Win.alert(a + "source, target, overwrite)\n\nExcept for copy and move,\n\nyou don't need the - overwrite - parameter.\n");
			}
			// Átnevezéskor:
			if (op.cmd === 'rename') {
				if (typeof op.newname !== 'string') return _Win.alert(a + "source, newname)\n\nThe - newname - parameter is missing !\n");
			}
			else if (op.newname) return _Win.alert(a + "source, newname)\n\nExcept for rename,\n\nyou don't need the - newname - parameter.\n");
			// Láthatóságkor:
			if (op.cmd === 'visibility') {
				if (typeof op.visible !== 'boolean') return _Win.alert(a + "source, visible)\n\nThe - visible - parameter is missing !\n\n•  true-false\n");
			}
			else if (op.visible) return _Win.alert(a + "source, visible)\n\nExcept for visibility,\n\nyou don't need the - visible - parameter.\n");
			// Műveletek:
			function operat(s_object) {
				let file = false;
				// Forrás objektum kibontása:
				s_object = _Env(s_object);
				// Ha van forrás objektum:
				if (_Exist(s_object)) {
					try {
						s_object = _Fso['GetFile'](s_object);
						file = true;
					}
					catch(e) {
						s_object = _Fso['GetFolder'](s_object);
					}
					s_object = String(s_object);
					//--------------------------------------------------+
					if (_Find(op.cmd, /copy|move/)) {
						// Cél objektum lekérése:
						let t_object = (t_folder + s_object.split("\\").pop());
						// Ha van felülírás és cél objektum:
						if (op.overwrite && _Exist(t_object)) {
							(file ? _Fso['DeleteFile'](t_object) : _Fso['DeleteFolder'](t_object));
						}
						// Ha nincs cél objektum:
						if (!_Exist(t_object)) {
							if (file) {
								if (op.cmd === 'copy') _Fso['CopyFile'](s_object, t_folder, true);
								if (op.cmd === 'move') _Fso['MoveFile'](s_object, t_folder);
							}
							else {
								if (op.cmd === 'copy') _Fso['CopyFolder'](s_object, t_folder, true);
								if (op.cmd === 'move') _Fso['MoveFolder'](s_object, t_folder);
							}
						}
					}
					//--------------------------------------------------+
					if (op.cmd === 'del') {
						(file ? _Fso['DeleteFile'](s_object) : _Fso['DeleteFolder'](s_object));
					}
					//--------------------------------------------------+
					if (op.cmd === 'rename') {
						// A név levágása a link végéről:
						let s_folder = s_object.replace(s_object.split("\\").pop(), "");
						if (!_Exist(s_folder + op.newname)) (file ? _Fso['MoveFile'](s_object, s_folder + op.newname) : _Fso['MoveFolder'](s_object, s_folder + op.newname));
					}
					//--------------------------------------------------+
					if (op.cmd === 'visibility') {
						(file ? (_Fso['GetFile'](s_object).Attributes = (op.visible ? 0 : 2)) : (_Fso['GetFolder'](s_object).Attributes = (op.visible ? 16 : 18)));
					}
				} // Ha van forrás objektum.
			} // operat()
			// Ha az objects Array:
			if (typeof op.source === 'object') {
				if (op.cmd === 'rename') return _Win.alert(a + ")\n\nOnly one object can be renamed !");
				else _LoopIn(op.source, function(key, source) { operat(source) });
			}
			// Ha az objects String:
			else if (typeof op.source === 'string') operat(op.source);
			// Ha egyik sem:
			else return _Win.alert(a + "source, ...)\n\nThe - source - parameter is missing !\n\n•  'pathname'\n•  ['pathname 1', 'pathname 2']");
		},
		// Másolás:
		// -- src		: objektumok	<= string | array ( fájl, mappa )
		// -- tgt		: célmappa		<= string ( mappa )
		// -- ow		: felülírás		<= boolean
		_Copy = function(src, tgt, ow) {
			_Operation({
				cmd: 'copy',
				source: src,
				target: tgt,
				overwrite: ow
			});
		},
		// Mozgatás:
		// -- src		: objektumok	<= string | array ( fájl, mappa )
		// -- tgt		: célmappa		<= string ( mappa )
		// -- ow		: felülírás		<= boolean
		_Move = function(src, tgt, ow) {
			_Operation({
				cmd: 'move',
				source: src,
				target: tgt,
				overwrite: ow
			});
		},
		// Törlés:
		//	-- src		: objektumok	<= string | array ( fájl, mappa )
		_DelObject = function(src) {
			_Operation({
				cmd: 'del',
				source: src
			});
		},
		// Átnevezés:
		//	-- src		: objektumok	<= string | array ( fájl, mappa )
		//	-- nn		: új név		<= string
		_Rename = function(src, nn) {
			_Operation({
				cmd: 'rename',
				source: src,
				newname: nn
			});
		},
		// Láthatóság:
		//	-- src		: objektumok	<= string | array ( fájl, mappa )
		//	-- st		: állapot		<= boolean
		_Visibility = function(src, st) {
			_Operation({
				cmd: 'visibility',
				source: src,
				visible: st
			});
		},
		//▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬//
		//		HTA																					 //
		//▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬//
		// Információk:
		// -- i		: érték				<= string
		// return	: érték				=> string
		_Info = function(i) {
			let info = {'creator': 'István Reich', 'created': '2017.02.15', 'version': '220511', 'updated': '2022.09.20'};
			return info[i];
		},
		// Fagyasztás:
		// -- ms	: milliseconds		<= number
		// return	: milliseconds		=> number
		_Freezing = function(ms) {
			let t = new Date().getTime();
			while (true) { if ((t + ms) < new Date().getTime()) break }
			return (new Date().getTime() - t);
		},
		// ActiveX vezérlők:
		// -- v		: név				<= string
		// return	: ActiveX			=> object
		_ActiveX = function(v) {
			if (!_Find(v, /\b(wss|fso|sap)\b/)) {
				_Win.alert("hta.activeX( )\n\nParameter is missing !\n\n•  'wss'\n•  'fso'\n•  'sap'\n");
				return '';
			}
			return ((v === 'fso') ? _Fso : (v === 'wss') ? _Wss : (v === 'sap') ? _Sap : {});
		},
		// Az hta fájl elérésiútjának lekérése:
		// -- m		: opciók			<= string ( 'file', 'folder', 'full' )
		// return	: link				=> string
		_PathName = function(m) {
			if (!_Find(m, /\b(file|folder|full)\b/)) {
				_Win.alert("hta.pathName( )\n\nParameter is missing !\n\n•  'file'\n•  'folder'\n•  'full'\n");
				return '';
			}
			let hta_file = _Win.location.pathname.split("\\").pop(), full = String(_Fso['GetFile'](hta_file));
			// Csak a fájl:
			if (m === 'file') return hta_file;
			// Csak a mappa:
			if (m === 'folder') return full.replace(hta_file, '');
			// Teljes link:
			if (m === 'full') return full;
		},
		// Registry fájl futtatása:
		// -- v		: fájl | szöveg		<= string
		// -- o		: megnyitás			<= boolean
		// return	: reg elérési út	=> string
		_RunReg = function(v, o) {
			let regFile;
			try { regFile = String(_Fso['GetFile'](v)) }
			catch(e) { regFile = _CreateFile('%temp%\\shl-TempRegFile.reg', v.replace(/\t/g, ''), true, true) }		// UTF-16 with BOM
			(o ? _Wss['Run']('notepad.exe "' + regFile + '"', 1, false) : _Wss['Run']('cmd.exe /c regedit.exe /s "' + regFile + '"', 0, true));
			return regFile;
		},
		// Batch fájl futtatása:
		// -- v		: fájl | szöveg		<= string
		// -- s		: kapcsoló			<= string
		// -- o		: megnyitás			<= boolean
		// return	: bat elérési út	=> string
		_RunCmd = function(v, s, o) {
			let batFile;
			try { batFile = String(_Fso['GetFile'](v)) }
			catch(e) { batFile = _CreateFile('%temp%\\shl-TempBatFile.bat', v.replace(/\t/g, ''), true) }			// UTF-8
			if (s === undefined) s = '';
			(o ? _Wss['Run']('notepad.exe "' + batFile + '"', 1, false) : _Wss['Run']('cmd.exe /c "' + batFile + '" ' + s, 0, true));
			return batFile;
		},
		// Frissítés:
		// -- url		: URL					<= string
		// -- version	: jelenlegi				<= number
		// return		: [url, version]		=> array
		_Update = function(url, version) {
			if (!version) version = 0.0;
			if (url) {
				let update = _ReadFile(url), hta_path = _PathName('full');
				if (update !== '404') {
					try {
						update = JSON.parse(update);
						if (update['latest-version'] && parseFloat(update['latest-version']) > version) _ShowMsg('confirm', update['message'], function() { // Igen funkció
							setTimeout(function() {
								// Ha van letöltés:
								if (update['download-link'] !== '') {
									let downloaded_file = _Env('%temp%\\shl-dl-file.' + update['download-ext']);
									_Download(update['download-link'], downloaded_file);
									if (_Exist(downloaded_file)) _Wss['Run']('"' + downloaded_file + '"');
									else _OkMsg(_Hun ? 'A letöltés nem sikerült!' : 'Download failed!');
								}
								// Régi átnevezése:
								_Copy(hta_path, _PathName('folder') + 'old\\');
								// HTA frissítése:
								_CreateFile(hta_path, update['hta-text'], true);
								// Weboldal megnyitása:
								if (update['web-page'] !== '') _Wss['Run']('cmd.exe /c start "" "' + update['web-page'] + '"', 0);
								// HTA újra nyitása az ablak bezárásakor:
								_Win.addEventListener('beforeunload', function() { _Wss['Run']('cmd.exe /c timeout /t 1 && start "" "' + hta_path + '"', 0) });
								// Ablak bezárása:
								_Win.close();
							}, 20);
						}, (_Hun ? 'Igen' : 'Yes'), false, (_Hun ? 'Később' : 'Later'), (url + '?_=' + new Date().getTime()));
					} catch(e) {
						_OkMsg('Update data is not available at this URL:\n\n' + url);
					}
				}
				else _OkMsg('Update data is not available at this URL:\n\n' + url);
			}
			else url = '';
			return [url, version];
		},
		// Teljesítmény idő megadása:
		// -- id		: id			<= string
		_SetPowerTimeById = function(id) {
			_PowerTime[id] = new Date().getTime();
		},
		// Teljesítmény idő lekérése:
		// -- id		: id			<= string
		// return		: millisec		=> number
		_GetPowerTimeById = function(id) {
			let t = _PowerTime[id];
			return (t ? (new Date().getTime() - t) : -1);
		},
		// Teljesítmény idő lekérése a lib megnyitásától:
		// return		: millisec		=> number
		_MainPowerTime = function() {
			return (new Date().getTime() - _MPowerTime);
		},
		// Téma beállítása:
		// -- mode		: mód			<= string 'light|dark|auto'
		// -- func		: function		<= function()
		_SetTheme = function(mode, func) {
			if (!mode) mode = 'auto';
			if (!_Find(mode, /\b(light|dark|auto)\b/)) { _Win.alert("hta.theme( mode )\n\nWrong - mode - parameter !\n\n•  'light'\n•  'dark'\n•  'auto'\n"); return null }
			// Ha világos van megadva:
			let light = (mode === 'light');
			// Ha 'auto', akkor a rendszer szerinti:
			if (mode === 'auto') { try { light = (_Wss['RegRead']('HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize\\AppsUseLightTheme').toString() === '1') } catch(e) {} }
			// Theme attribute megadása:
			_AllowedElems(function(elem) { elem.setAttr('theme', (light ? 'light' : 'dark')) });
			_LightMode = light;
			if (func) func(_LightMode);
		},
		// Téma lekérése:
		// return		: mód			=> string 'light|dark'
		_GetTheme = function() {
			return (_LightMode ? 'light' : 'dark');
		},
		// CSS átírása:
		_SetCss = function(selectorText, obj) {
			let id = _CssObject[selectorText];
			if (id) {
				let style = _Doc.styleSheets[0].cssRules[id[0]].style;
				_LoopIn(obj, function(key, value) { style[key] = value });
				_CssObject[selectorText][1] = style;
			}
		},
		// CSS lekérése:
		_GetCss = function(selectorText) {
			return _CssObject[selectorText][1];
		},
		// CSS Selector nevek lekérése:
		_GetSelectorText = function() {
			let text = '';
			_LoopIn(_CssObject, function(selectorText) { text += (selectorText + '\n') });
			return text;
		},
		// Ha van lista, akkor elrejtés:
		_HideSelectorLists = function() {
			// Az összes lista lekérése és elrejtése:	<div shl-elem="sr-lists sr-list-for-selector-1"></div>
			_LoopIn(_ShlElems('sr-lists'), function(key, tag) { tag.style.display = '' });
		},
		// Megfigyelő hozzáadása, csak egyszer:
		_AddObserver = function() {
			let global_cssText = 'body{margin:0;overflow:hidden}[shl-elem="logline-panel"]{position:absolute;font-family:"Consolas","Courier New",monospace;box-sizing:border-box;z-index:9999999}[shl-elem="logline-textarea"]{position:absolute;font-family:inherit;border:none;cursor:default;overflow:hidden;padding:2px 4px;width:calc(100% - 8px);height:calc(100% - 4px);font-size:18px;color:#eee;background-color:#457}[shl-elem~="logline-buttons"]{position:absolute;display:none;font-family:inherit;font-size:16px;padding:2px 7px;color:#222;border-radius:0.2em;background-color:#aaa}[shl-elem~="logline-buttons"]:hover{background-color:#d22;cursor:pointer;color:#fff}[shl-elem~="logline-pause"]{right:0.3em;top:0.3em}[shl-elem~="logline-clear"]{right:0.3em;top:2em}[shl-elem~="logline-pause"].deactivated{background-color:#f00}[shl-elem="fadein-layer"]{position:absolute;top:0;left:0;right:0;bottom:0;z-index:9999998;background-color:#000}[shl-elem="download-bar"]{position:absolute;display:none;font-family:inherit;left:0.2em;right:0.2em;bottom:0.2em;z-index:9999998;padding:0.5em;background-color:#ddd;color:#333}[shl-elem="msgbox-layer"]{position:absolute;display:none;top:0;left:0;right:0;bottom:0;z-index:9999997;background-color:rgba(0,0,0,0.4)}[shl-elem="msgbox-dialog"]{display:inline-block;width:auto;height:auto;box-sizing:border-box;padding:0.5em;border-radius:0.2em;box-shadow:0 0 2em rgba(0,0,0,0.5);background-color:#fff}[shl-elem="msgbox-textarea"]{display:block;font-family:inherit;font-size:inherit;padding:0;background-color:transparent;color:#333;border:none}[shl-elem~="msgbox-buttons"]{display:none;font-family:inherit;font-size:inherit;margin-left:0.5em;background-color:#ddd;border-radius:0.2em;color:#333;padding:0.1em 0.5em;transition:200ms}[shl-elem~="msgbox-buttons"]:nth-of-type(1){margin-left:0}[shl-elem~="msgbox-buttons"]:hover{background-color:#38e;color:#fff;cursor:pointer}[shl-elem~="msgbox-buttons"]:hover:active{transition:0ms;background-color:#25c;color:#fff}[shl-touch]{position:relative;overflow:hidden;vertical-align:bottom}[shl-elem="touch-effect"]{position:absolute;display:inline-block;z-index:9999995;width:20px;height:20px;border-radius:50%;background-color:#fff}[shl-elem="cb-input"]{position:relative;display:inline-block;vertical-align:bottom;height:1.3em;line-height:1.3em;padding:0 0.1em 0 1.4em;background-color:transparent}[shl-elem="cb-input"] [shl-elem="checkbox"]{position:absolute;box-sizing:border-box;width:1em;height:1em;left:0.1em;top:calc(50% - 0.5em);background-color:#fff;border:1px solid #888;border-radius:0.2em;transition:200ms}[shl-elem="cb-input"][marked="true"] [shl-elem="checkbox"]::before{position:absolute;content:"";width:0.2em;height:0.6em;left:0.25em;transform:rotate(40deg);border-width:0.2em;border-style:solid;border-left:none;border-top:none;border-color:#fff}[shl-elem="cb-input"][marked="true"]:not([deactivated="true"]){}[shl-elem="cb-input"][marked="true"]:not([deactivated="true"]) [shl-elem="checkbox"]{background-color:#38e;border-color:#38e}[shl-elem="cb-input"][deactivated="true"]{}[shl-elem="cb-input"][deactivated="true"] [shl-elem="checkbox"]{background-color:#888;border-color:#888}[shl-elem="cb-input"][marked="true"][deactivated="true"] [shl-elem="checkbox"]::before{}[shl-elem="cb-input"]:not([deactivated="true"]):hover{cursor:pointer}[shl-elem="cb-input"][marked="true"]:not([deactivated="true"]):hover{}[shl-elem="cb-input"][marked="true"]:not([deactivated="true"]):hover [shl-elem="checkbox"]{background-color:#8bf;border-color:#8bf}[shl-elem="cb-input"]:not([marked="true"]):not([deactivated="true"]):hover [shl-elem="checkbox"]{background-color:#38e;border-color:#38e}[shl-elem="cb-input"]:not([deactivated="true"]):hover:active{transition:0ms}[shl-elem="cb-input"]:not([deactivated="true"]):hover:active [shl-elem="checkbox"],[shl-elem="cb-input"]:not([deactivated="true"]) [shl-elem="checkbox"]:hover:active{transition:0ms;background-color:#25c;border-color:#25c}[shl-elem="rb-input"]{position:relative;display:inline-block;vertical-align:bottom;height:1.3em;line-height:1.3em;padding:0 0.1em 0 1.4em;background-color:transparent}[shl-elem="rb-input"] [shl-elem="radiobox"]{position:absolute;box-sizing:border-box;width:1em;height:1em;left:0.1em;top:calc(50% - 0.5em);background-color:#fff;border:1px solid #888;border-radius:50%;transition:200ms}[shl-elem="rb-input"][marked="true"]{}[shl-elem="rb-input"][marked="true"] [shl-elem="radiobox"]{background-color:#fff;border-width:0.3em;border-color:#38e}[shl-elem="rb-input"][deactivated="true"][marked="true"]{}[shl-elem="rb-input"][deactivated="true"][marked="true"] [shl-elem="radiobox"]{background-color:#fff;border-color:#888}[shl-elem="rb-input"][deactivated="true"]:not([marked="true"]){}[shl-elem="rb-input"][deactivated="true"]:not([marked="true"]) [shl-elem="radiobox"]{background-color:#888;border-color:#888}[shl-elem="rb-input"]:not([deactivated="true"]):hover{cursor:pointer}[shl-elem="rb-input"][marked="true"]:not([deactivated="true"]):hover{}[shl-elem="rb-input"][marked="true"]:not([deactivated="true"]):hover [shl-elem="radiobox"]{border-color:#8bf}[shl-elem="rb-input"]:not([marked="true"]):not([deactivated="true"]):hover [shl-elem="radiobox"]{background-color:#38e;border-color:#38e}[shl-elem="rb-input"]:not([deactivated="true"]):hover:active{transition:0ms}[shl-elem="rb-input"]:not([deactivated="true"]):hover:active [shl-elem="radiobox"],[shl-elem="rb-input"]:not([deactivated="true"]) [shl-elem="radiobox"]:hover:active{transition:0ms;background-color:#25c;border-color:#25c}[shl-elem="sr-input"]{position:relative;display:inline-block;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;vertical-align:bottom;height:1.3em;line-height:1.3em;padding:0 1em 0 0.3em;text-align:center;background-color:#fff;color:#333;border:1px solid #888;border-radius:0.2em;transition:200ms}[shl-elem="sr-input"]::after{position:absolute;content:"";box-sizing:border-box;transform:rotate(45deg);width:0.4em;height:0.4em;top:calc(50% - 0.25em);right:0.3em;border-width:0.1em;border-style:solid;border-left:none;border-top:none;border-color:#555;transition:200ms}[shl-elem="sr-input"][deactivated="true"]{background-color:#ddd;color:#555}[shl-elem="sr-input"][deactivated="true"]::after{border-color:#777}[shl-elem="sr-input"]:not([deactivated="true"]):hover{cursor:pointer;background-color:#38e;border-color:#38e;color:#fff}[shl-elem="sr-input"]:not([deactivated="true"]):hover::after{border-color:#fff}[shl-elem="sr-input"]:not([deactivated="true"]):hover:active{transition:0ms;background-color:#25c;border-color:#25c}[shl-elem="sr-input"]:not([deactivated="true"]):hover:active::after{transition:0ms}[shl-elem~="sr-lists"]{position:absolute;display:none;box-sizing:border-box;z-index:9999996;padding:0.2em;background-color:#fff;border:1px solid #888;border-radius:0.2em;box-shadow:0 0 1em rgba(0,0,0,0.6)}[shl-elem="sr-list-items"]{text-align:center;transition:200ms;height:1.3em;line-height:1.3em;padding:0.05em 0.3em;border-radius:0.2em}[shl-elem="sr-list-items"]:first-child{margin-top:0}[shl-elem="sr-list-items"]:last-child{margin-bottom:0}[shl-elem="sr-list-items"]:hover{cursor:pointer;background-color:#38e;color:#fff}';
			let minify = function(css) { return css.replace(/\r\n|\n/g, '').replace(/\/\*.*?\*\//g, '').split(/}\s*|\s*{/) };
			// Sílus összeállítása:
			_LoopIn(_Doc.styleSheets, function(key, sheet) {
				// <link rel="stylesheet" type="text/css" href="asdasd">
				if (sheet.href !== null) {
					global_cssText += _ReadFile(sheet.href);
				}
				// <style type="text/css"> Ha van rule:
				else if (sheet.cssRules[0]) {
					global_cssText += sheet.ownerNode.textContent;
				}
				sheet.ownerNode.setAttr('shl-elem', 'delete-style-link-tags');
			});
			// Minden törlése:
			_LoopIn(_ShlElems('delete-style-link-tags'), function(k, tag) { _Doc.head.removeChild(tag) });
			//----------------------------------------------------+
			// Egy új style tag készítése:
			//----------------------------------------------------+
			let global_cssTag = _Doc.createElement('style'), global_cssRules = minify(global_cssText);
			global_cssTag.setAttr('type', 'text/css');
			global_cssTag.textContent = global_cssText;
			_Doc.head.appendChild(global_cssTag);
			// CSS object:
			_LoopIn(_Doc.styleSheets[0].cssRules, function(key, rule, ruleIndex) {
				// Eredeti selectorText = [0, style];
				_CssObject[global_cssRules[ruleIndex*2]] = [ruleIndex, rule.style];
			});
			//-----------------------------------------------------------------------------------------------//
			_Win.addEventListener('mouseup', function(event) {
				if (event.button !== 0) return;
				let target = event.target;
				//	<div shl-elem="sr-input" id="selector-1" items="['itemHTML-1', 'itemHTML-2']"></div>
				//	<div shl-elem="sr-lists sr-list-for-selector-1">
				//		<div shl-elem="sr-list-items" id="selector-1-item-0">aaa</div
				//		<div shl-elem="sr-list-items" id="selector-1-item-1">bbb</div
				//		<div shl-elem="sr-list-items" id="selector-1-item-2">ccc</div
				//	</div>
				//--------------------------------------------------------------------------->
				// Ha egy item-re kattintok:
				//--------------------------------------------------------------------------->
				_Parent(target, 'shl-elem', 'sr-list-items', function(item) {
					let selector = _Doc.getElementById(item.id.split('-item-')[0]), items = JSON.parse(selector.getAttr('items'));
					// Tételekre bontás:
					_LoopPlus(items.length, function(i) {
						let itemHTML = items[i];
						// Ha a kattintott tétel HTML egyezik a listában szereplő HTML-el:
						if (_Find(itemHTML, item.textContent) && !_Find(itemHTML, selector.textContent)) {
							let func = selector.getAttr('func');
							if (func !== '') new Function("(" + func + ")('" + itemHTML.replace(/[']/g, "\\'") + "')")();
							selector.innerHTML = itemHTML;
						}
					});
				});
				//--------------------------------------------------------------------------->
				// Ha egy selector-ra kattintok:
				//--------------------------------------------------------------------------->
				_HideSelectorLists();
				_Parent(target, 'shl-elem', 'sr-input', function(selector) {
					// Ha le van tiltva:
					if (selector.getAttr('deactivated', 'true')) return;
					let delay = parseInt(selector.getAttr('shl-touch').getValue('delay:') || '300');
					function showList() {
						let list = _ShlElem('sr-list-for-' + selector.id);
						if (list.none) { _Win.alert('List is not found for "' + selector.id + '" selector !'); return null }
						// Először megjelenítés:
						list.style.display = 'inline-block';
						// Szélesség megadása:
						list.style.minWidth = (selector.offsetWidth + 'px');
						// Pozíciók lekérése:
						let selector_rect = selector.getBoundingClientRect(), list_rect = list.getBoundingClientRect(), innerW = _Win.innerWidth, innerH = _Win.innerHeight;
						// Elhelyezés:
						list.style.top = ((((selector_rect.top + list_rect.height) > innerH) ? (innerH - list_rect.height) : selector_rect.top) + 'px');
						list.style.left = ((((selector_rect.left + list_rect.width) > innerW) ? (innerW - list_rect.width) : selector_rect.left) + 'px');
						// Fadein:
						_JsTransition(500, function(v) { list.style.opacity = v });
					}
					if (selector.hasAttribute('shl-touch')) setTimeout(showList, delay); else showList();
				});
				//--------------------------------------------------------------------------->
				// Ha egy CB/RB-re kattintok:
				//--------------------------------------------------------------------------->
				_Parent(target, 'shl-elem', /(cb-input|rb-input)/, function(input) { input.change('marked') });
			});
			//-----------------------------------------------------------------------------------------------//
			_Doc.addEventListener('DOMNodeInserted', function() {
				clearTimeout(_TimerA);
				_TimerA = setTimeout(function() {
					let theme = (_LightMode ? 'light' : 'dark');
					_AllowedElems(function(elem) {
						if (!elem.getAttr('checkbox-integrated', 'true')) {
							if (elem.elemIs('cb-input')) {
								elem.innerHTML = ('<div shl-elem="checkbox" theme="' + theme + '"></div>' + elem.innerHTML);
								elem.setAttr('marked', 'false');
								elem.setAttr('deactivated', 'false');
								elem.setAttr('checkbox-integrated', 'true');
							}
							if (elem.elemIs('rb-input')) {
								elem.innerHTML = ('<div shl-elem="radiobox" theme="' + theme + '"></div>' + elem.innerHTML);
								elem.setAttr('marked', 'false');
								elem.setAttr('deactivated', 'false');
								elem.setAttr('checkbox-integrated', 'true');
							}
						}
						if (!elem.getAttr('theme', theme)) elem.setAttr('theme', theme);
					});
					clearTimeout(_TimerA);
				}, 20);
			});
		},
		// Item hozzáadása select-hez:
		// -- selId				: id		<= string
		// -- items				: items		<= array
		// -- start				: default	<= number
		//
		//	<div shl-elem="sr-input" id="selector-1" items="['itemHTML-1', 'itemHTML-2']"></div>
		//	<div shl-elem="sr-lists sr-list-for-selector-1">
		//		<div shl-elem="sr-list-items" id="selector-1-item-0">aaa</div
		//		<div shl-elem="sr-list-items" id="selector-1-item-1">bbb</div
		//		<div shl-elem="sr-list-items" id="selector-1-item-2">ccc</div
		//	</div>
		_AddListToSelector = function(selId, items, start) {
			let selector = _Doc.getElementById(selId), selList = _ShlElem('sr-list-for-' + selId), none = selList.none, list;
			// Nincs ilyen selector:
			if (!selector) return _Win.alert("hta.addListToSelector( id, ...)\n\n" + (_Hun ? "Ez az id nem található:" : "This id is not found:") + "\n\n'" + selId + "'");
			// Tiltott HTML karekterek lecserélése:
			_LoopPlus(items.length, function(i) { items[i] = items[i].replace(/\s\s*/g, ' ') });
			// Lista készítés, ha még nincs:
			if (none) {
				list = _Doc.createElement('div');
				list.setAttr('shl-elem', 'sr-lists sr-list-for-' + selId);
			}
			else list = selList;
			// Lista kiürítése:
			list.innerHTML = '';
			// Tételekre bontás:
			_LoopPlus(items.length, function(i) {
				let itemHTML = items[i];
				// Tételek integrálása a listába:
				list.innerHTML += ('<div shl-elem="sr-list-items" id="' + selId + '-item-' + i + '">' + itemHTML + '</div');
				// Kezdőérték beírása:
				if ((start || 0) === i) selector.innerHTML = itemHTML;
			});
			// Lista hozzáadása, ha még nincs:
			if (none) _Doc.body.appendChild(list);
			// Items:
			selector.setAttr('items', items);
		},
		_Style = {
			fadein: {
				layer: function(obj) { _SetCss('[shl-elem="fadein-layer"]', obj) }
			},
			touch: {
				effect: function(obj) { _SetCss('[shl-elem="touch-effect"]', obj) }
			},
			msg: {
				layer: function(obj) { _SetCss('[shl-elem="msgbox-layer"]', obj) },
				dialog: function(obj) { _SetCss('[shl-elem="msgbox-dialog"]', obj) },
				textarea: function(obj) { _SetCss('[shl-elem="msgbox-textarea"]', obj) },
				buttons: function(obj) { _SetCss('[shl-elem~="msgbox-buttons"]', obj) },
				buttonsHover: function(obj) { _SetCss('[shl-elem~="msgbox-buttons"]:hover', obj) },
				buttonsClicked: function(obj) { _SetCss('[shl-elem~="msgbox-buttons"]:hover:active', obj) }
			},
			cb: {
				input: function(obj) { _SetCss('[shl-elem="cb-input"]', obj) },
				inputBox: function(obj) { _SetCss('[shl-elem="cb-input"] [shl-elem="checkbox"]', obj) },
				inputBoxPipe: function(obj) { _SetCss('[shl-elem="cb-input"][marked="true"] [shl-elem="checkbox"]::before', obj) },
				inputDeactivatedBoxPipe: function(obj) { _SetCss('[shl-elem="cb-input"][marked="true"][deactivated="true"] [shl-elem="checkbox"]::before', obj) },
				inputHover: function(obj) { _SetCss('[shl-elem="cb-input"]:not([deactivated="true"]):hover', obj) },
				inputHoverBox: function(obj) { _SetCss('[shl-elem="cb-input"]:not([marked="true"]):not([deactivated="true"]):hover [shl-elem="checkbox"]', obj) },
				inputMarked: function(obj) { _SetCss('[shl-elem="cb-input"][marked="true"]:not([deactivated="true"])', obj) },
				inputMarkedBox: function(obj) { _SetCss('[shl-elem="cb-input"][marked="true"]:not([deactivated="true"]) [shl-elem="checkbox"]', obj) },
				inputMarkedHover: function(obj) { _SetCss('[shl-elem="cb-input"][marked="true"]:not([deactivated="true"]):hover', obj) },
				inputMarkedHoverBox: function(obj) { _SetCss('[shl-elem="cb-input"][marked="true"]:not([deactivated="true"]):hover [shl-elem="checkbox"]', obj) },
				inputClicked: function(obj) { _SetCss('[shl-elem="cb-input"]:not([deactivated="true"]):hover:active', obj) },
				inputClickedBox: function(obj) { _SetCss('[shl-elem="cb-input"]:not([deactivated="true"]):hover:active [shl-elem="checkbox"],[shl-elem="cb-input"]:not([deactivated="true"]) [shl-elem="checkbox"]:hover:active', obj) },
				inputDeactivated: function(obj) { _SetCss('[shl-elem="cb-input"][deactivated="true"]', obj) },
				inputDeactivatedBox: function(obj) { _SetCss('[shl-elem="cb-input"][deactivated="true"] [shl-elem="checkbox"]', obj) }
			},
			rb: {
				input: function(obj) { _SetCss('[shl-elem="rb-input"]', obj) },
				inputBox: function(obj) { _SetCss('[shl-elem="rb-input"] [shl-elem="radiobox"]', obj) },
				inputHover: function(obj) { _SetCss('[shl-elem="rb-input"]:not([deactivated="true"]):hover', obj) },
				inputHoverBox: function(obj) { _SetCss('[shl-elem="rb-input"]:not([marked="true"]):not([deactivated="true"]):hover [shl-elem="radiobox"]', obj) },
				inputMarked: function(obj) { _SetCss('[shl-elem="rb-input"][marked="true"]', obj) },
				inputMarkedBox: function(obj) { _SetCss('[shl-elem="rb-input"][marked="true"] [shl-elem="radiobox"]', obj) },
				inputMarkedHover: function(obj) { _SetCss('[shl-elem="rb-input"][marked="true"]:not([deactivated="true"]):hover', obj) },
				inputMarkedHoverBox: function(obj) { _SetCss('[shl-elem="rb-input"][marked="true"]:not([deactivated="true"]):hover [shl-elem="radiobox"]', obj) },
				inputClicked: function(obj) { _SetCss('[shl-elem="rb-input"]:not([deactivated="true"]):hover:active', obj) },
				inputClickedBox: function(obj) { _SetCss('[shl-elem="rb-input"]:not([deactivated="true"]):hover:active [shl-elem="radiobox"],[shl-elem="rb-input"]:not([deactivated="true"]) [shl-elem="radiobox"]:hover:active', obj) },
				inputMarkedDeactivated: function(obj) { _SetCss('[shl-elem="rb-input"][deactivated="true"][marked="true"]', obj) },
				inputMarkedDeactivatedBox: function(obj) { _SetCss('[shl-elem="rb-input"][deactivated="true"][marked="true"] [shl-elem="radiobox"]', obj) },
				inputDeactivated: function(obj) { _SetCss('[shl-elem="rb-input"][deactivated="true"]:not([marked="true"])', obj) },
				inputDeactivatedBox: function(obj) { _SetCss('[shl-elem="rb-input"][deactivated="true"]:not([marked="true"]) [shl-elem="radiobox"]', obj) }
			},
			sr: {
				input: function(obj) { _SetCss('[shl-elem="sr-input"]', obj) },
				inputArrow: function(obj) { _SetCss('[shl-elem="sr-input"]::after', obj) },
				inputHover: function(obj) { _SetCss('[shl-elem="sr-input"]:not([deactivated="true"]):hover', obj) },
				inputHoverArrow: function(obj) { _SetCss('[shl-elem="sr-input"]:not([deactivated="true"]):hover::after', obj) },
				inputClicked: function(obj) { _SetCss('[shl-elem="sr-input"]:not([deactivated="true"]):hover:active', obj) },
				inputClickedArrow: function(obj) { _SetCss('[shl-elem="sr-input"]:not([deactivated="true"]):hover:active::after', obj) },
				inputDeactivated: function(obj) { _SetCss('[shl-elem="sr-input"][deactivated="true"]', obj) },
				inputDeactivatedArrow: function(obj) { _SetCss('[shl-elem="sr-input"][deactivated="true"]::after', obj) },
				inputList: function(obj) { _SetCss('[shl-elem~="sr-lists"]', obj) },
				inputListItem: function(obj) { _SetCss('[shl-elem="sr-list-items"]', obj) },
				inputListItemHover: function(obj) { _SetCss('[shl-elem="sr-list-items"]:hover', obj) }
			}
		},
		//▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬//
		//		Logline																				 //
		//▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬//
		// Logline törlés-gomb igazítása:
		_LogDelButtonAlign = function() {
			let ta = _ShlElem('logline-textarea'), right = ('calc(' + (ta.offsetWidth - ta.clientWidth) + 'px + 0.3em)');
			_ShlElem('logline-pause').style.right = right;
			_ShlElem('logline-clear').style.right = right;
		},
		// Logline írása:
		// -- text		: text			<= string
		// return		: text			=> string
		_LogAdd = function(text) {
			if (arguments.length > 0) {
				if (_LoglineEnabled) {
					_LoglineText += (String(text) + '\n');
					if (_TimerB === -1) _TimerB = setTimeout(function() {
						let ta = _ShlElem('logline-textarea');
						if (ta.none) return;
						let rows = _LoglineText.replace(/\n+$/, '').replace(/\t/g, '   ').split('\n');
						ta.value = rows.slice(((rows.length > _LogRows) ? (rows.length - _LogRows) : 0), rows.length).join('\n');
						ta.scrollTop = ta.scrollHeight;
						_LogDelButtonAlign();
						_TimerB = -1;
					}, _LogRefresh);
				}
				else {
					clearTimeout(_TimerB);
					_TimerB = -1;
				}
			}
			return _LoglineText;
		},
		// Logline szöveg törlése:
		_LogClear = function() {
			_LoglineText = '';
			_ShlElem('logline-textarea').value = _LoglineText;
			_LogDelButtonAlign();
		},
		// Log szüneteltetése, ha textarea:
		_LogPause = function() {
			_LoglineEnabled = !_LoglineEnabled;
			_ShlElem('logline-pause').classList.toggle('deactivated');
		},
		//▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬//
		//		Window																				 //
		//▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬//
		// HTA ablak megnyitása:
		//	wo = {
		//		icon		: 'xyz.ico'				<= string			( 'link/to/icon' )
		//		title		: 'My Title'			<= string
		//		type		: 'tool',				<= string			( 'tool', 'fixed', 'default', 'max', 'full' )
		//		titlebar	: true,					<= string/boolean	( 'id', true, false )
		//		width		: '600px',				<= string/number
		//		height 		: '400px',				<= string/number
		//		top			: '100px',				<= string/number
		//		left		: '100px',				<= string/number
		//		fadein		: [500, 200],			<= array			[ duration, delay ]
		//		logline		: ['bottom', 0, 100]	<= array			[ 'bottom / right', max, update rate ]
		//		theme		: 'auto'				<= string			( 'light', 'dark', 'auto' )
		//	}
		_Open = function(wo, onFunc) {
			// Ha az open a HEAD-ben van:
			if (!_Doc.body) {
				_Win.alert("wnd.open( {} )\n\nUse this function in script tag in body !");
				_Win.close();
			}
			// Kilépés, ha az ablak már meg van nyitva:
			if (_Opened) return _Win.alert("Use the wnd.open( {} )\n\nfunction only once !");
			_Opened = true;
			// Ablak cím ellenőrzése:
			if (typeof wo['title'] !== 'string') {
				_Win.alert("wnd.open( {} )\n\nThe - title: - parameter is missing !");
				_Win.close();
			}
			// Ablaktípus ellenőrzés:
			if (!wo['type'] || !_Find(wo['type'], /\b(tool|fixed|default|max|full)\b/)) {
				_Win.alert("wnd.open( {} )\n\nThe - type: - parameter is missing !\n\n•  'tool'\n•  'fixed'\n•  'default'\n•  'max'\n•  'full'\n");
				_Win.close();
			}
			// 'tool' és 'fixed' állapotban:
			else if (_Find(wo['type'], /tool|fixed/)) {
				// Fejléc ellenőrzés:
				if (wo['titlebar'] === undefined) {
					_Win.alert("wnd.open( {} )\n\nThe - titlebar: - parameter is missing !\n\n•  true\n•  false\n•  'id'\n");
					_Win.close();
				}
			}
			// 'default':
			else if (wo['type'] === 'default') {
				if (wo['titlebar'] !== undefined) _Win.alert("wnd.open( {} )\n\nIf the window type is 'default' then\n - titlebar: - parameter is not required.\n");
				wo['titlebar'] = true;
			}
			// 'max' és 'full' állapotban a fejléc és méretek elhagyása:
			else if ((wo['titlebar'] !== undefined) || wo['width'] || wo['height'] || wo['left'] || wo['top']) {
				_Win.alert("wnd.open( {} )\n\nIf the window type is 'max' or 'full' then\n\n•  titlebar:\n•  width:\n•  height:\n•  top:\n•  left:\n\nvalues are not required.\n");
			}
			// Logline ellenőrzése, ha van:
			if (wo['logline'] && (typeof wo['logline'] !== 'object')) {
				_Win.alert("wnd.open( {} )\n\nWrong - logline: - parameter !\n\n•  ['bottom']\n•  ['right']\n•  ['bottom', 100]\n•  ['right', 100]\n");
				_Win.close();
			}
			//==================================================================================
			// title tag kezelése:
			//==================================================================================
			let title_text = ((wo['title'][0] === "!") ? wo['title'].substring(1, wo['title'].length) : wo['title']);
			// Lekérése, ha van:
			let title_tag = _Doc.getElementsByTagName('title')[0];
			// Felülírás, ha van vagy integrálás:
			(title_tag ? (title_tag.textContent = title_text) : _Doc.head.innerHTML += ('<title>' + title_text + '</title>'));
			// Az ablak cím írása az egyedi fejlécbe:
			if (typeof wo['titlebar'] === 'string') {
				let tb = _Doc.getElementById(wo['titlebar']);
				if (!tb) {
					_Win.alert("wnd.open( {} )\n\nCannot find the \"" + wo['titlebar'] + "\" id for title bar !");
					_Win.close();
				}
				// Ha nem ! -el kezdődik, akkor felülírja a fejlécet:
				else if (wo['title'][0] !== "!") tb.textContent = title_text;
			}
			//==================================================================================
			// HTML tag-ek összeállítása:
			//==================================================================================
			let html = '';
			// Minimize:
			// noinspection HtmlUnknownAttribute
			html += '<object shl-elem="minimize-object" c\lassid="clsid:adb880a6-d8ff-11cf-9377-00aa003b7a11" style="display:none;"><param name="command" value="minimize"></object>';
			// Maximize:
			// noinspection HtmlUnknownAttribute
			html += '<object shl-elem="maximize-object" c\lassid="clsid:adb880a6-d8ff-11cf-9377-00aa003b7a11" style="display:none;"><param name="command" value="maximize"></object>';
			// Msg box:
			html += '<div shl-elem="msgbox-layer">';
			html += 	'<div shl-elem="msgbox-dialog">';
			html += 		'<textarea shl-elem="msgbox-textarea" wrap="off" onfocus="this.blur();" readonly></textarea>';
			html += 		'<div shl-elem="msgbox-buttons-block" style="display:inline-block;white-space:nowrap;float:right;">';
			html +=				'<a href="#" shl-elem="msgbox-update-link" target="_blank" style="display:none;font-size:0.8em;margin-right:1em;" onmouseover="this.style.color=\'#36f\'" onmouseout="this.style.color=\'#999\'">' + (_Hun ? 'Részletek' : 'Details') + '</a>';
			html += 			'<div shl-elem="msgbox-buttons msgbox-button-1"></div>';
			html += 			'<div shl-elem="msgbox-buttons msgbox-button-2"></div>';
			html += 		'</div>';
			html += 	'</div>';
			html += '</div>';
			html += '<div shl-elem="download-bar">' + (_Hun ? 'Fájl letöltése folyamatban...' : 'File download in progress...') + '</div>';
			// Fade-in bg:
			if (wo['fadein']) html += '<div shl-elem="fadein-layer"></div>';
			// Logline:
			if (wo['logline']) {
				html += '<div shl-elem="logline-panel">';
				html += 	'<textarea shl-elem="logline-textarea" wrap="off" onfocus="this.blur()" readonly></textarea>';
				html += 	'<div shl-elem="logline-buttons logline-pause">' + (_Hun ? 'Szünet' : 'Pause') + '</div>';
				html += 	'<div shl-elem="logline-buttons logline-clear">' + (_Hun ? 'Törlés' : 'Clear') + '</div>';
				html += '</div>';
			}
			// tag-ek integrálása:
			_Doc.body.innerHTML += html;
			//==================================================================================
			// Windows app theme lekérése:
			//==================================================================================
			_SetTheme(wo['theme']);
			//==================================================================================
			// Observer hozzáadása:
			//==================================================================================
			_AddObserver();
			//==================================================================================
			// Méretek beállítása:
			//==================================================================================
			// Teljes képernyőn:
			if (wo['type'] === "full") _OuterSize = [_Win.screen.width, _Win.screen.height];
			// Max ablakon a border és méret megadása:
			else if (wo['type'] === "max") {
				_Border[0] = (_Win.outerWidth - _Win.innerWidth);
				_Border[1] = (_Win.outerHeight - _Win.innerHeight);
				_OuterSize[0] = (_Win.screen.availWidth + _Border[0]);
				_OuterSize[1] = (_Win.screen.availHeight + _Border[0]);
			}
			// Kis ablaknál méret és offset megadása:
			else if (_Find(wo['type'], /tool|fixed|default/)) {
				// Ha van Windows fejléc, akkor az ablakkeret vastagságának megadása:
				if (wo['titlebar'] === true) {
					_Border[0] = (_Win.outerWidth - _Win.innerWidth);
					_Border[1] = (_Win.outerHeight - _Win.innerHeight);
				}
				// Ha alapértelmezett, a pozíció mentése az ablak bezárásakor:
				if (wo['type'] === 'default') {
					try {
						let dt = _Wss['RegRead']('HKCU\\Software\\Shl\\WindowPosition\: ' + title_text).split(' | '), size = dt[0].split('x'), offs = dt[1].split('x');
						wo['width'] = parseInt(size[0]);
						wo['height'] = parseInt(size[1]);
						wo['top'] = parseInt(offs[0]);
						wo['left'] = parseInt(offs[1]);
					} catch(e) {}
					_Win.addEventListener('beforeunload', function() { _Wss['RegWrite']('HKCU\\Software\\Shl\\WindowPosition\: ' + title_text, _Win.innerWidth + 'x' + _Win.innerHeight + ' | ' + _Win.screenY + 'x' + _Win.screenX, 'REG_SZ') });
				}
				// Méret átalakítása:
				wo['width'] = _ConvertSize(wo['width'], 'width');
				wo['height'] = _ConvertSize(wo['height'], 'height');
				// Ablakméret felülírása, ha nagyobb, mint a képméret:
				if (wo['width'] > _Win.screen.width) wo['width'] = _Win.screen.width;
				if (wo['height'] > _Win.screen.height) wo['height'] = _Win.screen.height;
				// Globális külső méret:
				_OuterSize[0] = (wo['width'] + _Border[0]);
				_OuterSize[1] = (wo['height'] + _Border[1]);
				// Offset megadása:
				_Offset[0] = Math.round((wo['left'] !== undefined) ? _ConvertSize(wo['left'], 'width') : ((_Win.screen.width - _OuterSize[0]) * 0.5));
				_Offset[1] = Math.round((wo['top'] !== undefined) ? _ConvertSize(wo['top'], 'height') : ((_Win.screen.height - _OuterSize[1]) * 0.5));
			}
			//==================================================================================
			// Logline beállítása:
			//==================================================================================
			if (wo['logline']) {
				let expanded = false, llp = _ShlElem('logline-panel'), llt, llc, lls;
				// Limit értékek:
				_LogRows = (wo['logline'][1] === undefined ? 100 : (wo['logline'][1] < 1 ? 1 : wo['logline'][1]));
				_LogRefresh = (wo['logline'][2] === undefined ? 20 : (wo['logline'][2] < 20 ? 20 : wo['logline'][2]));
				//---------------------------------------//
				// Elhelyezés:
				//---------------------------------------//
				// Lent:
				if (wo['logline'][0] === 'bottom') {
					llp.style.width = '100%';
					llp.style.height = '30px';
					llp.style.bottom = '0px';
					llp.style[(wo['titlebar'] === true) ? 'borderTop' : 'border'] = '2px solid #aaa';
				}
				// Jobbra:
				else if (wo['logline'][0] === 'right') {
					llp.style.width = '30px';
					llp.style.height = '100%';
					llp.style.right = '0px';
					llp.style[(wo['titlebar'] === true) ? 'borderLeft' : 'border'] = '2px solid #aaa';
				}
				else {
					_Win.alert("wnd.open( {} )\n\nWrong - logline: - parameter !\n\n•  ['bottom']\n•  ['right']\n•  ['bottom', 100]\n•  ['right', 100]\n");
					_Win.close();
				}
				//---------------------------------------//
				// Kibontás-összecsukás:
				//---------------------------------------//
				_Win.addEventListener('mousemove', function(e) {
					if (_TitleBarClicked) return;
					// noinspection JSUnresolvedVariable
					if (e.target.elemIs && e.target.elemIs('logline')) {
						if (!expanded) {
							llp = _ShlElem('logline-panel');
							llt = _ShlElem('logline-textarea');
							llc = _ShlElem('logline-clear');
							lls = _ShlElem('logline-pause');
							llt.style.overflow = 'auto';
							llc.style.display = 'inline-block';
							lls.style.display = 'inline-block';
							llc.onclick = _LogClear;
							lls.onclick = _LogPause;
							llp.style[(wo['logline'][0] === 'bottom') ? 'height' : 'width'] = 'calc(100% - 30px)';
							_Win.requestAnimationFrame(_LogDelButtonAlign);
							expanded = true;
						}
					}
					else if (expanded) {
						_ShlElem('logline-textarea').style.overflow = 'hidden';
						_ShlElem('logline-clear').style.display = 'none';
						_ShlElem('logline-pause').style.display = 'none';
						_ShlElem('logline-panel').style[(wo['logline'][0] === 'bottom') ? 'height' : 'width'] = '30px';
						expanded = false;
					}
				});
			}
			//==================================================================================
			// HTA beállítása:
			//==================================================================================
			_HTAtag.setAttr('icon', (wo['icon'] ? wo['icon'] : ''));
			_HTAtag.setAttr('id', 'shl-app-id-' + title_text.replace(/\s/g, '-'));
			_HTAtag.setAttr('applicationname', title_text);
			_HTAtag.setAttr('singleinstance', 'yes');
			_HTAtag.setAttr('innerborder', 'no');
			_HTAtag.setAttr('scroll', 'no');
			_HTAtag.setAttr('selection', 'no');
			_HTAtag.setAttr('contextmenu', 'yes');
			// Border kezelése:
			function borderState(state) {
				switch (state) {
					case 'fixed': _HTAtag.setAttr('border', 'thin'); break;
					case 'hidden': _HTAtag.setAttr('caption', 'no'); _HTAtag.setAttr('border', 'none');
				}
			}
			// Ablak kezelése:
			function windowState(state) {
				switch (state) {
					case 'maximized': _HTAtag.setAttr('windowstate', 'maximize'); break;
					case 'min-close': _HTAtag.setAttr('border', 'thin'); _HTAtag.setAttr('maximizebutton', 'no'); break;
					case 'close': _HTAtag.setAttr('border', 'thin'); _HTAtag.setAttr('maximizebutton', 'no'); _HTAtag.setAttr('minimizebutton', 'no');
				}
			}
			// Típus bontása:
			switch (wo['type']) {
				case 'tool':
					((wo['titlebar'] === true) ? windowState('close') : borderState('hidden'));
					break;
				case 'fixed':
					((wo['titlebar'] === true) ? windowState('min-close') : borderState('hidden'));
					break;
				case 'default':
					borderState('normal');
					windowState('normal');
					break;
				case 'max':
					borderState('normal');
					windowState('maximized');
					break;
				case 'full':
					borderState('hidden');
					windowState('normal');
			}
			// hta tag integrálása a head-be:
			_Doc.head.appendChild(_HTAtag);
			//==================================================================================
			// Az ablak indítása:
			//==================================================================================
			function windowStarting() {
				//------------------------------+
				// Ablak aktiválása:
				_Win.focus();
				//------------------------------+
				// A select tag-ek deaktiválása:
				_Win.addEventListener('blur', _HideSelectorLists);
				//------------------------------+
				// Egyedi fejléc:
				//------------------------------+
				if (_Find(wo['type'], /tool|fixed/) && (typeof wo['titlebar'] === 'string')) {
					// Fejléc műveletek:
					let barBg, barC, posX = 0, posY = 0, bar = _Doc.getElementById(wo['titlebar']);
					bar.addEventListener('mouseup', function() { _TitleBarClicked = false });
					bar.addEventListener('mousedown', function() { _TitleBarClicked = true });
					_Win.addEventListener('mousemove', function(e) {
						if (_TitleBarClicked) {
							_Offset[0] += (e.pageX - posX);
							_Offset[0] = Math.round(_Offset[0]);
							_Offset[1] += (e.pageY - posY);
							_Offset[1] = Math.round(_Offset[1]);
							_Win.moveTo(_Offset[0], _Offset[1]);
						}
						else {
							posX = e.pageX;
							posY = e.pageY;
						}
					});
					// onBlur:
					_Win.addEventListener('blur', function() {
						barBg = bar['currentStyle']["background-color"];
						barC = bar['currentStyle']["color"];
						bar.style.backgroundColor = '#fff';
						bar.style.color = '#aaa';
					});
					// onFocus:
					_Win.addEventListener('focus', function() {
						bar.style.backgroundColor = barBg;
						bar.style.color = barC;
					});
				}
				//------------------------------+
				// Érintés hatás:
				//------------------------------+
				_Win.addEventListener('mousedown', function(cursor) {
					// Bal-klikk a gombra:
					if (cursor.button === 0) _Parent(cursor.target, 'shl-touch', '', function(parent) {
						// deactivated és SVG nem működik:
						if (parent.getAttr('deactivated', 'true') || !parent.elemIs) return;
						// Az előző törlése:
						let effect = _ShlElem('touch-effect');
						if (!effect.none) effect.parentElement.removeChild(effect);
						// Új megadása:
						parent.innerHTML = ('<div shl-elem="touch-effect"></div>' + parent.innerHTML);
						effect = _ShlElem('touch-effect');
						// Pozíciók lekérése:
						let top = Math.round(cursor.clientY - (parent.offsetTop + parent.clientTop)),
							left = Math.round(cursor.clientX - (parent.offsetLeft + parent.clientLeft)),
							duration = (parent.getAttr('shl-touch').getValue('dur:') || '700'),
							delay = (parent.getAttr('shl-touch').getValue('delay:') || '300');
						// Animálás:
						_JsTransition(duration, function(v) { effect.setAttr('style', (v === 1) ? 'display:none;' : ('top:' + top + 'px;left:' + left + 'px;transform:translate(-50%,-50%)rotate(' + (v * 360) + 'deg)scale(' + (1 + (v * 6)) + ');opacity:' + (1 - v))) });
						// OnMouseUp késleltetése:
						let mouseup = parent.getAttr('onmouseup');
						if ((mouseup !== '') && mouseup.indexOf('setTimeout') !== 0) {
							mouseup = ('setTimeout(function(){' + mouseup + '},' + delay + ')');
							parent.setAttr('onmouseup', mouseup);
						}
					});
				});
				//------------------------------+
				// Fade-in és indítás:
				//------------------------------+
				// Ha van fadein:
				if (wo['fadein']) {
					setTimeout(function() {
						let fiLayer = _ShlElem('fadein-layer');
						_JsTransition(wo['fadein'][0], function(v) {
							fiLayer.style.opacity = (1 - v).toString();
							if (v === 1) { fiLayer.style.display = 'none'; _IsFaded = true }
						});
					}, (wo['fadein'][1] || 0));
				}
				// Ha nincs, akkor elindult:
				else _Win.requestAnimationFrame(function() { _IsFaded = true });
			}
			//==================================================================================
			// Ablak megnyitása:
			//==================================================================================
			// Méretezés:
			let sizing = function() {}, sized = false, titlebar = false, taskbarPosition = function() {
				// Az ablak méretezése 2 x 2 re és mozgatása valamelyik sarokba:
				_Win.resizeTo(2, 2);
				_Win.moveTo(0, 0);
				// Tálca pozició lekérése binárisként és újra beírása szövegként:
				_Wss['Run']('cmd.exe /c set "value=00000000000000000000000000000" && (for /f "tokens=3" %a in (\'reg query "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StuckRects3" /v "Settings"\') do reg add "HKCU\\Software\\Shl" /v "TaskbarPosition" /t "REG_SZ" /d %a /f)', 0, true);
				// Pozi lekérése szövegként:
				let tbpos;
				try { tbpos = _Wss['RegRead']('HKCU\\Software\\Shl\\TaskbarPosition')[25] } catch(e) { tbpos = '0' }
				// Az ablak mozgatása:	bal-alsó								 jobb-felső:
				(_Find('0 3', tbpos) ? _Win.moveTo(0, _Win.screen.height - 2) : _Win.moveTo(_Win.screen.width - 2, 0));
				// Majd újraméretezés:
				sizing = function() {
					if (sized) return null;
					_Freezing(500);
					_Win.resizeTo(_OuterSize[0], _OuterSize[1]);
					_Win.moveTo(_Offset[0], _Offset[1]);
					sized = true;
				};
			};
			// Teljesképernyőn:
			if (wo['type'] === 'full') taskbarPosition();
			// Kisméreten:
			else if (_Find(wo['type'], /tool|fixed|default/)) {
				// Ha van fejléc, akkor azonnal méretezés, nem szabad késleltetni!
				if (wo['titlebar'] === true) {
					titlebar = true;
					_Win.resizeTo(_OuterSize[0], _OuterSize[1]);
					_Win.moveTo(_Offset[0], _Offset[1]);
				}
				// Ha nincs fejléc:
				else taskbarPosition();
			}
			else titlebar = true;
			// Ha document betöltött:
			_Doc.addEventListener('DOMContentLoaded', function() {
				_DoOnFrame(function(frame) {
					if (!titlebar && (frame < 5)) return false;
					sizing();
					if ((_Win.outerWidth === _OuterSize[0]) && (_Win.outerHeight === _OuterSize[1])) {
						_IsOpen = true;
						return true;
					}
					return false;
				});
			});
			//==================================================================================
			// Ha megnyilt az ablak, várakozás a betöltődésre:
			//==================================================================================
			_Win.addEventListener('load', function() {
				_DoOnFrame(function() {
					// Open 0
					if (_IsOpen) {
						_Win.requestAnimationFrame(function() {
							// Load +1
							_IsLoaded = true;
							// Ready +2
							windowStarting();
						});
						return true;
					}
					return false;
				});
			});
			//==================================================================================
			// Funkciók lefuttatása:
			//==================================================================================
			if (onFunc) {
				let opened = undefined, loaded = undefined, faded = undefined;
				_DoOnFrame(function() {
					if (opened === undefined && _IsOpen) opened = true;
					else if (opened) opened = false;
					if (loaded === undefined && _IsLoaded) loaded = true;
					else if (loaded) loaded = false;
					if (faded === undefined && _IsFaded) faded = true;
					else if (faded) faded = false;
					onFunc(opened, loaded, faded);
					if (_IsFaded) return true;
				});
			}
		},
		// Ha megnyilt az ablak, +2 frame a futtatástól:
		// -- func		: funkció		<= function()
		_OnOpen = function(func) {
			_DoOnFrame(function() {
				if (_IsOpen) { func(); return true }
				return false;
			});
		},
		// Ha betöltött az ablak, +2 frame a futtatástól:
		// -- func		: funkció		<= function()
		_OnLoad = function(func) {
			_DoOnFrame(function() {
				if (_IsLoaded) { func(); return true }
				return false;
			});
		},
		// Ha az ablak fadein befejezte, +3 frame a futtatástól, ha nincs 'fadein':
		// -- func		: funkció		<= function()
		_OnFaded = function(func) {
			_DoOnFrame(function() {
				if (_IsFaded) { func(); return true }
				return false;
			});
		},
		// Animált frame-en:
		// -- func		: funkció		<= function()
		_OnFrame = function(func) {
			let f = 0;
			_DoOnFrame(function() {
				if (_IsOpen) { func(f); f++ }
				return false;
			});
		},
		// Tick-en:
		// -- func		: funkció		<= function()
		_OnTick = function(func) {
			let t = 0;
			setInterval(function() {
				if (_IsOpen) { func(t); t++ }
			}, 15);
		},
		// Offset lekérés:
		// return		: offset		=> array
		_GetOffset = function() {
			if (_IsOpen) _Offset = [_Win.screenX, _Win.screenY];
			return _Offset.slice();
		},
		// Offset megadása:
		// -- x			: balról / tömb		<= number | array
		// -- y			: fentről			<= number
		_SetOffset = function(x, y) {
			// Ha nincs parameter, akkor középre igazítás:
			if (arguments.length === 0) {
				x = ((_Win.screen.width / 2) - (_OuterSize[0] / 2));
				y = ((_Win.screen.height / 2) - (_OuterSize[1] / 2));
			}
			// Array:
			else if (typeof x === 'object') {
				y = (x[1] ? x[1] : 0);
				x = (x[0] ? x[0] : 0);
			}
			else if (!y) y = '0px';
			x = _ConvertSize(x, 'width');
			y = _ConvertSize(y, 'height');
			// Offset kerekítve:
			_Offset[0] = Math.round(x);
			_Offset[1] = Math.round(y);
			_Win.moveTo(_Offset[0], _Offset[1]);
		},
		// Ablak belső méret lekérése:
		// return		: méret				=> array
		_GetSize = function() {
			if (_IsOpen) _OuterSize = [_Win.outerWidth, _Win.outerHeight];
			return [_OuterSize[0] - _Border[0], _OuterSize[1] - _Border[1]];
		},
		// Ablak belső méret megadása:
		// -- x			: szélesség / tömb	<= number | array
		// -- y			: magasság			<= number
		// -- c			: középre			<= boolean
		_SetSize = function(x, y, c) {
			// Ha nincs paraméter, akkor riasztás:
			if (arguments.length === 0) return _Win.alert("wnd.setSize()\n\nParameter is missing !\n\n•  array | number");
			// Array:
			if (typeof x === 'object') {
				y = (x[1] ? x[1] : 0);
				x = (x[0] ? x[0] : 0);
			}
			else if (!y) y = '0px';
			x = _ConvertSize(x, 'width');
			y = _ConvertSize(y, 'height');
			// Ablakméret felülírása, ha nagyobb, mint a képméret:
			if (x > _Win.screen.width) x = _Win.screen.width;
			if (y > _Win.screen.height) y = _Win.screen.height;
			// Belső méret növelése a kerettel:
			x += _Border[0];
			y += _Border[1];
			// Külső méret, kerekítve:
			_OuterSize[0] = Math.round(x);
			_OuterSize[1] = Math.round(y);
			_Win.resizeTo(_OuterSize[0], _OuterSize[1]);
			// Középre igazítás:
			if ((c === undefined) ? true : c) _SetOffset();
		},
		// Ablakkeret vastagságának lekérése:
		// -- v			: value					<= string ( 'lrb', 'top' )
		// return		: széles, vastag		=> array | number
		_BorderSize = function(v) {
			return (v ? ((v === 'lrb') ? (_Border[0] / 2) : ((v === 'top') ? (_Border[1] - (_Border[0] / 2)) : 0)) : _Border.slice());
		},
		// Ablak műveletek:
		// -- cmd		: parancs				<= string
		_Cmd = function(cmd) {
			if ((!cmd) || !_Find(cmd, /\b(min|restore|close)\b/)) return _Win.alert("wnd.cmd(cmd)\n\nThe - cmd - parameter is missing !\n\n•  'min'\n•  'restore'\n•  'close'\n");
			if ((cmd === 'min') && !_HTAtag.getAttr('minimizebutton', 'no')) _ShlElem('minimize-object')['Click']();
			if ((cmd === 'restore') && !_HTAtag.getAttr('maximizebutton', 'no')) _ShlElem('maximize-object')['Click']();
			if (cmd === 'close') _Win.close();
		},
		// DPI lekérése:
		// return		: factor				=> number ( 1, 1.25, 1.5 )
		_DpiFactor = function() {
			let dpi;
			try { dpi = (Math.round(_Wss['RegRead']('HKCU\\Control Panel\\Desktop\\LogPixels')) / 96) } catch(e) { dpi = 1.0 }
			return dpi;
		},
		// Ablakpozíció törlése a Registry-ből:
		// -- t			: ablak cím				<= string
		_DelPos = function(t) {
			try { _Wss['RegDelete']('HKCU\\Software\\Shl\\WindowPosition\: ' + t) } catch(e) {}
		};
		//==================================================================================
		// let vége
		//==================================================================================

	//----------------------------------------------------+
	// 64-bites rendszer javítása:
	//----------------------------------------------------+
	if (_X64()) {
		let syswow64_cmd = _Env('%SystemRoot%\\Sysnative\\cmd.exe');
		// Ha SysWow64 nyitja:
		if (_Exist(syswow64_cmd)) {
			// Nyitó parancs tiltása:
			_Open = function(w) {};
			_OnOpen = function(f) {};
			// Képernyőn kívülre rakás:
			_Win.resizeTo(100,100);
			_Win.moveTo(-300,-300);
			// Újranyitás 32-ben:
			_Wss['Run'](syswow64_cmd + ' /c (timeout /t 1) && (' + _Env('%SystemRoot%\\System32\\mshta.exe') + ' "' + _PathName('full') + '")', 0, false);
			_Win.close();
		}
		else if (!_Find(_Wss['RegRead']('HKCR\\htafile\\Shell\\Open\\Command\\'), 'System32')) _OnFaded(function() { _Wss['Run']('cmd.exe /c Reg Add HKCR\\htafile\\Shell\\Open\\Command /ve /d "' + _Env('%SystemRoot%\\System32\\mshta.exe') + ' \\"\%1\\"" /f', 0, false) });
	}
	//----------------------------------------------------+
	// Shl adatok lekérése:
	//----------------------------------------------------+
	_Doc.addEventListener('keydown', function(e) {
		// About:
		if (e.key === 'F1') _OkMsg((_Hun ? "Shl legutóbbi frissítése:\n" : "Shl latest update:\n") + _Info('updated') + "\n\n" + (_Hun ? "Verzió:\n" : "Version:\n") + _Info('version'));
		// Kilépés:
		if (e.key === 'Esc') _Win.close();
	});
	//----------------------------------------------------+
	// Library összeállítása:
	//----------------------------------------------------+
	_Win.SuperHtaLibrary = function() {
		this['msg'] = {
			ok: _OkMsg,
			confirm: _ConfirmMsg
		};
		this['obj'] = {
			taskkill: _TaskKill,
			env: _Env,
			exist: _Exist,
			createFile: _CreateFile,
			createFolder: _CreateFolder,
			unZip: _UnZip,
			download: _Download,
			readFile: _ReadFile,
			copy: _Copy,
			move: _Move,
			del: _DelObject,
			rename: _Rename,
			visibility: _Visibility
		};
		this['hta'] = {
			find: _Find,
			loopIn: _LoopIn,
			loopPlus: _LoopPlus,
			loopMinus: _LoopMinus,
			info: _Info,
			freezing: _Freezing,
			activeX: _ActiveX,
			x64: _X64,
			pathName: _PathName,
			runReg: _RunReg,
			runCmd: _RunCmd,
			update: _Update,
			addListToSelector: _AddListToSelector,
			hideSelectorLists: _HideSelectorLists,
			setPowerTimeById: _SetPowerTimeById,
			getPowerTimeById: _GetPowerTimeById,
			mainPowerTime: _MainPowerTime,
			setTheme: _SetTheme,
			getTheme: _GetTheme,
			setCss: _SetCss,
			getCss: _GetCss,
			getSelectorText: _GetSelectorText
		};
		this['log'] = {
			add: _LogAdd,
			clear: _LogClear,
			pause: _LogPause
		};
		this['wnd'] = {
			open: _Open,
			onOpen: _OnOpen,
			onLoad: _OnLoad,
			onFaded: _OnFaded,
			onFrame: _OnFrame,
			onTick: _OnTick,
			getOffset: _GetOffset,
			setOffset: _SetOffset,
			getSize: _GetSize,
			setSize: _SetSize,
			border: _BorderSize,
			cmd: _Cmd,
			dpiFactor: _DpiFactor,
			delPos: _DelPos
		};
		this['elem'] = {
			class: _Class,
			id: _Id
		};
		this['style'] = _Style;
	};

})(window, window.document);

