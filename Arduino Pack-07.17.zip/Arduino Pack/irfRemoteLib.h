#ifndef __IRFRemote_h__
#define __IRFRemote_h__ 1

class IRFRemote {

private:

	uint32_t
		g_signal_mcrs		= 0,
		g_end_mcrs			= 0,
		g_code				= 0,
		s_signal_mcrs		= 0,
		s_last_code			= -1,
		s_pulse_mcrs		= 0,
		f_end_mcrs			= 0,
		f_last_mcrs			= 0,
		f_long_mcrs			= 0,
		f_last_code			= 0,
		f_long_code			= 0;

	uint8_t
		g_signal_state		= 0,
		g_bit_counter		= 32,
		g_started_state		= 2,
		s_signal_state		= 0,
		s_bit_counter		= 32,
		s_send_counter		= 0,
		f_counter			= 0,
		f_once				= 0,
		_Remote_pin			= 0;

	bool _Set_code = false;

public:


	void init(uint8_t pin, uint8_t mode)
	{
		pinModeFast(pin, mode);
		_Set_code = (mode == OUTPUT);
		_Remote_pin = pin;
	}


	//-----------------------------------------------------------------------------------//


	IRFRemote(uint8_t pin = 0, uint8_t mode = 0)
	{
		if (pin > 0) init(pin, mode);
	}


	//-----------------------------------------------------------------------------------//


	void setCode(uint32_t mcrs, uint32_t &code, uint8_t times = 1)
	{
		if (!_Set_code) return;

		// Változáskor reset:
		if (s_last_code != code)
		{
			fastWrite(_Remote_pin, 0);
			s_signal_mcrs	= 0;
			s_pulse_mcrs	= 500;
			s_bit_counter	= 32;
			s_send_counter	= 0;
			s_signal_state	= 0;
			s_last_code		= code;
		}

		// Továbbengedés, ha van kód:
		if (code == 0) return;

		// Ha a pulse nagyobb, mint a szélesség:
		if (uint32_t(mcrs - s_signal_mcrs) < s_pulse_mcrs) return;

		s_signal_mcrs = mcrs;

		if (s_signal_state)
		{
			// Az utolsó   pulse_mcrs:500  és  bit_counter:255 !
			if (s_bit_counter > 32)
			{
				// Ha a számláló elérte a limitet:
				if ((++s_send_counter) == times)
				{
					code = 0;
					s_send_counter = 0;
				}
				// Vagy újrakezdés, mintha 32 lenne:
				else
				{
					s_pulse_mcrs = 10000;
					s_bit_counter = 31;
				}
			}
			else
			{
				// Kezdőérték:
				if (s_bit_counter == 32) s_pulse_mcrs = 10000;
				else
				{
					// Encoding:
					uint8_t bit = bitRead(s_last_code, s_bit_counter);
					s_pulse_mcrs = (bit ? 1400 : 350);
				}
				s_bit_counter--; // 255
			}

			s_signal_state = 0;
		}
		else
		{
			s_pulse_mcrs = 500;
			s_signal_state = 1;
		}

		fastWrite(_Remote_pin, s_signal_state);
	}


	//-----------------------------------------------------------------------------------//


	uint32_t getCode(uint32_t mcrs)
	{
		if (_Set_code) return 0;

		uint8_t state = fastRead(_Remote_pin);
		uint32_t return_code = 0;


		// IR -------------------------------------------- IR
		if (state == 0)
		{
			if (g_signal_state)
			{
					uint32_t pulse_mcrs = (mcrs - g_signal_mcrs);

					// Start:
					if (pulse_mcrs > 3000)
					{
						if (g_started_state > 0)
						{
							if (g_bit_counter <= 8)
								return_code		= g_code;
							g_end_mcrs			= mcrs;
							// g_code			= 0;	// Infránál ezt nem szabad,
							// g_bit_counter	= 32;	// mert nem biztos, hogy ismétli a kódot.
							g_started_state		= 1;
						}
					}
					// Decoding:
					else if (g_bit_counter > 0 and g_started_state == 1 and pulse_mcrs < 2000)
					{
						bitWrite(g_code, (--g_bit_counter), (pulse_mcrs > 1000));
					}

					g_signal_mcrs = mcrs;
					g_signal_state = 0;
			}
		}
		// RF -------------------------------------------- RF
		else if (!g_signal_state)
		{
					uint32_t pulse_mcrs = (mcrs - g_signal_mcrs);

					// Reset on RF noise:
					if (pulse_mcrs < 200)
					{
						if (g_started_state < 2)
						{
							g_code				= 0;
							g_bit_counter		= 32;
							g_end_mcrs			= 0;
							g_started_state		= 2;
						}
					}
					// Start:
					else if (pulse_mcrs > 3000)
					{
						if (g_started_state != 1)
						{
							if (g_bit_counter <= 8)
								return_code		= g_code;
							g_end_mcrs			= mcrs;
							g_code				= 0;
							g_bit_counter		= 32;
							g_started_state		= 0;
						}
					}
					// Decoding:
					else if (g_bit_counter > 0 and g_started_state == 0 and pulse_mcrs < 2000)
					{
						bitWrite(g_code, (--g_bit_counter), (pulse_mcrs > 600));
					}

					g_signal_mcrs = mcrs;
					g_signal_state = 1;
		}


		// Gomb felengedése után: (120ms)
		if (g_end_mcrs and uint32_t(mcrs - g_end_mcrs) > 120000)
		{
			if (g_bit_counter <= 8)
				return_code		= g_code;
			g_code				= 0;
			g_bit_counter		= 32;
			g_started_state		= 2;
			g_end_mcrs			= 0;
		}

		return return_code;
	}


	//-----------------------------------------------------------------------------------//


	uint32_t safetyCode(uint32_t mcrs, bool long_press = false, uint32_t code = 1)
	{
		// Ha nincs kód, akkor megadás:
		if (code == 1) code = getCode(mcrs);

		uint32_t return_code = 0, runtime_mcrs = (mcrs - f_last_mcrs);
		f_last_mcrs = mcrs;

		// Ha nincs semmi, akkor kilépés, hogy kevesebb legyen a futásidő:
		if (code == 0 and f_end_mcrs == 0) return 0;


		// Gomb nyomásakor:
		if (code)
		{
			f_end_mcrs += uint32_t(mcrs - f_end_mcrs);

			if (f_counter < 3)
			{
				if (f_last_code != code)
				{
					f_counter = 0;
					f_last_code = code;
				}
				if (f_counter == 2)
				{
					if (long_press)
					{
						if (!f_once)
						{
							f_long_mcrs += uint32_t(mcrs - f_long_mcrs);
							f_once = 1;
						}
						f_long_code = code;
					}
					else
					{
						f_long_mcrs = 0;
						return_code = code;
					}
				}
				f_counter++;
			}
			// Hosszúnál nullázni kell, hogy a legutóbbi kód érvényesüljön:
			if (f_counter == 3 and long_press) f_counter = 0;
		}


		// Futásidő hozzáadása:
		if (runtime_mcrs > 200)
		{
			if (f_end_mcrs) f_end_mcrs += uint32_t(mcrs - f_end_mcrs);
			if (f_long_mcrs) f_long_mcrs += uint32_t(mcrs - f_long_mcrs);
		}


		// Gomb felengedése után: (120ms)
		if (f_end_mcrs and uint32_t(mcrs - f_end_mcrs) > 120000)
		{
			f_once			= 0;
			f_counter		= 0;
			f_long_code		= 0;
			f_last_code		= 0;
			f_long_mcrs		= 0;
			f_end_mcrs		= 0;
		}
		// Gomb hosszú nyomása közben: (400ms)
		else if (f_long_mcrs and uint32_t(mcrs - f_long_mcrs) > 400000)
		{
			return_code		= f_long_code;
			f_long_code		= 0;
			f_long_mcrs		= 0;
		}

		return return_code;
	}

};

#endif
