(new ActiveXObject('WScript.Shell')).Run('"C:\\Program Files\\Apps\\WU Switcher\\app\\wu.bat" daily', 0, false);
