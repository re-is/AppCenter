#ifndef __WiFiRemote_h__
#define __WiFiRemote_h__ 1

#include <WiFi.h>
#include <ESPmDNS.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <LittleFS.h>

//-----------------------------------------------//

AsyncWebServer wifiremote_server(80);
AsyncWebSocket wifiremote_socket("/ws");

String wifiremote_index_html, WFR_ID, WFR_RESULT;

//-----------------------------------------------//

class WiFiRemote {
private:

	uint32_t reconnect_ms = 0, message_ms = 0;
	uint16_t lux_limit_a = 0, lux_limit_b = 0;
	bool disconnected = true, station_mode = false, enable_orientation = false, result = false, rssi_s = false;
	int rssi_switch = 1, rssi_avg[10], rssi_counter = 0;

	void initServer() {

		// If used the "data/index.html" file:
		if (wifiremote_index_html == "") {
			LittleFS.begin(true);
			File file = LittleFS.open("/index.html");
			delay(1000);
			wifiremote_index_html = file.readString();
		}

		// Add JS library:
		wifiremote_index_html.replace("</head>", "<script>"
			"((w)=>{w.websocket=new WebSocket(`ws://${w.location.hostname}/ws`);w.websocket.a"
			"ddEventListener('open',()=>{w.websocket.send('onOpen')});w.websocket.addEventLis"
			"tener('message',(e)=>{let m=e.data;if(m.indexOf('js:')===0)new Function(m.substr"
			"ing(3))()});w.S=(sel,res)=>{let e=document.querySelector(sel);if(e&&res)e.setAtt"
			"ribute('result',res);return e};w.android||={lightLimits:(x,y)=>{},orientation:()"
			"=>{},rssiSwitch:(x)=>{}};w.addEventListener('click',(e)=>{let res=(e.target.getA"
			"ttribute('result')||'');if(res==='')return;if(w.websocket.readyState!==1)return "
			"w.location.reload(true);w.websocket.send(`${e.target.id} ${res}`)},{passive:false})})(window);"
			+ (lux_limit_a ? "android.lightLimits(" + String(lux_limit_a) + "," + String(lux_limit_b) + ");" : "")
			+ (enable_orientation ? "android.orientation();" : "")
			+ ((!station_mode && rssi_switch < 1) ? + "android.rssiSwitch(" + String(rssi_switch) + ");" : "") +
			"</script>\n</head>");

		wifiremote_socket.onEvent([](AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type, void *arg, uint8_t *data, size_t length) {
			switch (type) {
			case WS_EVT_CONNECT:
				Serial.printf("WebSocket client #%u connected from %s\n", client->id(), client->remoteIP().toString().c_str());
				break;
			case WS_EVT_DISCONNECT:
				Serial.printf("WebSocket client #%u disconnected\n", client->id());
				break;
			case WS_EVT_DATA:
				if (length > 0) {
					data[length] = 0;
					bool res = false;
					for (int i = 0; i < length; i++) {
						char chr = data[i];
						if (chr == ' ') res = true;
						else if (res) WFR_RESULT += chr;
						else WFR_ID += chr;
					}
				}
				break;
			}
		});

		wifiremote_server.addHandler(&wifiremote_socket);
		wifiremote_server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) { request->send(200, "text/html", wifiremote_index_html.c_str()); });
		wifiremote_server.begin();
	}

public:

	// --- Access Point mode,
	// Create Access Point. IP: 192.168.100.1
	void create(const char *ssid, const char *password) {
		WiFi.mode(WIFI_AP);
		IPAddress ip1(192, 168, 100, 1);
		IPAddress ip2(255, 255, 255, 0);
		WiFi.softAPConfig(ip1, ip1, ip2);
		WiFi.softAP(ssid, password);
		initServer();
		MDNS.begin("esp");
		Serial.printf("WebServer\n  - Host: http://esp.local\n  - IP: http://%s\n", ip1.toString().c_str());
	}

	// --- Station mode,
	// Connect to Access Point. IP: dynamic.dynamic.dynamic.1
	void connect(const char *ssid, const char *password) {
		station_mode = true;
		WiFi.mode(WIFI_STA);
		WiFi.begin(ssid, password);
		initServer();
	}

	//-----------------------------------------------//



	WiFiRemote(String html = "") {
		if (html != "") wifiremote_index_html = html;
	}



	// Send websocket Response-message to all clients:
	void send(String text) {
		wifiremote_socket.textAll(text);
	}



	// JavaScript evaluation in all clients:
	void evalJS(String javascript) {
		send("js:" + javascript);
	}



	// Client websocket Request:
	bool onMessage() {
		wifiremote_socket.cleanupClients();

		// STA mode:
		if (station_mode) {
			uint32_t ms = millis();
			if (uint32_t(ms - message_ms) >= 100) {
				// CONNECTION LOST:
				if (WiFi.status() != WL_CONNECTED) {
					if (!disconnected) {
						WFR_ID = "";
						IPAddress ip(0, 0, 0, 0);
						WiFi.config(ip);
						MDNS.end();
						Serial.println(F("WiFi connection lost !"));
						disconnected = true;
					}
					// Reconnect by 5 seconds interval:
					if (uint32_t(ms - reconnect_ms) >= 5000) {
						WiFi.reconnect();
						reconnect_ms = ms;
					}
				}
				else if (disconnected) {
					IPAddress gw = WiFi.gatewayIP();
					IPAddress ip(gw[0], gw[1], gw[2], 1);
					WiFi.config(ip);
					MDNS.begin("esp");
					Serial.printf("WebServer\n  - Host: http://esp.local\n  - IP: http://%s\n", ip.toString().c_str());
					disconnected = false;
				}
				// RSSI
				if (rssi_switch < 1) {

					rssi_avg[rssi_counter] = WiFi.RSSI();

					if (++rssi_counter == 10) rssi_counter = 0;

					int avg = 0;
					for (int i = 0; i < 10; ++i) {
						if (rssi_avg[i] < 0) avg += rssi_avg[i];
					}
					avg /= 10;

					if (rssi_switch == 0) {
						WFR_ID = "RSSI";
						WFR_RESULT = String(avg);
					}
					else if (avg > rssi_switch) {
						if (!rssi_s) {
							WFR_ID = "RSSI";
							WFR_RESULT = "ON";
							rssi_s = true;
						}
					}
					else if (avg < rssi_switch * 1.2) {
						if (rssi_s) {
							WFR_ID = "RSSI";
							WFR_RESULT = "OFF";
							rssi_s = false;
						}
					}
				}

				message_ms = ms;
			}
		}

		if (WFR_ID != "") {
			if (result) {
				WFR_ID = "";
				WFR_RESULT = "";
				result = false;
			}
			else result = true;
		}

		return result;
	}



	// Light-sensor for MobileApp:
	void lightSensor(uint16_t limitA = 0, uint16_t limitB = 0) {
		if (limitA == 0) {
			lux_limit_a = 1;
			return;
		}
		lux_limit_a = limitA;
		lux_limit_b = limitB;
	}

	// Gravity-sensor for MobileApp:
	void orientationSensor() {
		enable_orientation = true;
	}

	// Switch by RSSI:
	void rssiSwitch(int limit = 0) {
		rssi_switch = limit;
	}

};

#endif
