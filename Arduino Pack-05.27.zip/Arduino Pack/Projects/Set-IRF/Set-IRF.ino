#include "C:/Program Files/Apps/Arduino Pack/pinoutLib.h"
#include "C:/Program Files/Apps/Arduino Pack/irfRemoteLib.h"

IRFremote <NANO_D3, SET_CODE> remoteRF;

void setup() {

	remoteRF.init();

	Serial.begin(1000000);

	uint32_t microsec, code;

	for (ever) {

		microsec = micros();

		if (microsec % 5000000 < 50) code = 12345678;



		remote.setCode(microsec, code, 3);
	}
}
