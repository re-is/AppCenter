(function js_min() {

	var js_file = 'wifiremote.js';
	var fso = new ActiveXObject('Scripting.FileSystemObject');
	var opened_text_file = fso.OpenTextFile(js_file, 1);
	var text = opened_text_file.ReadAll(); opened_text_file.Close();

	text = text.replace(/(^|[\s;])\/\/.*$/gm, '');
	text = text.replace(/\r\n|\t/g, '');
	text = text.replace(/[/][*].*[*][/]/g, '');
	text = text.replace(/\B\s|\s\B/g, '');
	text = text.replace(/\;\}/g, '}');
	text = text.replace(/\}\$/g, '\} \$');

	var min = fso.CreateTextFile('w-----------------------temp.txt', true);
	min.Write('const char wifiremote_js[] PROGMEM = R"js(' + text + ')js";');
	min.Close();

})();
