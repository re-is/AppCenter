#include "C:/Program Files/Apps/Arduino Pack/pinoutLib.h"
#include "C:/Program Files/Apps/Arduino Pack/wifiRemoteLib.h"

WiFiRemote wfr;

// Saved value's:
uint8_t
	led_grn_pin = 21,
	led_red_pin = 19,
	saved_grn_value = 0,
	saved_red_value = 0;


void setup() {

	pinMode(led_grn_pin, OUTPUT);
	pinMode(led_red_pin, OUTPUT);
	digitalWrite(led_grn_pin, saved_grn_value);
	digitalWrite(led_red_pin, saved_red_value);

	// Start ----------------------------------->
	Serial.begin(115200);

	// Sensor limits:
	//wfr.lightSensor(20, 50);
	//wfr.orientationSensor();
	//wfr.rssiSwitch(-40);

	// Station mode
	// Mobile / Router		ssid & password:
	wfr.connect("Mi Hazánk, 2026", "tda8560q");

	// AccessPoint mode
	// ESP / Arduino		ssid & password:
	//wfr.create("ESP32-Hotspot", "tda8560q");

	//------------------------------------------>
	for (ever) {

		if (wfr.onMessage()) {

			if (wfr.id == "RSSI_ID") Serial.println(wfr.result);

			if (wfr.id == "LIGHT_ID") {
				Serial.println("Light sensor: " + wfr.result);
			}

			if (wfr.id == "ORIENTATION_ID") {
				Serial.println("Orientation: " + wfr.result);
			}

			if (wfr.id == "led-grn") {
				saved_grn_value = (wfr.result == "off");
			}

			if (wfr.id == "led-red") {
				saved_red_value = (wfr.result == "off");
			}

			//--------------------------------------------------------------------------//

			digitalWrite(led_grn_pin, saved_grn_value);
			digitalWrite(led_red_pin, saved_red_value);

			wfr.evalJS(
				"S('#led-grn', " + String(saved_grn_value ? "'on'" : "'off'") + ");"
				"S('#led-red', " + String(saved_red_value ? "'on'" : "'off'") + ");"
			);
		}




		if (millis() % 1000 == 0) {

			wfr.evalJS("S('#wifi-strength').innerText = '" + String(WiFi.RSSI()) + "';");

		}
	}
}
