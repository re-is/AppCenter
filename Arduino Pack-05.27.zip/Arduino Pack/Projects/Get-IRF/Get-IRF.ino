#include "C:/Program Files/Apps/Arduino Pack/pinoutLib.h"
#include "C:/Program Files/Apps/Arduino Pack/irfRemoteLib.h"

IRFremote <NANO_D3, GET_CODE> remoteRF;
IRFremote <NANO_D5, GET_CODE> remoteIR;

void setup() {

	remoteRF.init();
	remoteIR.init();

	Serial.begin(1000000);

	uint32_t microsec, codeRF, codeIR;

	for (ever) {

		microsec = micros();

		codeRF = remoteRF.getCode(microsec);
		codeIR = remoteIR.getCode(microsec);

		if (codeRF) Serial.println(codeRF);
		if (codeIR) Serial.println(codeIR);

		/*
		uint32_t code = remoteRF.safetyCode(microsec);

		if (code) Serial.println(code);


		if (code == 4087716608) {
			Serial.println("A");
		}
		if (code == 4087717376) {
			Serial.println("B");
		}
		if (code == 4087715584) {
			Serial.println("C");
		}
		if (code == 4087717120) {
			Serial.println("D");
		}*/
	}
}
