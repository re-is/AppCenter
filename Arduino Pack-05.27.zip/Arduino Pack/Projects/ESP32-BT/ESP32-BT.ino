#include "C:\Program Files\Apps\Arduino pack\pinoutLib.h"
#include "C:\Program Files\Apps\Arduino pack\bluetoothLib.h"

void setup() {

	// LEDs --------------------------->
	uint8_t led_grn = 21, led_red = 19;
	pinMode(led_grn, OUTPUT);
	pinMode(led_red, OUTPUT);
	digitalWrite(led_grn, 0);
	digitalWrite(led_red, 0);

	// Start -------------------------->
	Serial.begin(115200);
	SerialBT.begin("ESP32-device");

	for (ever) {

		if (Serial.available()) {
			SerialBT.write(Serial.read());
		}

		if (SerialBT.available()) {
			Serial.write(SerialBT.read());
		}

		bool connected = SerialBT.connected();
		digitalWrite(led_grn, connected);
		digitalWrite(led_red, !connected);

		delay(20);
	}
}
