#ifndef __GeneraLib_h__
#define __GeneraLib_h__ 1

struct GeneraLib {



	template <uint32_t tempo>
	class LOOP {
	private:
		uint32_t last_mcrs = 0, cycle_time = 0;
	public:

		inline bool run(uint32_t mcrs) {
			// Ciklus:
			cycle_time = (mcrs - last_mcrs);
			// Üzem közben:
			if (cycle_time < tempo) return false;
			// Léptetés: Az aktuális micro-hoz !
			last_mcrs += ((cycle_time - tempo < 50) ? tempo : cycle_time);
			return true;
		}
	};



	template <uint8_t pin>
	class PWM {
	private:

		bool inited = false;
		uint32_t
			last_mcrs = 0,
			cycle_time = 0,
			tempo = 0,
			duty_time = 0;

	public:

		void init() {
			pinModeFast(pin, OUTPUT);
			digitalWriteFast(pin, 0);
			inited = true;
		}

		inline void run(uint32_t mcrs, uint16_t freq, uint8_t duty) {
			if (!inited) return;
			cycle_time = (mcrs - last_mcrs);
			tempo = (1000000 / MINMAX(freq, 1, 2000));
			duty_time = ((tempo * MINMAX(duty, 0, 100)) / 100);
			// Üzem közben:
			if (cycle_time < tempo) {
				digitalWriteFast(pin, (cycle_time < duty_time));
				return;
			}
			// Léptetés: Az aktuális micro-hoz !
			last_mcrs += ((cycle_time - tempo < 50) ? tempo : cycle_time);
		}

		inline void stop() {
			if (inited) digitalWriteFast(pin, 0);
		}
	};



	template <uint8_t limit>
	class AVG {
		static_assert(limit > 2 and limit < 60, "AVG -> limit must be 0-60 !\n<60>");
	private:
		uint16_t arr[limit], count = 0, sum = 0;
	public:

		void init() {
			for (uint8_t i = 0; i < limit; i++) arr[i] = 0;
		}

		inline uint16_t calc(uint16_t num) {
			sum -= arr[count];
			arr[count] = num;
			sum += num;
			if (++count == limit) count = 0;
			return (sum / limit);
		}

	};



	void delayMicros(uint32_t n) {
		uint32_t m = micros();
		while (m + n > micros());
	}

	void readSerial(String &res) {
		#if defined( ARDUINO_ARCH_AVR ) && defined( UDR0 )
			if (res != "") res = "";
			if (Serial.available() == 0) return;
			static uint16_t speed = 65000;
			if (speed == 65000) {
				Serial.print("Speed checking");
				uint32_t mic = micros();
				for (uint8_t i = 0; i < 100; i++) Serial.print(i < 99 ? "." : "\n");
				speed = ((micros() - mic) / 48); // 34000 : 300 baudrate
			}
			for (ever) {
				if (speed > 50) delayMicros(speed);
				uint8_t decimal = Serial.read();
				if (BETWEEN(decimal, 31, 123)) res += String(char(decimal));
				if (decimal == 255) break;
			}
		#endif
	}



	void reset(uint8_t pin, uint8_t hour = 1) {
		static uint8_t counter = 0;
		static uint32_t last_millis = 0;
		uint32_t cycle_time = (millis() - last_millis), limit = 3600000;
		if (cycle_time < limit) return;
		last_millis += ((cycle_time - limit < 2) ? limit : cycle_time);
		if (++counter < hour) return;
		digitalWrite(pin, HIGH);
		while(1);
	}
};

#endif
