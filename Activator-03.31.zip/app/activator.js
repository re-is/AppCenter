(function() {

	// Helyi változók:
	var
		app_folder = 'C:\\Program Files\\Apps\\Activator\\app',
		fso = new ActiveXObject('Scripting.FileSystemObject'),
		wss = new ActiveXObject('WScript.Shell'),
		date = new Date(),
		auto = false,
		lastTick = 0,
		currentTick = date.getTime(),
		activated = (date.getFullYear() + '.' + ('0' + (date.getMonth() + 1)).slice(-2) + '.' + ('0' + date.getDate()).slice(-2));


	// Kapcsoló ellenőrzése:
	// Ha van, akkor automatikus. Ha nincs, akkor kézi aktiválás.
	try { auto = (WScript.Arguments(0) === 'auto') } catch(e) {}


	// Idő lekérése:
	try { lastTick = Number(wss.RegRead('HKCU\\Software\\Apps\\MicrosoftActivator')) } catch(e) {}


	// Ha kézi vagy ha eltelt 30 nap:
	if (!auto || (currentTick > (lastTick + (1000 * 60 * 60 * 24 * 30)))) {

		// Aktiváló futtatása:
		wss.Run('"' + app_folder + '\\activator.bat"' + (auto ? ' auto' : ''), (auto ? 0 : 1), true);
		// Adat fájl készítése:
		var f = fso.CreateTextFile(app_folder + '\\Last Activation.txt', true, false);
		f.WriteLine('Utolsó aktiválás: ' + activated);
		f.Close();

		wss.RegWrite('HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run\\MicrosoftActivator', 'C:\\Windows\\System32\\wscript.exe "' + app_folder + '\\activator.js" auto', 'REG_SZ');
		wss.RegWrite('HKCU\\Software\\Apps\\MicrosoftActivator', currentTick, 'REG_SZ');

	}

})();
