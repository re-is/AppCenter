(function() {

	var wss = new ActiveXObject('WScript.Shell'),
		app_folder = 'C:\\Program Files\\Apps\\Activator\\app',
		activator_js = ('"' + app_folder + '\\activator.js"'),
		activator_bat = ('"' + app_folder + '\\activator.bat"');

	wss.RegWrite('HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run\\MicrosoftActivator',
		'"C:\\Windows\\System32\\wscript.exe" ' + activator_js, 'REG_SZ');

	wss.Run(activator_bat, 0, false);

})();
