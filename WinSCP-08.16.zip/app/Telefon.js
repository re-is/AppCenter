(function() {

	var file = 'C:\\temp.txt', fso = new ActiveXObject('Scripting.FileSystemObject'), wss = new ActiveXObject('WScript.Shell');
	// Get IP:
	wss.Run('cmd.exe /c ipconfig > "' + file + '"', 0, true);
	// Open temp file:
	var opened_file = fso.OpenTextFile(file, 1);
	// Get Wi-fi DNS address:
	var rows = opened_file.ReadAll().split('\n'), ip = rows[rows.length-2].replace(/\s*/g, '');
	// Close temp file:
	opened_file.Close();
	// Delete:
	fso.DeleteFile(file);
	// Run WinSCP.exe:
	wss.Run('"C:\\Program Files\\Apps\\WinSCP\\app\\WinSCP.exe" "ftp://anonymous:anonymous@' + ip + ':2221/"');

})();
