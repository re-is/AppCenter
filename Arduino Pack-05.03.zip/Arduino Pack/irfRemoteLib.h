#ifndef __IRFRemote_h__

class IRFRemote {

private:

	uint8_t remote_pin = 0, default_state = 2;
	bool set_code = false;


	void waitForDefaultState(uint32_t mcrs) {

		static uint32_t signal_mcrs = 0, remote_mcrs = 0, state_summary = 0, state_counter = 0, signal = 0;
		uint8_t state = fastRead(remote_pin);

		if (state == 0) {
			if (signal) {
				signal_mcrs = mcrs;
				signal = 0;
			}
		}
		else if (!signal) {
			uint32_t pulse_mcrs = (mcrs - signal_mcrs);

			if (pulse_mcrs > 3000) {
				if (!remote_mcrs) remote_mcrs = mcrs;
			}
			else if (pulse_mcrs < 200) {
				state_summary = 0;
				state_counter = 0;
				remote_mcrs = 0;
			}

			signal = 1;
		}

		if (remote_mcrs) {
			state_summary += state;
			state_counter++;

			if (uint32_t(mcrs - remote_mcrs) > 120000) {
				state_counter /= 2;
				default_state = (state_summary > state_counter);
				Serial.println(String(default_state ? "IR" : "RF") + " receiver detected.");
				state_summary = 0;
				state_counter = 0;
				remote_mcrs = 0;
			}
		}
	}


public:


	void init(uint8_t pin, uint8_t mode, uint8_t state = 2) {
		if (remote_pin) return;
		pinModeFast(pin, mode);
		set_code = (mode == OUTPUT);
		if (state < 2) default_state = state;
		remote_pin = pin;
	}


	//-----------------------------------------------------------------------------------//


	IRFRemote(uint8_t pin = 0, uint8_t mode = 0, int state = -1) {
		if (pin > 0) init(pin, mode, state);
	}


	//-----------------------------------------------------------------------------------//


	void setCode(uint32_t mcrs, uint32_t &code, uint8_t limit = 1) {
		if (!set_code) return;

		static uint32_t last_code = -1, signal_mcrs = 0, pulse_mcrs = 0;
		static uint8_t bit_counter = 0, send_counter = 0, signal = 0;

		// Változáskor reset:
		if (last_code != code) {
			fastWrite(remote_pin, 0);
			signal_mcrs = 0;
			pulse_mcrs = 500;
			bit_counter = 32;
			send_counter = 0;
			signal = 0;
			last_code = code;
		}

		// Továbbengedés, ha van kód:
		if (code == 0) return;

		// Ha a pulse nagyobb, mint a szélesség:
		if (uint32_t(mcrs - signal_mcrs) < pulse_mcrs) return;
		signal_mcrs = mcrs;

		if (signal) {

			// Az utolsó   pulse_mcrs:500  és  bit_counter:255 !
			if (bit_counter > 32) {
				// Ha a számláló elérte a limitet:
				if ((++send_counter) == limit) {
					code = 0;
					send_counter = 0;
				}
				// Vagy újrakezdés, mintha 32 lenne:
				else {
					pulse_mcrs = 10000;
					bit_counter = 31;
				}
			}
			else {
				// Kezdőérték:
				if (bit_counter == 32) pulse_mcrs = 10000;
				else {
					// Encoding, 32-bit: 31 -> 0
					uint8_t bit = bitRead(last_code, bit_counter);
					pulse_mcrs = (bit ? 1000 : 400);
				}
				bit_counter--; // 255
			}

			signal = 0;
		}
		else {
			pulse_mcrs = 500;
			signal = 1;
		}

		fastWrite(remote_pin, signal);
	}


	//-----------------------------------------------------------------------------------//


	uint32_t getCode(uint32_t mcrs) {
		if (set_code) return 0;

		if (default_state == 2) {
			waitForDefaultState(mcrs);
			return 0;
		}

		static uint32_t signal_mcrs = 0, end_mcrs = 0, code = 0;
		static uint8_t bit_counter = 32, signal = 0;

		uint32_t return_code = 0;

		if (fastRead(remote_pin) == default_state) {
			if (signal) {
				signal_mcrs = mcrs;
				signal = 0;
			}
		}
		else if (!signal) {
			uint32_t pulse_mcrs = (mcrs - signal_mcrs);

			// Start or Reset:
			if (pulse_mcrs > 3000) {
				if (bit_counter <= 8) return_code = code; // Result
				if (default_state == 0) bit_counter = 32; // RF reset
				end_mcrs = mcrs;
			}
			else if (end_mcrs) {
				// Reset on RF noise:
				if (pulse_mcrs < 200) {
					bit_counter = 32;
					code = 0;
					end_mcrs = 0;
				}
				// Decoding:
				else if (pulse_mcrs < 2000 and bit_counter > 0) {
					if (bit_counter == 32) code = 0;
					bitWrite(code, (--bit_counter), (pulse_mcrs > (default_state ? 1000 : 550)));
				}
			}

			signal = 1;
		}

		// Ha felengedtem a gombot:
		if (end_mcrs and uint32_t(mcrs - end_mcrs) > 120000) {
			if (bit_counter <= 8) return_code = code;
			bit_counter = 32;
			code = 0;
			end_mcrs = 0;
		}

		return return_code;
	}


	//-----------------------------------------------------------------------------------//


	uint32_t safetyCode(uint32_t mcrs, bool long_press = false, uint32_t code = 1) {
		if (code == 1) code = getCode(mcrs);

		static uint32_t end_mcrs = 0, code_mcrs = 0, last_mcrs = 0, last_code = 0, long_return_code = 0, counter = 0, sent = 0;

		uint32_t return_code = 0, runtime_mcrs = (mcrs - last_mcrs);

		// Ha nincs semmi, akkor kilépés, hogy kevesebb legyen a futásidő:
		if (code == 0 and end_mcrs == 0) return 0;

		// Futásidő hozzáadása:
		if (runtime_mcrs > 1000) {
			end_mcrs += runtime_mcrs;
			code_mcrs += runtime_mcrs;
		}
		last_mcrs = mcrs;

		// Gomb nyomásakor:
		if (code) {
			end_mcrs = mcrs;
			if (counter < 3) {
				if (last_code != code) {
					counter = 0;
					last_code = code;
				}
				if (counter == 2) {
					if (long_press) {
						// Csak egyszer !
						if (sent == 0) {
							code_mcrs = mcrs;
							sent = 1;
						}
						long_return_code = code;
					}
					else {
						code_mcrs = 0;
						return_code = code;
					}
				}
				counter++;
			}
			// Hosszúnál nullázni kell, hogy a legutóbbi kód érvényesüljön:
			if (long_press and counter == 3) counter = 0;
		}
		// Gomb felengedése után: (120ms)
		else if (end_mcrs and uint32_t(mcrs - end_mcrs) > 120000) {
			sent = 0;
			counter = 0;
			long_return_code = 0;
			last_code = 0;
			code_mcrs = 0;
			end_mcrs = 0;
		}
		// Gomb hosszú nyomása közben: (400ms)
		else if (code_mcrs and uint32_t(mcrs - code_mcrs) > 400000) {
			return_code = long_return_code;
			long_return_code = 0;
			code_mcrs = 0;
		}

		return return_code;
	}

};

#define __IRFRemote_h__ 1
#endif
