#ifndef __WiFiRemote_h__

#include <WiFi.h>

//-----------------------------------------------//

NetworkClient wifiremote_client;
NetworkServer wifiremote_server(80);
IPAddress wifiremote_server_ip(192, 168, 0, 100);
IPAddress wifiremote_subnet_ip(255, 255, 255, 0);
IPAddress wifiremote_reset_ip(0, 0, 0, 0);
uint32_t WFR_RESULTS[2];

//-----------------------------------------------//

class WiFiRemote {
private:

	uint32_t reconnect_millis = 0, min_lux = 0, max_lux = 0, update_seconds = 0;
	bool disconnected = true, station_mode = false;
	const char *style, *body;

public:

	// Init:
	WiFiRemote(const char *html_style, const char *html_body) {
		style = html_style;
		body = html_body;
	}

	//-----------------------------------------------//

	// --- Access Point mode
	// Create Hotspot: 192.168.10.100
	void create(const char *ssid, const char *password) {
		WiFi.mode(WIFI_AP);
		wifiremote_server_ip[2] = 10;
		WiFi.softAPConfig(wifiremote_server_ip, wifiremote_server_ip, wifiremote_subnet_ip);
		WiFi.softAP(ssid, password);
		wifiremote_server.begin();
		Serial.print(F("WebServer IP: "));Serial.println(WiFi.softAPIP());
	}

	// --- Station mode
	// Connect to Hotspot: 192.168.dynamic.100
	void connect(const char *ssid, const char *password) {
		WiFi.mode(WIFI_STA);
		WiFi.begin(ssid, password);
		wifiremote_server.begin();
		station_mode = true;
	}

	//-----------------------------------------------//

	// Enable Light Sensor for MobileApp:
	void lightSensor(uint32_t min, uint32_t max = 0) {
		min_lux = min;
		max_lux = max;
	}

	// HTML page update-interval by seconds:
	void updateInterval(uint8_t seconds) {
		update_seconds = seconds;
	}



	// Switch by RSSI, STA mode only !
	// return: 0, 1, 2
	uint8_t switchByRSSI(int limit = -20) {
		if (!station_mode) return 0;
		static uint32_t last_ms = 0, counter = 0;
		static int avg_rssi = 0;
		static uint8_t state = 0, c_state = 0;
		uint32_t ms = millis();
		if (last_ms != ms) {
			avg_rssi += WiFi.RSSI();
			counter++;
			last_ms = ms;
		}
		if (counter < 200) return 0;
		int rssi = (avg_rssi / 200);
		avg_rssi = 0;
		counter = 0;
		if (rssi == 0 or (rssi / 1.5) < limit) c_state = 1;else if (rssi > limit) c_state = 2;
		if (state == c_state) return 0;
		state = c_state;
		return state;
	}



	// Result of XMLHttpRequest()
	// WFR_RESULTS[2]
	// 0 -> id		uint32_t
	// 1 -> value	uint32_t
	bool getResult() {
		// STA mode:
		if (station_mode) {													// 0 - 2000 mcrs
			if (WiFi.status() != WL_CONNECTED) {							// 3 mcrs
				// Reset IP, if your phone has a dynamic hotspot:
				if (!disconnected) {
					wifiremote_server_ip[2] = 0;
					WiFi.config(wifiremote_reset_ip, wifiremote_reset_ip, wifiremote_reset_ip);
					Serial.println(F("WebServer IP: 0.0.0.0"));
					disconnected = true;
				}
				// Reconnect by 5 seconds interval:
				uint32_t diff = (millis() - reconnect_millis);
				if (diff > 5000) {
					if (WiFi.gatewayIP()[2] == 0) WiFi.reconnect();			// 400 mcrs
					reconnect_millis += diff;
				}
				return false;
			}
			else if (disconnected) {
				// After reconnect, add new IP, if it's changed:
				uint8_t w = WiFi.gatewayIP()[2];
				if (w > 0) {
					wifiremote_server_ip[2] = w;
					WiFi.config(wifiremote_server_ip);
					Serial.print(F("WebServer IP: "));Serial.println(WiFi.localIP());
					disconnected = false;
				}
			}
		}
		NetworkClient current_client = wifiremote_server.accept();			// 40 - 800 mcrs
		// Saved client by current:
		if (current_client) wifiremote_client = current_client;
		// Wait for available:												// 0 - 1500 mcrs
		if (wifiremote_client and wifiremote_client.connected() and wifiremote_client.available()) {
			// Reset results:
			WFR_RESULTS[0] = 0;
			WFR_RESULTS[1] = 0;
			uint32_t slash = 0;
			char chr = 0;
			while (chr = wifiremote_client.read()) {
				if (chr == '\n') break;
				else if (chr == '/') slash++;
				else if (slash > 0) {
					if (chr == ' ' or slash == 3) break;
					WFR_RESULTS[slash-1] *= 10;
					WFR_RESULTS[slash-1] += uint8_t(chr - '0');
				}
			}
			return true;
		}
		return false;
	}



	// Evaluate JavaScript or send HTML at first loading.
	// favicon is disabled.
	void evalJs(String data) {

		// Page build:
		if (WFR_RESULTS[0] == 0) data =
			"<!DOCTYPE html>\n"
			"<html><head><title>WebServer</title>\n"
			"<link rel=\"icon\" href=\"data:image/png;base64,iVBORw0KGgo=\">\n"
			"<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">\n"
			"<meta name=\"viewport\" content=\"width=device-width,initial-scale=1,user-scalable=no\">\n"
			"<style>html{user-select:none}body{margin:0px}" + String(style) + "</style>\n"
			"<script>((w,d)=>{HTMLElement.prototype.resultAttribute=function(v){this.setAttribute('result',v)};w.S=(n)=>{return d.querySelector(n)};"
			"w.android||={xhrError:()=>{},lightLimits:(x,y)=>{}};w.pingTime=0;w.setResult=(()=>{"
			"let x=0,t=0;return function(z){if(x)return;let p=new Date().getTime(),u=z.split('-'),i=u[0],v=u[1];if(i==0)return;"
			"x=new XMLHttpRequest();x.open('GET','/'+i+(v?'/'+v:''),true);x.onload=()=>{"
			"w.pingTime=(new Date().getTime()-p);if(t)clearTimeout(t);new Function(x.responseText)();x=0};x.send();t=setTimeout(()=>{x.abort();x=0;android.xhrError();t=0},2000)}})();"
			"d.onclick=(e)=>{let r=e.target.getAttribute('result');if(r)w.setResult(r)}})(window,document);"
			+ String(update_seconds ? "setInterval(function(){w.setResult('9999')}," + String(update_seconds * 1000) + ");" : "")
			+ String(min_lux ? "(()=>{android.lightLimits(" + String(min_lux) + "," + String(max_lux) + ")})();" : "") + "</script></head>\n"
			"<body>" + String(body) + "<script id=\"to-remove\">" + data + "S('#to-remove').remove();</script></body></html>\n";

		wifiremote_client.println("HTTP/1.1 200 OK\nConnection:close\nContent-type:text/html\n\n" + data);
		wifiremote_client.stop();
		wifiremote_client = 0;
	}

};

#define __WiFiRemote_h__ 1
#endif
