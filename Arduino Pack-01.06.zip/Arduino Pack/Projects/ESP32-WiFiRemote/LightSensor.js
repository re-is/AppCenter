setInterval(function(){
	let v=window.lightSensorValue||0;
	if(v<" + String(minLux) + "){
		if(" + String(savedLightValue) + "!==0)location.href='/999998/0'
	}else if(v>=" + String(maxLux) + "){
		if(" + String(savedLightValue) + "!==2)location.href='/999998/2'
	}else if(" + String(savedLightValue) + "!==1)location.href='/999998/1'
},300);



setInterval(function(){
	let v=window.lightSensorValue||0;
	if(v<" + String(minLux) + "){
		if(" + String(savedLightValue) + "!==0)location.href='/999998/0'
	}else if(" + String(savedLightValue) + "!==1)location.href='/999998/1'
},300);
