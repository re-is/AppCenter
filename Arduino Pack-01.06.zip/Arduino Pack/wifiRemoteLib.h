#ifndef __WiFiRemote_h__

#include <WiFi.h>

//-------------------------------------------------------------------------------------//

NetworkClient wifiremote_client;
NetworkServer wifiremote_server(80);
IPAddress wifiremote_server_ip(192, 168, 0, 100);
IPAddress wifiremote_subnet_ip(255, 255, 255, 0);
IPAddress wifiremote_reset_ip(0, 0, 0, 0);
bool wifiremote_sta = false;

struct WiFiRemote {

	//--- SETUP
	//---------------------------------------------------------------------------------//

	void cssCompression(String &css) {
		css.replace("\t", "");
		css.replace("\n", "");
		css.replace("  ", " ");
		css.replace(" {", "{");
		css.replace("{ ", "{");
		css.replace(" }", "}");
		css.replace("} ", "}");
		css.replace(" (", "(");
		css.replace("( ", "(");
		css.replace(" )", ")");
		css.replace(") ", ")");
		css.replace(" :", ":");
		css.replace(": ", ":");
		css.replace(" ,", ",");
		css.replace(", ", ",");
		css.replace(" ;", ";");
		css.replace("; ", ";");
		css.replace(";}", "}");
	}

	//  192.168.10.100
	void create(const char *ssid, const char *password) {
		WiFi.mode(WIFI_AP);
		wifiremote_server_ip[2] = 10;
		WiFi.softAPConfig(wifiremote_server_ip, wifiremote_server_ip, wifiremote_subnet_ip);
		WiFi.softAP(ssid, password);
		wifiremote_server.begin();
		Serial.print(F("WebServer IP: "));Serial.println(WiFi.softAPIP());
	}

	//  192.168.dynamic.100
	void connect(const char *ssid, const char *password) {
		WiFi.mode(WIFI_STA);
		WiFi.begin(ssid, password);
		wifiremote_server.begin();
		wifiremote_sta = true;
	}






	//--- LOOP
	//---------------------------------------------------------------------------------//

	class WRClient {
	private:
		uint32_t reconnect_millis = 0, minLux = 0, maxLux = 0, lightState = 0, reloadSeconds = 0;
		bool disconnected = true;
	public:




		bool result(uint32_t *res) {
			// in STA mode:
			if (wifiremote_sta) {												// 0 - 2000 mcrs
				if (WiFi.status() != WL_CONNECTED) {							// 3 mcrs
					// Reset IP, if your phone has a dynamic hotspot:
					if (!disconnected) {
						wifiremote_server_ip[2] = 0;
						WiFi.config(wifiremote_reset_ip, wifiremote_reset_ip, wifiremote_reset_ip);
						Serial.println(F("WebServer IP: 0.0.0.0"));
						disconnected = true;
					}
					// Reconnect by 5 seconds interval:
					uint32_t diff = (millis() - reconnect_millis);
					if (diff > 5000) {
						if (WiFi.gatewayIP()[2] == 0) WiFi.reconnect();			// 400 mcrs
						reconnect_millis += diff;
					}
					return false;
				}
				else if (disconnected) {
					// After reconnect, add new IP, if it's changed:
					uint8_t w = WiFi.gatewayIP()[2];
					if (w > 0) {
						wifiremote_server_ip[2] = w;
						WiFi.config(wifiremote_server_ip);
						Serial.print(F("WebServer IP: "));Serial.println(WiFi.localIP());
						disconnected = false;
					}
				}
			}
			NetworkClient current_client = wifiremote_server.accept();			// 40 - 800 mcrs
			// Set saved client by current:
			if (current_client) wifiremote_client = current_client;
			// Wait for available:												// 0 - 1500 mcrs
			if (wifiremote_client and wifiremote_client.connected() and wifiremote_client.available()) {
				// Reset results:
				res[0] = 0;
				res[1] = 0;
				uint8_t slash = 0;
				char chr = 0;
				while (chr = wifiremote_client.read()) {
					if (chr == '\n') break;
					else if (chr == '/') ++slash;
					else if (slash > 0) {
						if (chr == ' ' or slash == 3) break;
						res[slash-1] *= 10;
						res[slash-1] += uint8_t(chr - '0');
					}
				}
				return true;
			}
			return false;
		}




		void lightSensor(uint32_t *res, uint32_t min, uint32_t max = 0) {
			if (res[0] == 999998) lightState = res[1];
			minLux = min;
			if (max) maxLux = (max < min ? min : max);
		}

		void reloadInterval(uint8_t seconds) {
			reloadSeconds = seconds;
		}




		void create(String css, String body) {									// 3500 mcrs +/- 500 !!
			bool script = (reloadSeconds or minLux or maxLux);
			String html = "HTTP/1.1 200 OK\nContent-type:text/html\n\n";

			html += "<!DOCTYPE html>\n";
			html += "<html><head><title>WebServer</title>\n";
			html += "<link rel=\"icon\" href=\"data:image/png;base64,iVBORw0KGgo=\">\n";
			html += "<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">\n";
			html += "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1,user-scalable=no\">\n";
			html += "<style>html{user-select:none}body{margin:0px}" + css + "</style>";
			html += "</head><body>" + body;
			html += (script ? "<script>" : "</body></html>\n");
			if (reloadSeconds)	html += "setTimeout(function(){location.href='/999999'}," + String(reloadSeconds * 1000) + ");";
			if (maxLux)			html += "setInterval(function(){let v=window.lightSensorValue||0;if(v<" + String(minLux) + "){if(" + String(lightState) + "!==0)location.href='/999998/0'}else if(v>=" + String(maxLux) + "){if(" + String(lightState) + "!==2)location.href='/999998/2'}else if(" + String(lightState) + "!==1)location.href='/999998/1'},300);";
			else if (minLux)	html += "setInterval(function(){let v=window.lightSensorValue||0;if(v<" + String(minLux) + "){if(" + String(lightState) + "!==0)location.href='/999998/0'}else if(" + String(lightState) + "!==1)location.href='/999998/1'},300);";
			if (script)			html += "</script></body></html>\n";

			wifiremote_client.println(html);
			wifiremote_client.stop();
		}


	}; // WRClient


	WRClient client;
};


#define __WiFiRemote_h__ 1
#endif
