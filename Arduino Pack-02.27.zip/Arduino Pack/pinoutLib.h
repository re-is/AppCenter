#ifndef __PinoutLib_h__
#define __PinoutLib_h__ 1

#include "C:\Program Files\Apps\Arduino pack\digitaLib.h"

#define BETWEEN(x, y, z) ((x > y) and (x < z))
#define FROMTO(x, y, z) ((x >= y) and (x < z))
#define MINMAX(x, y, z) ((x < y) ? y : (x > z) ? z : x)
#define ever ;;

#define NANO_D2 2
#define NANO_D3 3
#define NANO_D4 4
#define NANO_D5 5
#define NANO_D6 6
#define NANO_D7 7
#define NANO_D8 8
#define NANO_D9 9
#define NANO_D10 10
#define NANO_D11 11
#define NANO_D12 12
#define NANO_A0 14
#define NANO_A1 15
#define NANO_A2 16
#define NANO_A3 17
#define NANO_A4 18
#define NANO_A5 19
#define NANO_A6 20
#define NANO_A7 21

#define TINY_D0 0
#define TINY_D1 1
#define TINY_D2 2
#define TINY_D3 3
#define TINY_D4 4
#define TINY_A2 2
#define TINY_A3 3
#define TINY_A4 4

void loop() {}

#endif
