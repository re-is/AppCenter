
char *id, *result;



// 90 mcrs
char *charPointerResize(char *pointer, size_t src_length = 0, char *src = "") {
	size_t length = (src_length ? src_length : strlen(src)), ns = length * 2;
	char *new_pointer = new char[ns];
	memcpy(new_pointer, pointer, length * sizeof(int));
	delete[] pointer;
	new_pointer[length] = '\0';
	return new_pointer;
}


size_t strIndexOf(char *source, char chr) {
	for (size_t i = 0; i < strlen(source); i++) {
		if (source[i] == chr) return i;
	}
}



char *html = "<head>head vége</head><body>Hello szia</body>";
char *lib = "<script>if (true) { let value = 10; }</script>";
char *temp_html;

void setup() {

	Serial.begin(1000000);

	size_t
		start_index = 0,
		start_lib = 0,
		html_length = strlen(html),
		lib_length = strlen(lib),
		full_length = html_length+lib_length;

	temp_html = charPointerResize(temp_html, full_length);

	for (size_t i = 0; i < full_length; i++) {

		if (i < html_length-6 &&
			html[i] == '<' &&
			html[i+1] == '/' &&
			html[i+2] == 'h' &&
			html[i+3] == 'e' &&
			html[i+4] == 'a' &&
			html[i+5] == 'd' &&
			html[i+6] == '>') {
				start_lib = 1;
				start_index = i;
			}

		// Normál átírás:
		if (start_lib == 0) temp_html[i] = html[i];
		// Lib beírása:
		else if (start_lib == 1) {
			// Amíg a hossza engedi:
			if (i-start_index < lib_length) temp_html[i] = lib[i-start_index];
			// Tovább léptetés:
			else start_lib = 2;
		}
		// Maradék beírása:
		if (start_lib == 2 && start_index < html_length) temp_html[i] = html[start_index++];
	}

	Serial.println(temp_html);

/*
	char *data = "button-id off";

	size_t
		data_length = strlen(data),
		sep_index = strIndexOf(data, ' '),
		target_length = (sep_index ? sep_index : data_length);




	id = charPointerResize(id, target_length);
	for (size_t i = 0; i < target_length; i++) id[i] = data[i];

	Serial.print(id);Serial.println(";");



	if (sep_index) {
		target_length = (data_length-sep_index-1);
		result = charPointerResize(result, target_length);
		for (size_t i = 0; i < target_length; i++) result[i] = data[i+sep_index+1];

		Serial.print(result);Serial.println(";");
	}*/



	while(1);
}
