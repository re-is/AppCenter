#include "C:\Program Files\Apps\Arduino pack\pinoutLib.h"
#include "C:\Program Files\Apps\Arduino pack\irfRemoteLib.h"

void setup() {

	// Nano_D3, R-F
	// Nano_D5, I-R

	IRFRemote remoteRF(Nano_D3, INPUT);
	IRFRemote remoteIR(Nano_D5, INPUT);

	Serial.begin(1000000);

	uint32_t microsec, codeRF, codeIR;

	for (ever) {

		microsec = micros();

		codeRF = remoteRF.getCode(microsec);
		codeIR = remoteIR.getCode(microsec);

		if (codeRF) Serial.println(codeRF);
		if (codeIR) Serial.println(codeIR);

		/*uint32_t code = remoteRF.safetyCode(microsec);

		if (code) Serial.println(code);


		if (code == 4087716608) {
			Serial.println("A");
		}
		if (code == 4087717376) {
			Serial.println("B");
		}
		if (code == 4087715584) {
			Serial.println("C");
		}
		if (code == 4087717120) {
			Serial.println("D");
		}*/
	}
}
