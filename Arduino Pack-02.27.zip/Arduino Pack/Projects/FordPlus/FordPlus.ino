//-----------------------------------------------------------------//
// Generátor + ventillátor szabályozó és központizár kezelő, 2025
//-----------------------------------------------------------------//

#include "C:\Program Files\Apps\Arduino pack\pinoutLib.h"
#include "C:\Program Files\Apps\Arduino pack\generaLib.h"
#include "C:\Program Files\Apps\Arduino pack\irfRemoteLib.h"

void command(uint8_t process)
{
	switch (process)
	{
	case 1:
		fastWrite(Nano_D10, 1);
		delay(100);
		fastWrite(Nano_D10, 0);
		break;
	case 2:
		fastWrite(Nano_D8, 1);
		delay(100);
		fastWrite(Nano_D8, 0);
		break;
	case 3:
		fastWrite(Nano_D10, 1);
		delay(100);
		fastWrite(Nano_D4, 1);
		delay(100);
		fastWrite(Nano_D4, 0);
		delay(100);
		fastWrite(Nano_D10, 0);
		break;
	}
}

double voltage()
{
	return (analogRead(Nano_A0) / 34.8);
}

void setup()
{
	pinMode(Nano_A0, INPUT);		// Volt
	pinMode(Nano_A7, INPUT);		// Termo
	pinMode(Nano_D2, OUTPUT);		// Reset

	//	   Fast(Nano_D3, INPUT);	// Remote
	pinModeFast(Nano_D4, OUTPUT);	// Csomi	/ fehér
	//	   Fast(Nano_D6, OUTPUT);	// Gen		/ kék
	pinModeFast(Nano_D8, OUTPUT);	// Zárás	/ sárga
	pinModeFast(Nano_D10, OUTPUT);	// Nyitás	/ zöld
	pinModeFast(Nano_D12, OUTPUT);	// Relé		/ fekete

	IRFRemote remote_D3(Nano_D3, INPUT);
	GeneraLib::PWM pwm_D6(Nano_D6);
	GeneraLib::LOOP loop(500000);


	double
		volts			= voltage(),
		celcius_limit	= 90.0;
	bool
		pwm_signal		= (volts > 13),
		fan_on			= false,
		print			= false;
	uint8_t
		timer			= 0;


	if (print)
	{
		Serial.begin(1000000);
		if (pwm_signal) Serial.println(F("PWM bekapcsolva."));
	}


	for (ever)
	{
		uint32_t microsec = micros();

		//-------------------------------------------------------------------------------------------//



		// Fél másodpercenként fut le:
		if (loop.run(microsec))
		{

			// Hőfok kiolvasása:
			double celcius = (analogRead(Nano_A7) / 8.5);
			if (print) Serial.println("Hőfok:\t" + String(celcius) + " °C");

			if (!fan_on and volts > 13 and celcius > celcius_limit)
			{
				if (print) Serial.println(F("Relay ON !"));
				digitalWrite(Nano_D12, 1);
				fan_on = true;
			}

			if (fan_on and celcius < (celcius_limit-0.2))
			{
				if (print) Serial.println(F("Relay OFF !"));
				digitalWrite(Nano_D12, 0);
				fan_on = false;
			}



			// Feszültség kiolvasása:
			volts = voltage();
			if (print) Serial.println("Fesz:\t" + String(volts) + " V");

			if (volts > 13)
			{
				if (!pwm_signal)
				{
					if (print) Serial.println(F("RESET !"));
					delay(100);
					digitalWrite(Nano_D2, 1);
					while(1);
				}
				else if (timer < 6) timer = 6;
			}
			else if (!fan_on)
			{
				if (timer > 0)
				{
					if (print) Serial.println(F("Feszültség 13 V alatt !"));
					timer--;
				}
				else if (pwm_signal)
				{
					if (print) Serial.println(F("PWM kikapcsolva."));
					pwm_D6.stop();
					pwm_signal = false;
				}
			}
		}



		//-------------------------------------------------------------------------------------------//



		uint32_t code = remote_D3.safetyCode(microsec, true);


		// (A1 A2)
		if (code == 1912212992 or code == 2966597120)
		{
			pwm_D6.stop();
			command(1);
			if (print) Serial.println(F("Nyitva"));
		}


		// (B1 B2)
		if (code == 1912212736 or code == 2966596864)
		{
			pwm_D6.stop();
			command(2);
			if (print) Serial.println(F("Zárva"));
		}


		// Járó motornál PWM indítása:
		if (pwm_signal) pwm_D6.run(microsec, 128, 0.4);
		// (A1+A2 B1+B2), csak álló motornál !
		else if (code == 1912212480 or code == 2966596608)
		{
			pwm_D6.stop();
			command(3);
			if (print) Serial.println(F("Csomiajtó"));
		}
	}
}
