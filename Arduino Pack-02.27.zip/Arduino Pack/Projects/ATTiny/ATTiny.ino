#include "C:\Program Files\Apps\Arduino pack\pinoutLib.h"

void setup() {

	pinMode(TINY_D3, OUTPUT);	// piros
	pinMode(TINY_D4, OUTPUT);	// kék

	uint8_t bright = 0;

	for (ever) {

		if (bright < 255) {
			delay(20);
			analogWrite(TINY_D4, ++bright);
		}
	}
}
