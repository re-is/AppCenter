(function js_min() {

	var js_file = 'WiFiRemote.js';
	var fso = new ActiveXObject('Scripting.FileSystemObject');
	var opened_text_file = fso.OpenTextFile(js_file, 1);
	var text = opened_text_file.ReadAll(); opened_text_file.Close();

	text = text.replace(/\r\n|\t/g, '');
	text = text.replace(/[/][*].*[*][/]/g, '');
	text = text.replace(/\B\s|\s\B/g, '');
	text = text.replace(/\;\}/g, '}');
	text = text.replace(/\}\$/g, '\} \$');

	var ch = text.split('');
	var max_lines = parseInt(Math.round(ch.length / 80));
	var new_line = 0;
	var js_text = '';

	for (var i = 0; i < ch.length; i++) {

		if (i === 0) {
			js_text += '"';
		}
		else if (i % 80 === 0 && ++new_line < max_lines) {
			js_text += '"\r\n\t\t\t"';
		}

		js_text += ch[i];

		if (i === ch.length-1) js_text += '"';

	}

	var min = fso.CreateTextFile('w-----------------------temp.txt', true);
	min.Write(js_text);
	min.Close();

})();
