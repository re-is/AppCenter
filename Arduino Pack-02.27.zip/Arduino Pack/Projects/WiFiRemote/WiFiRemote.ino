#include "C:\Program Files\Apps\Arduino pack\pinoutLib.h"
#include "C:\Program Files\Apps\Arduino pack\wifiRemoteLib.h"

WiFiRemote wfr;

// Saved value's:
uint8_t
	led_grn_pin = 21,
	led_red_pin = 19,
	saved_grn_value = 0,
	saved_red_value = 0;


void setup() {

	pinMode(led_grn_pin, OUTPUT);
	pinMode(led_red_pin, OUTPUT);
	digitalWrite(led_grn_pin, saved_grn_value);
	digitalWrite(led_red_pin, saved_red_value);

	// Start ----------------------------------->
	Serial.begin(115200);

	// Sensor limits:
	//wfr.lightSensor(20, 50);
	//wfr.orientationSensor();
	//wfr.rssiSwitch(-40);

	// Station mode
	// Mobile / Router		ssid & password:
	wfr.connect("Mi Hazánk, 2026", "tda8560q");

	// AccessPoint mode
	// ESP / Arduino		ssid & password:
	//wfr.create("ESP32-Hotspot", "tda8560q");

	//------------------------------------------>
	for (ever) {

		if (wfr.onMessage()) {

			if (WFR_ID == "RSSI_ID") Serial.println(WFR_RESULT);

			if (WFR_ID == "LIGHT_ID") {
				Serial.println("Light sensor: " + WFR_RESULT);
			}

			if (WFR_ID == "ORIENTATION_ID") {
				Serial.println("Orientation: " + WFR_RESULT);
			}

			if (WFR_ID == "led-grn") {
				saved_grn_value = (WFR_RESULT == "off" ? 1 : 0);
			}

			if (WFR_ID == "led-red") {
				saved_red_value = (WFR_RESULT == "off" ? 1 : 0);
			}

			//--------------------------------------------------------------------------//

			digitalWrite(led_grn_pin, saved_grn_value);
			digitalWrite(led_red_pin, saved_red_value);

			wfr.evalJS(
				"S('#led-grn', " + String(saved_grn_value ? "'on'" : "'off'") + ");"
				"S('#led-red', " + String(saved_red_value ? "'on'" : "'off'") + ");"
			);
		}




		if (millis() % 1000 == 0) {

			wfr.evalJS("S('#wifi-strength').innerText = '" + String(WiFi.RSSI()) + "';");

		}
	}
}
