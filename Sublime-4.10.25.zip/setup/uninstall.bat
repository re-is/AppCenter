@echo off
taskkill /f /im "sublime_text.exe"
