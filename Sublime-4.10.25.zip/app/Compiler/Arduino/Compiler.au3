#Pragma compile(Icon, 'icon.main.ico')

Func m($text)
	MsgBox(0, "", $text)
EndFunc

Func Compile()

	Local $ino_file		= StringSplit(WinGetTitle("[CLASS:PX_WINDOW_CLASS]"), " - Sublime Text", 1)[1]
	Local $ino_ext		= StringSplit($ino_file, ".")
	Local $ino_path		= StringSplit($ino_file, "\")
	Local $sketch_path	= StringReplace($ino_file, "\" & $ino_path[$ino_path[0]], "")
	Local $sketch_name	= $ino_path[$ino_path[0]-1]


	; Csak .ino fájl:
	If ($ino_ext[$ino_ext[0]] <> "ino") Then
		ToolTip("---------------------------------------------" & @Lf & "Only .ino files are allowed!" & @LF & "---------------------------------------------", 20, 20, "Arduino Compiler", 2)
		Sleep(4000)
		Exit
	EndIf


	; IDE 2.x.x ablakcím lekérése:
	AutoItSetOption("WinTitleMatchMode", 2)
	Local $ide_title = WinGetTitle($sketch_name & " | Arduino IDE 2")


	; IDE megnyitása, ha még nincs:
	If ($ide_title = "") Then
		Run('"C:\Program Files\Arduino IDE\Arduino IDE.exe" "' & $sketch_path & '"')
		Exit
	Else
		WinActivate($sketch_name & " | Arduino IDE 2")
		Sleep(1000)
		; Compile & Upload:
		Send("^u")
	EndIf


EndFunc

Sleep(100)

Compile()
