#include <GUIConstantsEx.au3>
#Pragma compile(Icon, 'icon.main.ico')

Func m($text)
	MsgBox(0, "", $text)
EndFunc

Func Compile()

	Sleep(100)
	Local $log_file		= (EnvGet("TEMP") & "\temp.log")
	Local $mq5_file		= StringSplit(WinGetTitle("[CLASS:PX_WINDOW_CLASS]"), " - Sublime Text", 1)[1]
	Local $mq5_path		= StringSplit($mq5_file, ".")
	Local $editor_title	= "MetaEditor"
	Local $meta_folder	= StringSplit($mq5_file, "\MQL5\", 1)[1]
	Local $editor_exe	= ($meta_folder & "\metaeditor64.exe")
	Local $terminal_exe	= ($meta_folder & "\terminal64.exe")


	; Csak .mq5 fájl:
	If ($mq5_path[$mq5_path[0]] <> "mq5") Then
		ToolTip("---------------------------------------------" & @Lf & "Only MQ5 files are allowed!" & @LF & "---------------------------------------------", 20, 20, "MQ5 Compiler", 2)
		Sleep(4000)
		Exit
	EndIf


	; Taskkill
	If Not WinExists($editor_title) Then
		RunWait(@ComSpec & ' /c taskkill /f /im "metaeditor64.exe"', "", @SW_HIDE)
		Sleep(500)
	EndIf


	; LOG fájl készítés:
	RunWait('"' & $editor_exe & '" /compile:"' & $mq5_file & '" /log:"' & $log_file & '" /s', "", @SW_HIDE)
	Local $text, $errors = False
	While 1
		If FileExists($log_file) Then
			Sleep(500)
			$text = FileRead($log_file)
			; Ha van benne hiba:
			If (StringInStr($text, ".mq5(") > 0) Or (StringInStr($text, ".mqh(") > 0) Then $errors = True
			FileDelete($log_file)
			ExitLoop
		EndIf
	WEnd


	; Editor megnyitása az aktuális mq5 fájllal:
	Run('"' & $editor_exe & '" "' & $mq5_file & '"')
	Local $innerWindow, $height = (@DesktopHeight * 0.9), $y = ($height * 0.05)
	While 1
		Sleep(50)
		$innerWindow = ControlGetHandle($editor_title, "", 65280)
		If WinExists($innerWindow) Then
			Sleep(50)
			WinSetState($editor_title, "", @SW_RESTORE)
			WinMove($editor_title, "", 80, $y, 800, $height, 1)
			ExitLoop
		EndIf
	WEnd


	; Compile:
	Send("{F7}")


	; Ha van benne hiba, az editor megjelenítése,
	; ha nincs, a terminal futtatása:
	If $errors Then
		TraySetIcon("icon.nok.ico")
		GUISetIcon("icon.nok.ico")
		WinSetState($innerWindow, "", @SW_MAXIMIZE)
	Else
		Run($terminal_exe)
	EndIf


	; Belső ablak bezárása, az editor a tálcára:
	Sleep(2000)
	While 1
		Sleep(50)
		If Not WinActive($editor_title) Then
			If WinExists($innerWindow) Then WinClose($innerWindow)
			Sleep(300)
			WinSetState($editor_title, "", @SW_MINIMIZE)
			ExitLoop
		EndIf
	WEnd

EndFunc

Compile()
