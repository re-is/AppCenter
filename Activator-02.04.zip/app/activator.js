(function() {

	// Helyi változók:
	var
		app_folder = 'C:\\Program Files\\Apps\\Activator\\app',
		fso = new ActiveXObject('Scripting.FileSystemObject'),
		wss = new ActiveXObject('WScript.Shell'),
		date = new Date(),
		manual = false,
		currentTick = date.getTime(),
		lastTick = 0,
		activated = (date.getFullYear() + '.' + ('0' + (date.getMonth() + 1)).slice(-2) + '.' + ('0' + date.getDate()).slice(-2));


	// Kapcsoló ellenőrzése:
	// Ha van, akkor kézi aktiválás. Ha nincs, akkor automatikus:
	try { manual = (WScript.Arguments(0) !== '') } catch(e) {}


	// Idő lekérése:
	try { lastTick = Number(wss.RegRead('HKCU\\Software\\Apps\\WindowsActivation')) } catch(e) {}


	// Ha kézi vagy ha eltelt 30 nap:
	if (manual || (currentTick > (lastTick + (1000 * 60 * 60 * 24 * 30)))) {

		// Aktiváló futtatása:
		wss.Run('"' + app_folder + '\\activator.bat"' + (manual ? ' manual' : ''), (manual ? 1 : 0), true);
		// Adat fájl készítése:
		var f = fso.CreateTextFile(app_folder + '\\Last Activation.txt', true, false);
		f.WriteLine('Utolsó aktiválás: ' + activated);
		f.Close();

		wss.RegWrite('HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run\\MicrosoftActivator', 'C:\\Windows\\System32\\wscript.exe "' + app_folder + '\\activator.js"', 'REG_SZ');
		wss.RegWrite('HKCU\\Software\\Apps\\WindowsActivation', currentTick, 'REG_SZ');

	}

})();
