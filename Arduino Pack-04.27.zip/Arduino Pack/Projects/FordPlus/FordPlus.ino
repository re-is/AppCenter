//-----------------------------------------------------------------//
// Generátor + ventillátor szabályozó és központizár kezelő, 2025
//-----------------------------------------------------------------//

#include "C:/Program Files/Apps/Arduino Pack/pinoutLib.h"
#include "C:/Program Files/Apps/Arduino Pack/generaLib.h"
#include "C:/Program Files/Apps/Arduino Pack/irfRemoteLib.h"

IRFremote <NANO_D3, GET_CODE> remote_D3;
GeneraLib::PWM <NANO_D6> pwm_D6;
GeneraLib::AVG <10> average;
GeneraLib::LOOP <500000> time_loop;

void command(uint8_t process)
{
	switch (process)
	{
	case 1:
		digitalWrite(NANO_D10, 1);
		delay(100);
		digitalWrite(NANO_D10, 0);
		break;
	case 2:
		digitalWrite(NANO_D8, 1);
		delay(100);
		digitalWrite(NANO_D8, 0);
		break;
	case 3:
		digitalWrite(NANO_D10, 1);
		delay(100);
		digitalWrite(NANO_D4, 1);
		delay(100);
		digitalWrite(NANO_D4, 0);
		delay(100);
		digitalWrite(NANO_D10, 0);
		break;
	}
}

void setup()
{
	pinMode(NANO_A0, INPUT);	// Volt
	pinMode(NANO_A7, INPUT);	// Termo
	pinMode(NANO_D2, OUTPUT);	// Reset
	//pinMode(NANO_D3, INPUT);	// Remote
	pinMode(NANO_D4, OUTPUT);	// Csomi	/ fehér
	//pinMode(NANO_D6, OUTPUT);	// Gen		/ kék
	pinMode(NANO_D8, OUTPUT);	// Zárás	/ sárga
	pinMode(NANO_D10, OUTPUT);	// Nyitás	/ zöld
	pinMode(NANO_D12, OUTPUT);	// Relé		/ fekete

	remote_D3.init();
	pwm_D6.init();
	average.init();

	delay(10);

	uint8_t
		timer			= 0;
	uint16_t
		volts			= analogRead(NANO_A0),
		_13v			= (13 * 34.8),
		celsius_limit	= 88;
	uint32_t
		microsec		= 0,
		code			= 0;
	bool
		pwm_signal		= (volts > _13v),
		fan_on			= false,
		print			= false;


	celsius_limit *= 8.5;


	if (print)
	{
		Serial.begin(1000000);
		if (pwm_signal) Serial.println(F("PWM bekapcsolva."));
	}


	for (ever)
	{
		microsec = micros();

		//-------------------------------------------------------------------------------------------//



		// Fél másodpercenként fut le:
		if (time_loop.run(microsec))
		{

			// Hőfok átlag kiolvasása:
			uint16_t celsius = analogRead(NANO_A7);
			celsius = average.calc(celsius);
			if (print) Serial.println("Hőfok:\t" + String(celsius / 8.5) + " °C");

			if (!fan_on and volts > _13v and celsius > celsius_limit)
			{
				if (print) Serial.println(F("Relay ON !"));
				digitalWrite(NANO_D12, 1);
				fan_on = true;
			}

			if (fan_on and (!pwm_signal || celsius < (celsius_limit-3)))
			{
				if (print) Serial.println(F("Relay OFF !"));
				digitalWrite(NANO_D12, 0);
				fan_on = false;
			}


			// Feszültség kiolvasása:
			volts = analogRead(NANO_A0);
			if (print) Serial.println("Fesz:\t" + String(volts / 34.8) + " V");

			if (volts > _13v)
			{
				if (!pwm_signal)
				{
					if (print) Serial.println(F("RESET !"));
					delay(100);
					digitalWrite(NANO_D2, 1);
					while(1);
				}
				else if (timer < 10) timer = 10;
			}
			else
			{
				if (timer > 0)
				{
					if (print) Serial.println(F("Feszültség 13 V alatt !"));
					timer--;
				}
				else if (pwm_signal)
				{
					if (print) Serial.println(F("PWM kikapcsolva."));
					pwm_D6.stop();
					pwm_signal = false;
				}
			}
		}



		//-------------------------------------------------------------------------------------------//



		code = remote_D3.safetyCode(microsec, true);


		// (A1 A2)
		if (code == 1912212992 or code == 2966597120)
		{
			pwm_D6.stop();
			command(1);
			if (print) Serial.println(F("Nyitva"));
		}


		// (B1 B2)
		if (code == 1912212736 or code == 2966596864)
		{
			pwm_D6.stop();
			command(2);
			if (print) Serial.println(F("Zárva"));
		}


		// Járó motornál PWM indítása:
		if (pwm_signal) pwm_D6.run(microsec, 125, 44);
		// (A1+A2 B1+B2), csak álló motornál !
		else if (code == 1912212480 or code == 2966596608)
		{
			pwm_D6.stop();
			command(3);
			if (print) Serial.println(F("Csomiajtó"));
		}
	}
}
