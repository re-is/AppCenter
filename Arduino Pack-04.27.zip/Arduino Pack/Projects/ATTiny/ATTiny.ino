#include "C:/Program Files/Apps/Arduino Pack/pinoutLib.h"
#include "C:/Program Files/Apps/Arduino Pack/generaLib.h"

// Fogyasztó Volt ---------//
#define SOURCE 12
#define TARGET 3
//-------------------------//

GeneraLib::AVG<50>avg_main;
GeneraLib::AVG<50>avg_load;

void setup() {

	pinMode(TINY_D0, OUTPUT);	// mfet
	pinMode(TINY_A2, INPUT);	// main
	pinMode(TINY_A3, INPUT);	// load

	digitalWrite(TINY_D0, 0);
	delay(1);

	uint16_t
		source = (SOURCE * 50),
		target = (TARGET * 50),
		final_target = 0,
		load_target = 0,
		last_millis = 0,
		main = 0,
		load = 0;

	avg_main.init();
	avg_load.init();

	for (ever) {

		// Fade-in:
		if (final_target < target) {
			uint8_t m = millis();
			if (last_millis != m) {
				final_target++;
				last_millis = m;
			}
		}

		// Olvasás:
		main = analogRead(TINY_A2);
		load = analogRead(TINY_A3);

		// Átlagolás, 50/1:
		main = avg_main.calc(main);
		load = avg_load.calc(load);

		// 600 * 100 / 550 * 150 / 100
		load_target = ((((source * 100) / main) * final_target) / 100);

		// Ha a "Terhelés" a "Cél" alatt van, akkor 1:
		digitalWrite(TINY_D0, (load < load_target));
	}
}
