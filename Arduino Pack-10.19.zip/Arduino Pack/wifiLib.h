#include <WiFi.h>

WiFiClient wifilib_client;
WiFiServer wifilib_server(80);
IPAddress local_ip(192, 168, 0, 100);

void wifilib_connected(WiFiEvent_t event, WiFiEventInfo_t info) {
	if (local_ip[2] == WiFi.gatewayIP()[2]) return;
	local_ip[2] = WiFi.gatewayIP()[2];
	Serial.print("ESP WebServer IP: ");Serial.println(local_ip);
	WiFi.disconnect();
}

void wifilib_disconnected(WiFiEvent_t event, WiFiEventInfo_t info) {
	WiFi.disconnect(true, true);
	delay(100);
	if (local_ip[2]) WiFi.config(local_ip);
	WiFi.begin("Netem", "tda8560q");
}

class WiFiLib {
private:
public:

	//--- SETUP
	//--- HOTSPOT handling -----------------------------------------------//

	void createHotspot(const char* ssid, const char* password) {
		WiFi.softAP(ssid, password);
		wifilib_server.begin();
		Serial.print("ESP WebServer IP: ");Serial.println(WiFi.softAPIP());
	}

	void connectToHotspot(const char* ssid, const char* password) {
		WiFi.mode(WIFI_STA);
		WiFi.begin(ssid, password);
		WiFi.onEvent(wifilib_connected, WiFiEvent_t::ARDUINO_EVENT_WIFI_STA_GOT_IP);
		WiFi.onEvent(wifilib_disconnected, WiFiEvent_t::ARDUINO_EVENT_WIFI_STA_DISCONNECTED);
		wifilib_server.begin();
	}

	//--- LOOP
	//--------------------------------------------------------------------//

	char clientHrefValue() {
		char value = 0;
		wifilib_client = wifilib_server.accept();
		if (wifilib_client) {
			uint32_t i = 0;
			while (wifilib_client.connected()) {
				if (wifilib_client.available()) {
					bool dollar_chr = false;
					value = '0';
					for (ever) {
						char chr = wifilib_client.read();
						if (chr == '\n') break;
						else if (chr == '$') dollar_chr = true;
						else if (dollar_chr) {
							value = chr; // -> /$[x]
							break;
						}
					}
					break;
				}
				else if (i > 200) break;
				else {
					delay(1);
					++i;
				}
			}
		}
		return value;
	}

	void clientHtml(String styleTextContent, String bodyInnerHTML) {
		wifilib_client.println("HTTP/1.1 200 OK\nContent-type:text/html\nConnection:close\n\n<!DOCTYPE html>\n<html><head><title>ESP32 WebServer</title><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1, user-scalable=no\"><link rel=\"icon\" type=\"image/x-icon\" href=\"https://raw.githubusercontent.com/re-is/shl.min/refs/heads/main/server.ico\"><style>html{display:inline-block}body{margin:0px}" + styleTextContent + "</style></head><body style=\"user-select:none;\">" + bodyInnerHTML + "</body></html>\n");
	}

};
