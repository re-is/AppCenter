class GeneraLib {
private:
public:

	void delayMicros(uint32_t n) {
		uint32_t m = micros();
		while (m + n > micros());
	}

	void readSerial(String &res) {
		if (res != "") res = "";
		if (Serial.available() == 0) return;
		static uint16_t speed = 65000;
		if (speed == 65000) {
			Serial.print("Speed checking");
			uint32_t mic = micros();
			for (uint8_t i = 0; i < 100; i++) Serial.print(i < 99 ? "." : "\n");
			speed = ((micros() - mic) / 48); // 34000 : 300 baudrate
		}
		for (ever) {
			if (speed > 50) delayMicros(speed);
			uint8_t decimal = Serial.read();
			if (BETWEEN(decimal, 31, 123)) res += String(char(decimal));
			if (decimal == 255) break;
		}
	}

	void reset(uint8_t pin, uint8_t hour = 1) {
		static uint8_t counter = 0;
		static uint32_t last_mlls = 0;
		const uint32_t limit = 3600000;
		uint32_t cycle_time = (millis() - last_mlls);
		if (cycle_time < limit) return;
		last_mlls += ((cycle_time - limit < 2) ? limit : cycle_time);
		counter++;
		if (counter == hour) {
			delay(100);
			digitalWrite(pin, HIGH);
			counter = 0;
		}
	}

	bool loop(uint32_t &handler, uint32_t mcrs, uint32_t tempo) {
		// Ciklus: mcrs -> tempo | 0 -> 1000 | 45212335 -> 1000
		uint32_t cycle_time = (mcrs - handler);
		// Üzem közben:
		if (cycle_time < tempo) return false;
		// Léptetés: Az aktuális micro-hoz !
		handler += ((cycle_time - tempo < 50) ? tempo : cycle_time);
		return true;
	}

	void pwm(uint32_t &handler, uint32_t mcrs, uint8_t pin, double duty, uint16_t freq = 1000) {
		uint32_t tempo = (1000000 / MINMAX(freq, 1, 2000)), duty_cycle = (tempo * MINMAX(duty, 0, 1)), cycle_time = (mcrs - handler);
		// Léptetés: Az aktuális micro-hoz !
		if (cycle_time >= tempo) handler += ((cycle_time - tempo < 50) ? tempo : cycle_time);
		// Üzem közben:
		else digitalWriteFast(pin, (cycle_time < duty_cycle));
	}

	uint64_t micros64() {
		static uint64_t s64 = 0;
		static uint32_t s32 = 0;
		uint32_t m32 = micros();
		s64 += (m32 - s32);
		s32 = m32;
		return s64;
	}

	void print64(uint64_t n) {
		if (n == 0) Serial.println("0");
		else {
			String t = "";
			uint8_t c = 0;
			while (n) {
				c = (n % 10);
				t = String(c) + t;
				n /= 10;
			}
			Serial.println(t);
		}
	}
};
