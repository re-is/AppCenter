#include "C:/Program Files/Apps/Arduino Pack/pinoutLib.h"

// Fogyasztó Volt ---------//
#define SOURCE 12
#define TARGET 3
//-------------------------//

void setup() {

	pinMode(TINY_D0, OUTPUT);	// mfet
	pinMode(TINY_A2, INPUT);	// main
	pinMode(TINY_A3, INPUT);	// load

	digitalWrite(TINY_D0, 0);
	delay(1);

	uint16_t
		source_volts = (SOURCE * 50),
		target_volts = (TARGET * 50),
		final_target = 0,
		last_millis = 0,
		main_volts = 0,
		load_volts = 0;

	for (ever) {

		main_volts = analogRead(TINY_A2);
		load_volts = analogRead(TINY_A3);

		// Nem lehet kisebb, mint a "Forrás"!
		//if (main_volts < source_volts) main_volts = source_volts;

		// Fade-in:
		if (final_target < target_volts) {
			uint8_t m = millis();
			if (last_millis != m) {
				final_target++;
				last_millis = m;
			}
		}

		// Ha a "Cél" alatt van a "Terhelés", akkor 1:
		uint16_t target = (((source_volts * 100 / main_volts) * final_target) / 100);

		digitalWrite(TINY_D0, (target > load_volts));
	}
}
