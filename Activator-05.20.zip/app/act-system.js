(new ActiveXObject('WScript.Shell')).Run('"C:\\Program Files\\Apps\\Activator\\app\\activator.bat"', 0, false);
