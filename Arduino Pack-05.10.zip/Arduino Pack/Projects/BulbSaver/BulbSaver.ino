#include "C:/Program Files/Apps/Arduino Pack/pinoutLib.h"

// Fogyasztó Volt ---------//
#define SOURCE 12
#define TARGET 12
//-------------------------//

void setup() {

	pinMode(TINY_D0, OUTPUT);	// mfet
	pinMode(TINY_A2, INPUT);	// main
	pinMode(TINY_A3, INPUT);	// load

	digitalWrite(TINY_D0, 0);
	delay(100);

	uint16_t
		source = (SOURCE * 50),
		target = (TARGET * 50),
		final_target = 0,
		load_target = 0,
		last_millis = 0,
		main = 0,
		load = 0;

	if (target > source) target = source;

	for (ever) {

		// Fade-in:
		if (final_target < target) {
			uint8_t m = millis();
			if (last_millis != m) {
				final_target++;
				last_millis = m;
			}
		}

		// Olvasás:
		main = analogReadFast(TINY_A2);
		load = analogReadFast(TINY_A3);

		// 8 voltnál nem lehet kisebb, mert túlcsordul a 16 bit load_target !
		if (main < 400) main = 400;

		// 650 * 50 / 700 * 650 / 50
		load_target = ((((source * 50) / main) * final_target) / 50);

		// Ha a "Terhelés" a "Cél" alatt van, akkor 1:
		digitalWriteFast(TINY_D0, (load < load_target));
	}
}
