#ifndef __IRFRemote_h__

class IRFRemote {

private:

	uint8_t remote_pin = 0, default_state = 0;
	uint16_t separator_mcrs = 0;
	bool set_code = false;

public:

	void init(uint8_t pin, uint8_t mode) {

		// pin init:
		if (remote_pin == 0) {
			pinModeFast(pin, mode);
			set_code = (mode == OUTPUT);
			remote_pin = pin;
		}

		// Jelküldéskor kilépés:
		if (set_code) return;

		// Ez kell, ha a Vin/5V a táp !
		delay(500);

		uint32_t mcrs = micros(), step = mcrs, first_mcrs = mcrs, last_mcrs = 0, noise_counter = 0, state_summary = 0, state_counter = 0;
		bool signal = false;

		while ((mcrs - first_mcrs) < 500000UL) {
			mcrs = micros();

			// Csak 20 mikrononként:
			if (mcrs < step) continue;
			step += 20;

			uint8_t state = digitalReadFast(pin);

			if (state == 0) {
				if (signal) {
					last_mcrs = mcrs;
					signal = false;
				}
			}
			else if (!signal) {
				if ((mcrs - last_mcrs) < 200) noise_counter++;
				signal = true;
			}

			state_summary += state;
			state_counter++;
		}

		state_counter /= 2;	// -> ~ 12500
		default_state = ((noise_counter > 10 or state_summary < state_counter) ? 0 : 1);
		separator_mcrs = (default_state ? 1000 : 550);
		//Serial.println(String(noise_counter) + " > 10 or " + String(state_summary) + " < " + String(state_counter) + ": " + String(default_state));
	}


	//-----------------------------------------------------------------------------------//


	IRFRemote(uint8_t pin = 0, uint8_t mode = 0) {
		if (pin > 0) init(pin, mode);
	}


	//-----------------------------------------------------------------------------------//


	void setCode(uint32_t mcrs, uint32_t &code, uint8_t limit = 1) {
		if (!set_code) return;

		static uint32_t last_code = -1, signal_mcrs = 0, width_mcrs = 0;
		static uint8_t bit_counter = 0, send_counter = 0;
		static bool signal = false;

		// Változáskor reset:
		if (last_code != code) {
			digitalWriteFast(remote_pin, 0);
			signal_mcrs = 0;
			width_mcrs = 500;
			bit_counter = 32;
			send_counter = 0;
			signal = false;
			last_code = code;
		}

		// Továbbengedés, ha van kód:
		if (code == 0) return;

		// Ha a pulse nagyobb, mint a szélesség:
		if (uint32_t(mcrs - signal_mcrs) < width_mcrs) return;
		signal_mcrs = mcrs;

		if (signal) {

			// Az utolsó   width_mcrs:500  és  bit_counter:255 !
			if (bit_counter > 32) {
				// Ha a számláló elérte a limitet:
				if ((++send_counter) == limit) {
					code = 0;
					send_counter = 0;
				}
				// Vagy újrakezdés, mintha 32 lenne:
				else {
					width_mcrs = 10000;
					bit_counter = 31;
				}
			}
			else {
				// Kezdőérték:
				if (bit_counter == 32) width_mcrs = 10000;
				else {
					// Encoding, 32-bit: 31 -> 0
					uint8_t bit = bitRead(last_code, bit_counter);
					width_mcrs = (bit ? 1000 : 400);
				}
				bit_counter--; // 255
			}

			signal = false;
		}
		else {
			width_mcrs = 500;
			signal = true;
		}

		digitalWriteFast(remote_pin, signal);
	}


	//-----------------------------------------------------------------------------------//


	uint32_t getCode(uint32_t mcrs) {
		if (set_code) return 0;

		static bool signal = false;
		static uint32_t signal_mcrs = 0, end_mcrs = 0, code = 0;
		static uint8_t bit_counter = 32;

		uint32_t return_code = 0;

		if (digitalReadFast(remote_pin) == default_state) {
			if (signal) {
				signal_mcrs = mcrs;
				signal = false;
			}
		}
		else if (!signal) {
			uint32_t width_mcrs = (mcrs - signal_mcrs);

			// Start or Reset:
			if (width_mcrs > 3000) {
				if (bit_counter <= 8) return_code = code;
				if (default_state == 0) bit_counter = 32;
				end_mcrs = mcrs;
			}
			else if (end_mcrs) {
				// Reset on RF noise:
				if (width_mcrs < 200) {
					bit_counter = 32;
					code = 0;
					end_mcrs = 0;
				}
				// Decoding:
				else if (width_mcrs < 2000 and bit_counter > 0) {
					if (bit_counter == 32) code = 0;
					bitWrite(code, (--bit_counter), (width_mcrs > separator_mcrs ? 1 : 0));
				}
			}

			signal = true;
		}

		if (end_mcrs and uint32_t(mcrs - end_mcrs) > 120000UL) {
			if (bit_counter <= 8) return_code = code;
			bit_counter = 32;
			code = 0;
			end_mcrs = 0;
		}

		return return_code;
	}


	//-----------------------------------------------------------------------------------//


	uint32_t safetyCode(uint32_t mcrs, bool long_press = false, uint32_t code = 1) {
		if (code == 1) code = getCode(mcrs);

		static bool sent = false;
		static uint32_t end_mcrs = 0, code_mcrs = 0, last_mcrs = 0, last_code = 0, long_return_code = 0, counter = 0;
		uint32_t return_code = 0, runtime_mcrs = (mcrs - last_mcrs);

		// Ha nincs semmi, akkor kilépés, hogy kevesebb legyen a futásidő:
		if (code == 0 and end_mcrs == 0) return 0;

		// Futásidő hozzáadása:
		if (runtime_mcrs > 300) {
			end_mcrs += runtime_mcrs;
			code_mcrs += runtime_mcrs;
		}
		last_mcrs = mcrs;

		// Gomb nyomásakor:
		if (code) {
			end_mcrs = mcrs;
			if (counter < 3) {
				if (last_code != code) {
					counter = 0;
					last_code = code;
				}
				if (counter == 2) {
					if (long_press) {
						// Csak egyszer !
						if (!sent) {
							code_mcrs = mcrs;
							sent = true;
						}
						long_return_code = code;
					}
					else {
						code_mcrs = 0;
						return_code = code;
					}
				}
				counter++;
			}
			// Hosszúnál nullázni kell, hogy a legutóbbi kód érvényesüljön:
			if (long_press and counter == 3) counter = 0;
		}
		// Gomb felengedése után 120ms:
		else if (end_mcrs and uint32_t(mcrs - end_mcrs) > 120000UL) {
			sent = false;
			counter = 0;
			long_return_code = 0;
			last_code = 0;
			code_mcrs = 0;
			end_mcrs = 0;
		}
		// Hosszú nyomáskor:
		else if (code_mcrs and uint32_t(mcrs - code_mcrs) > 400000UL) {
			return_code = long_return_code;
			long_return_code = 0;
			code_mcrs = 0;
		}

		return return_code;
	}

};

#define __IRFRemote_h__ 1
#endif
