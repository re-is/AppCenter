(function(w,d){
	HTMLElement.prototype.result=function(v){this.setAttribute('result',v)};
	w.S=function(n){return d.querySelector(n)};
	w.android||={xhrLoadingError:function(){},lightLimits:function(x,y){}};
	w.pingTime=0;
	w.result=(function(){
		let x=null,t=0;
		return function(z){
			if(x)return;
			let p=new Date().getTime(),u=z.split('-'),id=u[0],v=u[1];
			x=new XMLHttpRequest();
			x.onreadystatechange=function(){
				if(this.readyState==4&&this.status==200){
					pingTime=(new Date().getTime()-p);
					clearTimeout(t);
					new Function(this.responseText)();
					x=null
				}
			};
			x.open('GET',(location.href.match(/http:\/\/\d+\.\d+\.\d+\.\d+/)+'/'+id+(v?'/'+v:'')),true);
			x.send();
			t=setTimeout(function(){x.abort();x=null;android.xhrLoadingError()},2000)
		}
	})();
	d.onclick=function(e){let k=e.target.getAttribute('result');if(k)result(k)}
})(window,document);



(function(){android.lightLimits(" + String(min_lux) + "," + String(max_lux) + ")})();
