(function() {

	var wss = new ActiveXObject('WScript.Shell');
	var fso = new ActiveXObject('Scripting.FileSystemObject');
	var error_file = wss.ExpandEnvironmentStrings('%TEMP%') + '\\arduino-errors.txt';

	wss.Run('cmd.exe /c start "" "C:\\Program Files\\Apps\\Arduino\\arduino-cli.exe" compile "C:\\Program Files\\Apps\\Arduino\\Projects\\GenCom" --fqbn "arduino:avr:nano" --port COM9 --upload --verify 2> "C:\\Users\\Admin\\AppData\\Local\\Temp\\log.txt"');

})();
