#ifndef __IRFRemote_h__
#define __IRFRemote_h__ 1


template <ui8 pin>
class IRFget {

private:

	ui32 signal_mcrs, end_mcrs, code, short_mcrs, last_mcrs, long_mcrs, last_code, long_code;
	ui8 signal_state, bit_counter, started_state, counter;

	enum : ui16 {
		data_IR			= 0,
		state_RF		= 0,
		state_IR		= 1,
		state_IDLE		= 2,
		reset_BITS		= 32,
		noise_PULSE		= 200,
		start_PULSE		= 3000,
		max_PULSE		= 2000,
		threshold_IR	= 1000,
		threshold_RF	= 600
	};

public:




	void init()
	{
		pinModeFast(pin, INPUT);
		bit_counter		= reset_BITS;
		started_state	= state_IDLE;
		signal_state	= state_IDLE;
		signal_mcrs		= 0;
		end_mcrs		= 0;
		code			= 0;
		counter			= 0;
		short_mcrs		= 0;
		last_mcrs		= 0;
		long_mcrs		= 0;
		last_code		= 0;
		long_code		= 0;
	}




	inline ui32 getCode(ui32 mcrs)
	{
		ui8 state = digitalReadFast(pin);
		ui32 return_code = 0;

		if (signal_state != state) {

			ui32 pulse_mcrs = (mcrs - signal_mcrs);


			// IR -------------------------------------------- IR
			if (state == data_IR)
			{
				// Start:
				if (pulse_mcrs > start_PULSE)
				{
					// 1 vagy 2 | IR vagy Alap
					if (started_state != state_RF)
					{
						if (bit_counter <= 8)
							return_code		= code;
						end_mcrs			= mcrs;
						// Infránál ezeket nem szabad, mert nem biztos, hogy ismétli a kódot:
						// code				= 0;
						// bit_counter		= reset_BITS;
						started_state		= state_IR;
					}
				}
				// Decoding:
				else if (bit_counter > 0 and started_state == state_IR and pulse_mcrs < max_PULSE)
				{
					bitWrite(code, (--bit_counter), (pulse_mcrs > threshold_IR));
				}
			}
			// RF -------------------------------------------- RF
			else
			{
				// Reset on RF noise:
				if (pulse_mcrs < noise_PULSE)
				{
					if (started_state != state_IDLE)
					{
						code				= 0;
						end_mcrs			= 0;
						bit_counter			= reset_BITS;
						started_state		= state_IDLE;
					}
				}
				// Start:
				else if (pulse_mcrs > start_PULSE)
				{
					// 0 vagy 2 | RF vagy Alap
					if (started_state != state_IR)
					{
						if (bit_counter <= 8)
							return_code		= code;
						code				= 0;
						end_mcrs			= mcrs;
						bit_counter			= reset_BITS;
						started_state		= state_RF;
					}
				}
				// Decoding:
				else if (bit_counter > 0 and started_state == state_RF and pulse_mcrs < max_PULSE)
				{
					bitWrite(code, (--bit_counter), (pulse_mcrs > threshold_RF));
				}
			}

			signal_mcrs = mcrs;
			signal_state = state;
		}



		// Timeout 120ms: Gomb felengedése után:
		if (end_mcrs and ui32(mcrs - end_mcrs) > 120000)
		{
			if (bit_counter <= 8)
				return_code		= code;
			bit_counter			= reset_BITS;
			started_state		= state_IDLE;
			code				= 0;
			end_mcrs			= 0;
		}

		return return_code;
	}




	inline ui32 safetyCode(ui32 mcrs, bool long_press = false, ui32 code = 1)
	{
		// Ha nincs kód, akkor megadás:
		if (code == 1) code = getCode(mcrs);

		// A futásidőt folyamatosan figyelni kell!
		ui32 return_code = 0, runtime_mcrs = (mcrs - last_mcrs);
		last_mcrs = mcrs;

		// Ha nincs semmi, akkor kilépés, hogy kevesebb legyen a futásidő:
		if (code == 0 and short_mcrs == 0) return 0;

		ui8 limit = (long_press ? 5 : 2);


		// Gomb nyomásakor:
		if (code)
		{
			if (long_press and short_mcrs == 0) long_mcrs = mcrs;

			short_mcrs = mcrs;

			if (counter < limit)
			{
				if (last_code != code)
				{
					counter = 0;
					last_code = code;
				}

				if ((++counter) == limit)
				{
					if (long_press)	long_code = last_code;
					else			return_code = last_code;
				}
			}
		}
		// Ha túl sok a futásidő:
		else if (short_mcrs and runtime_mcrs > noise_PULSE) short_mcrs = mcrs;


		// Timeout 120ms: Gomb felengedése után:
		if (short_mcrs and ui32(mcrs - short_mcrs) > 120000)
		{
			counter		= 0;
			last_code	= 0;
			long_code	= 0;
			long_mcrs	= 0;
			short_mcrs	= 0;
		}

		// Timeout 500ms: Gomb hosszú nyomása közben:
		if (long_mcrs and ui32(mcrs - long_mcrs) > 500000)
		{
			return_code	= long_code;
			long_code	= 0;
			long_mcrs	= 0;
		}


		return return_code;
	}

};






template <ui8 pin>
class IRFset {

private:

	ui32 signal_mcrs, last_code, pulse_mcrs;
	ui8 signal_state, bit_counter, send_counter;

	enum : ui16 {
		reset_BITS		= 32,
		reset_PULSE		= 500,
		pulse_0			= 400,
		pulse_1			= 1400,
		start_PULSE		= 10000
	};

public:



	void init()
	{
		pinModeFast(pin, OUTPUT);
		bit_counter		= reset_BITS;
		pulse_mcrs		= 0;
		signal_mcrs		= 0;
		last_code		= 1;
		signal_state	= 0;
		send_counter	= 0;
	}



	inline void setCode(ui32 mcrs, ui32 &code, ui8 times = 1)
	{
		// Változáskor reset:
		if (last_code != code)
		{
			digitalWriteFast(pin, 0);
			bit_counter		= reset_BITS;
			signal_mcrs		= 0;
			pulse_mcrs		= 0;
			send_counter	= 0;
			signal_state	= 0;
			last_code		= code;
		}

		// Továbbengedés, ha van kód:
		if (code == 0) return;

		// Ha a pulse nagyobb, mint a szélesség:
		if (ui32(mcrs - signal_mcrs) < pulse_mcrs) return;

		signal_mcrs = mcrs;
		signal_state = !signal_state;

		if (signal_state)
		{
			// Kezdőérték:
			if (bit_counter == reset_BITS)
			{
				pulse_mcrs = start_PULSE;
			}
			else
			{
				// Encoding:
				ui8 bit = bitRead(last_code, bit_counter);
				pulse_mcrs = (bit ? pulse_1 : pulse_0);
			}
			bit_counter--;	// 255
		}
		else
		{
			if (bit_counter == 255)
			{
				// Ha a számláló elérte a limitet:
				if ((++send_counter) == times)
				{
					code = 0;
					send_counter = 0;
				}
				// Vagy újrakezdés, mintha 32 lenne:
				else
				{
					bit_counter = reset_BITS;
				}
			}

			pulse_mcrs = reset_PULSE;
		}

		digitalWriteFast(pin, signal_state);
	}

};

#endif
