#include "C:/Program Files/Apps/Arduino Pack/defaultLib.h"

// Fogyasztó Volt ---------//
#define SOURCE 120
#define TARGET 30
//-------------------------//

void setup() {

	pinMode(TINY_D0, OUTPUT);	// mfet
	pinMode(TINY_A2, INPUT);	// main
	pinMode(TINY_A3, INPUT);	// load

	digitalWrite(TINY_D0, 0);
	delay(100);

	ui16
		source = (SOURCE * 5),
		target = (TARGET * 5),
		resolution = (65000 / source),
		final_target = 0,
		load_target = 0,
		last_millis = 0,
		main = 0,
		load = 0;

	if (target > source) target = source;

	while (true) {

		// Fade-in:
		if (final_target < target) {
			ui8 m = millis();
			if (last_millis != m) {
				final_target++;
				last_millis = m;
			}
		}

		// Olvasás:
		main = analogReadFast(TINY_A2);
		load = analogReadFast(TINY_A3);

		// Ha a "Táp" kevesebb mint 6 Volt, vagy kevesebb mint a "Cél", akkor 1:
		if (main < 300 or main < final_target) {
			digitalWriteFast(TINY_D0, 1);
		}
		else {
			// "Cél"			600  *     108     / 700   *     600       /     108
			load_target = ((((source * resolution) / main) * final_target) / resolution);

			// Ha a "Terhelés" a "Cél" alatt van, akkor 1, hogy felhúzza a Célhoz:
			digitalWriteFast(TINY_D0, (load < load_target));
		}
	}
}
