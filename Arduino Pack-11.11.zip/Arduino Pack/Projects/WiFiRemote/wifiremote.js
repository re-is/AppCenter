/*******************************
	WiFiRemote JS library
	2026.08.01, István Reich
*******************************/

if (!window.WiFiRemote) window.WiFiRemote = new function() {
	let loadingTimer = 0;
	const
		ws = new WebSocket(`ws://${window.location.hostname}/wfr`),
		ws_send = () => {
			// Küldés:
			if (ws.readyState === 1) ws.send(JSON.stringify(data.obj));
			// Reset:
			data.obj = {};
		},
		data = {
			obj: {},
			timeout: 0,
			send(key, value) {
				clearTimeout(data.timeout);
				data.obj[key] = value;
				data.timeout = setTimeout(ws_send, 1);
				loadingTimer = setTimeout(() => {
					document.body.innerHTML = '<div style="text-align:center;margin-top:20vh">Connection lost !</div>';
				}, 4000);
			}
		};

	this.toESP = data.send;
	ws.addEventListener('open', () => data.send('client-id', '0'));
	ws.addEventListener('message', (e) => {
		clearTimeout(loadingTimer);
		if (typeof WiFiRemote.fromESP === 'function') WiFiRemote.fromESP(JSON.parse(e.data));
	});

	window.addEventListener('DOMContentLoaded', () => document.body.style.cssText = 'user-select:none;position:absolute;width:100vw;margin:0;');
};







window.addEventListener('click', (e) => {
	const elem = e.target;

	if (elem.className.includes('buttons')) {

		WiFiRemote.toESP(
			e.target.id,
			e.target.getAttribute('state')
		);
	}
});


WiFiRemote.fromESP = (obj) => {
	if (obj['led-grn']) document.querySelector('#led-grn').setAttribute('state', obj['led-grn'] == '1' ? 'on' : 'off');
	if (obj['led-red']) document.querySelector('#led-red').setAttribute('state', obj['led-red'] == '1' ? 'on' : 'off');
};
