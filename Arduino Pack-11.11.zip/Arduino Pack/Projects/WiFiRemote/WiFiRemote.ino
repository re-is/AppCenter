#include "C:/Program Files/Apps/Arduino Pack/defaultLib.h"
#include "C:/Program Files/Apps/Arduino Pack/wifiRemoteLib.h"

WIFIREMOTE_RES("C:/Program Files/Apps/Arduino Pack/Projects/WiFiRemote/", "index.html", "wifiremote.js");

// Saved value's:
ui8
	led_grn_pin = 21,
	led_red_pin = 19,
	saved_grn_value = 0,
	saved_red_value = 0;


void setup() {

	pinMode(led_grn_pin, OUTPUT);
	pinMode(led_red_pin, OUTPUT);
	digitalWrite(led_grn_pin, saved_grn_value);
	digitalWrite(led_red_pin, saved_red_value);

	// Start ----------------------------------->
	Serial.begin(115200);

	// Station mode
	WiFiRemote.connect("TPlink-Home", "tda8560q");

	// AccessPoint mode
	//WiFiRemote.create("ESP32-Router", "tda8560q");



	WiFiRemote.fromJs([](Json obj) {

		if (obj.has("led-grn")) {
			saved_grn_value = obj.get("led-grn") == "off";
		}

		if (obj.has("led-red")) {
			saved_red_value = obj.get("led-red") == "off";
		}

		digitalWrite(led_grn_pin, saved_grn_value);
		digitalWrite(led_red_pin, saved_red_value);

		obj.set("led-grn", saved_grn_value);
		obj.set("led-red", saved_red_value);

		return obj;
	});


	//------------------------------------------>
	while (true) {

		WiFiRemote.refresh();

		if (millis() == 5000) {
			Json json;
			json.set("led-red", 1);
			WiFiRemote.toJs(json);
		}

	}
}
