//-----------------------------------------------------------------//
// Generátor + ventillátor szabályozó és központizár kezelő, 2025
//-----------------------------------------------------------------//

#include "C:/Program Files/Apps/Arduino Pack/defaultLib.h"
#include "C:/Program Files/Apps/Arduino Pack/generaLib.h"
#include "C:/Program Files/Apps/Arduino Pack/irfRemoteLib.h"

IRFget <NANO_D3> remote_D3;
GeneraLib::PWM <NANO_D6> pwm_D6;
GeneraLib::AVG <10> average;
GeneraLib::LOOP <500000> time_loop;

void command(ui8 process)
{
	switch (process)
	{
	case 1:
		digitalWriteFast(NANO_D10, 1);
		delay(100);
		digitalWriteFast(NANO_D10, 0);
		break;
	case 2:
		digitalWriteFast(NANO_D8, 1);
		delay(100);
		digitalWriteFast(NANO_D8, 0);
		break;
	case 3:
		digitalWriteFast(NANO_D10, 1);
		delay(100);
		digitalWriteFast(NANO_D4, 1);
		delay(100);
		digitalWriteFast(NANO_D4, 0);
		delay(100);
		digitalWriteFast(NANO_D10, 0);
		break;
	}
}

void setup()
{
	pinMode(NANO_A0, INPUT);	// Volt
	pinMode(NANO_A7, INPUT);	// Termo
	pinMode(NANO_D2, OUTPUT);	// Reset
	//pinMode(NANO_D3, INPUT);	// Remote
	pinMode(NANO_D4, OUTPUT);	// Csomi	/ fehér
	//pinMode(NANO_D6, OUTPUT);	// Gen		/ kék
	pinMode(NANO_D8, OUTPUT);	// Zárás	/ sárga
	pinMode(NANO_D10, OUTPUT);	// Nyitás	/ zöld
	pinMode(NANO_D12, OUTPUT);	// Relé		/ fekete

	remote_D3.init();
	pwm_D6.init();
	average.init();

	delay(10);

	ui8
		timer			= 0;
	ui16
		volts			= analogReadFast(NANO_A0),
		_13v			= (13 * 34.8),
		celsius_limit	= 88;
	ui32
		microsec		= 0,
		code			= 0;
	bool
		pwm_signal		= (volts > _13v),
		fan_on			= false,
		print			= false;


	celsius_limit *= 8.5;


	if (print)
	{
		UART::init();
		if (pwm_signal) UART::println("PWM bekapcsolva.");
	}


	while (true)
	{
		microsec = micros();

		//-------------------------------------------------------------------------------------------//



		// Fél másodpercenként fut le:
		if (time_loop.run(microsec))
		{

			// Hőfok átlag kiolvasása:
			ui16 celsius = analogReadFast(NANO_A7);
			celsius = average.calc(celsius);
			if (print) { UART::print("Hőfok:\t");UART::print(ui32(celsius / 8.5));UART::println(" °C"); }

			if (!fan_on and volts > _13v and celsius > celsius_limit)
			{
				if (print) UART::println("Relay ON !");
				digitalWriteFast(NANO_D12, 1);
				fan_on = true;
			}

			if (fan_on and (!pwm_signal || celsius < (celsius_limit-3)))
			{
				if (print) UART::println("Relay OFF !");
				digitalWriteFast(NANO_D12, 0);
				fan_on = false;
			}


			// Feszültség kiolvasása:
			volts = analogReadFast(NANO_A0);
			if (print) { UART::print("Fesz:\t");UART::print(ui32(volts / 34.8));UART::println(" V"); }

			if (volts > _13v)
			{
				if (!pwm_signal)
				{
					if (print) UART::println("RESET !");
					delay(100);
					digitalWriteFast(NANO_D2, 1);
					while(1);
				}
				else if (timer < 10) timer = 10;
			}
			else
			{
				if (timer > 0)
				{
					if (print) UART::println("Feszültség 13 V alatt !");
					timer--;
				}
				else if (pwm_signal)
				{
					if (print) UART::println("PWM kikapcsolva.");
					pwm_D6.stop();
					pwm_signal = false;
				}
			}
		}



		//-------------------------------------------------------------------------------------------//



		code = remote_D3.safetyCode(microsec, true);


		// (A1 A2)
		if (code == 1912212992 or code == 2966597120)
		{
			pwm_D6.stop();
			command(1);
			if (print) UART::println("Nyitva");
		}


		// (B1 B2)
		if (code == 1912212736 or code == 2966596864)
		{
			pwm_D6.stop();
			command(2);
			if (print) UART::println("Zárva");
		}


		// Járó motornál PWM indítása:
		if (pwm_signal) pwm_D6.run(microsec, 125, 43);
		// (A1+A2 B1+B2), csak álló motornál !
		else if (code == 1912212480 or code == 2966596608)
		{
			pwm_D6.stop();
			command(3);
			if (print) UART::println("Csomiajtó");
		}
	}
}
