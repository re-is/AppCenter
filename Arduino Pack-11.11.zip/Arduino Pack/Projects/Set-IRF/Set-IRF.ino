#include "C:/Program Files/Apps/Arduino Pack/defaultLib.h"
#include "C:/Program Files/Apps/Arduino Pack/irfRemoteLib.h"

IRFset <NANO_D3> rf;

void setup() {

	rf.init();

	ui32 microsec, code;

	while (true) {

		microsec = micros();

		if (microsec % 5000000 < 50) code = 12345678;

		rf.setCode(microsec, code, 3);
	}
}
