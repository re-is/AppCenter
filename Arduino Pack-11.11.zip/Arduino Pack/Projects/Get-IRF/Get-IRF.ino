#include "C:/Program Files/Apps/Arduino Pack/defaultLib.h"
#include "C:/Program Files/Apps/Arduino Pack/irfRemoteLib.h"

IRFget <NANO_D3> rf;
IRFget <NANO_D5> ir;

void setup() {

	UART::init();

	rf.init();
	ir.init();

	ui32 microsec, codeRF, codeIR;

	while (true) {

		microsec = micros();

		codeRF = rf.getCode(microsec);
		codeIR = ir.getCode(microsec);

		if (codeRF) UART::println(codeRF);
		if (codeIR) UART::println(codeIR);

		/*
		uint32_t code = remoteRF.safetyCode(microsec);

		if (code) Serial.println(code);


		if (code == 4087716608) {
			Serial.println("A");
		}
		if (code == 4087717376) {
			Serial.println("B");
		}
		if (code == 4087715584) {
			Serial.println("C");
		}
		if (code == 4087717120) {
			Serial.println("D");
		}*/
	}
}
