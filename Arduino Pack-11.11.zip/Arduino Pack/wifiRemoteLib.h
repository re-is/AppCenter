#ifndef __WiFiRemote_h__
#define __WiFiRemote_h__ 1

#include <WiFi.h>
#include <ESPmDNS.h>
#include <ESPAsyncWebServer.h>

#define WIFIREMOTE_RES_2(dir, html_file) asm(			\
	".section .rodata\n"								\
	".global wifiremote_html\n"							\
	"wifiremote_html:\n"								\
	".incbin \"" dir html_file "\"\n"					\
	".byte 0\n"											\
	".global wifiremote_js\n"							\
	"wifiremote_js:\n"									\
	".byte 0\n"											\
)

#define WIFIREMOTE_RES_3(dir, html_file, js_file) asm(	\
	".section .rodata\n"								\
	".global wifiremote_html\n"							\
	"wifiremote_html:\n"								\
	".incbin \"" dir html_file "\"\n"					\
	".byte 0\n"											\
	".global wifiremote_js\n"							\
	"wifiremote_js:\n"									\
	".incbin \"" dir js_file "\"\n"						\
	".byte 0\n"											\
)

#define WIFIREMOTE_RES_SELECT(_1, _2, _3, NAME, ...) NAME

#define WIFIREMOTE_RES(...) \
	WIFIREMOTE_RES_SELECT(__VA_ARGS__, WIFIREMOTE_RES_3, WIFIREMOTE_RES_2)(__VA_ARGS__)



AsyncWebServer wifiremote_server(80);
AsyncWebSocket wifiremote_socket("/wfr");

extern const char wifiremote_html[];
extern const char wifiremote_js[];
// Ez kell majd !
//const char wifiremote_js[] PROGMEM = R"js()js";


class Json {
private:
	String _text;

public:

	Json(const char* text = "{}") {
		_text.reserve(200);
		_text = text;
	}

	operator String() const { return _text; }
	const String& toString() const { return _text; }


	// Key is exist ---------------------------->
	bool has(const char* key) {
		// Max 23 karakter
		char search[24];
		snprintf(search, sizeof(search), "\"%s\"", key);

		return (strstr(_text.c_str(), search) != nullptr);
	}


	// GET value ------------------------------->
	String get(const char* key) {
		static char value[24];
		char temp_key[24];

		// key-1 -> "key-1"
		snprintf(temp_key, sizeof(temp_key), "\"%s\"", key);

		// Ha van ilyen kulcs: ["key-1"]:  "value"
		const char* p = strstr(_text.c_str(), temp_key);
		if (!p) return "";

		// Ha van [:]  "value"
		p = strchr(p, ':');
		if (!p) return "";

		p++;

		// :[  ]"value"
		while (*p == ' ') p++;

		// :["]value"
		if (*p != '"') return "";

		p++;

		size_t i = 0;
		// Ha van karakter, ami nem ["] és limiten belül van
		while (*p && *p != '"' && i < sizeof(value) - 1) {
			// "key-1" = "value"
			value[i++] = *p++;
		}

		// Lezárás
		value[i] = '\0';

		return String(value);
	}


	// SET value ------------------------------->
	template<typename T>
	void set(const char* key, T value) {
		setv(key, String(value));
	}
	void set(const char* key, bool value) {
		setv(key, value ? "true" : "false");
	}
	void set(const char* key, const char* value) {
		setv(key, String(value));
	}

	void setv(const char* key, const String& value) {
		char search[24];
		snprintf(search, sizeof(search), "\"%s\"", key);

		const char* p = strstr(_text.c_str(), search);

		// Nincs ilyen kulcs -> hozzáadás
		if (!p) {
			if (_text == "{}") {
				_text = "{\"";
				_text += key;
				_text += "\":\"";
				_text += value;
				_text += "\"}";
			}
			else {
				_text.remove(_text.length() - 1);	// leveszi }

				_text += ",\"";
				_text += key;
				_text += "\":\"";
				_text += value;
				_text += "\"}";						// itt vissza rakja }
			}

			return;
		}

		// Van ilyen kulcs -> érték csere
		p = strchr(p, ':');
		if (!p) return;

		char* start = strchr((char*)p, '"');
		if (!start) return;
		start++;

		char* end = strchr(start, '"');
		if (!end) return;

		size_t pos = start - _text.c_str();

		String result;
		result.reserve(_text.length() + value.length());

		result.concat(_text.c_str(), pos);
		result += value;
		result += end;

		_text = result;
	}
};




class WiFiRemoteClass {
private:

	using MessageCallback = std::function<Json(Json)>;

	MessageCallback messageCallback;

	ui32 reconnect_ms = 0, message_ms = 0;
	bool disconnected = true, station_mode = false;
	char message[200];

	void initServer() {

		wifiremote_socket.onEvent([this](AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type, void *arg, uint8_t *data, size_t len) {
			switch (type) {
				case WS_EVT_CONNECT: {
					Serial.printf("WebSocket client #%u connected from %s\n", client->id(), client->remoteIP().toString().c_str());
					break;
				}
				case WS_EVT_DISCONNECT: {
					Serial.printf("WebSocket client #%u disconnected\n", client->id());
					break;
				}
				case WS_EVT_DATA: {
					AwsFrameInfo *info = (AwsFrameInfo*)arg;
					if (info->opcode == WS_TEXT &&
						info->final &&
						info->index == 0 &&
						info->len == len &&
						len < sizeof(message) &&
						messageCallback
					) {
						memcpy(message, data, len);
						message[len] = '\0';

						// Fogadott Js objektum:
						Json json(message);

						// Összefésülés a WiFiRemote.fromJs értékekkel:
						json = messageCallback(json);

						// Első megnyitáskor:
						if (json.get("client-id") == "0") {
							json.set("client-id", client->id());
							client->text(json.toString());
						}
						// Visszaküldés mindnek:
						else wifiremote_socket.textAll(json.toString());
					}
					break;
				}
			}
		});

		wifiremote_server.addHandler(&wifiremote_socket);

		wifiremote_server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {

			/*----- JS injektálás a </head> elé by GPT:*/
			AsyncResponseStream *response = request->beginResponseStream("text/html");

			const char *headEnd = strstr(wifiremote_html, "</head>");

			if (headEnd) {
				size_t beforeLen = headEnd - wifiremote_html;

				response->write((const uint8_t*)wifiremote_html, beforeLen);
				// <head>
				//	...
				response->print("<script>");
				response->print(FPSTR(wifiremote_js));
				response->print("</script>");
				// </head>
				response->print(headEnd);
			}
			else {
				response->print(wifiremote_html);
			}

			request->send(response);
		});

		wifiremote_server.begin();

		if (MDNS.begin("esp")) MDNS.addService("http", "tcp", 80);
	}


	void checkConnection() {
		wifiremote_socket.cleanupClients();
		// STA mode:
		if (!station_mode) return;
		ui32 ms = millis();
		if (ui32(ms - message_ms) >= 100) {
			// CONNECTION LOST:
			if (WiFi.status() != WL_CONNECTED) {
				if (!disconnected) {
					disconnected = true;
					MDNS.end();
					WiFi.config(INADDR_NONE, INADDR_NONE, INADDR_NONE);
					Serial.println("WiFi connection lost !");
				}
				// Reconnect by 2 seconds interval:
				if (ui32(ms - reconnect_ms) >= 2000) {
					WiFi.reconnect();
					reconnect_ms = ms;
				}
			}
			else if (disconnected) {
				disconnected = false;
				IPAddress gw = WiFi.gatewayIP();
				IPAddress sn(255, 255, 255, 0);
				IPAddress ip = gw;
				ip[3] = 254;
				WiFi.config(ip, gw, sn);
				if (MDNS.begin("esp")) MDNS.addService("http", "tcp", 80);
				Serial.printf("WebServer\n - Host: http://esp.local\n - IP: http://%s\n", ip.toString().c_str());
			}

			message_ms = ms;
		}
	}


public:

	void fromJs(MessageCallback callback) {
		messageCallback = callback;
	}

	void toJs(const Json& json) {
		wifiremote_socket.textAll(json.toString());
	}

	void refresh() {
		checkConnection();
	}


	//-------------------------------------------------------->


	// --- Access Point mode
	// Create Access Point.
	void create(const char *ssid, const char *password) {
		station_mode = false;
		WiFi.mode(WIFI_AP);
		IPAddress ip(192, 168, 155, 254);
		IPAddress sn(255, 255, 255, 0);
		WiFi.softAPConfig(ip, ip, sn);
		WiFi.softAP(ssid, password);
		WiFi.setTxPower(WIFI_POWER_11dBm);
		initServer();
		Serial.printf("WebServer\n - Host: http://esp.local\n - IP: http://%s\n", WiFi.softAPIP().toString().c_str());
	}

	// --- Station mode
	// Connect to Access Point.
	void connect(const char *ssid, const char *password) {
		station_mode = true;
		esp_log_level_set("wifi", ESP_LOG_NONE);
		WiFi.mode(WIFI_STA);
		WiFi.begin(ssid, password);
		initServer();
	}

};

extern WiFiRemoteClass WiFiRemote;

WiFiRemoteClass WiFiRemote;

#endif
