void readSerial(String &t) {
	if (t != "") t = "";
	while (Serial.available()) {
		char c = char(Serial.read());
		if (c == '\n') continue;
		t += String(c);
	}
}

bool microLoop(uint32_t &handler, uint32_t mcrs, uint32_t tempo) {
	// Ciklus: mcrs -> tempo | 0 -> 1000 | 45212335 -> 1000
	uint32_t cycle_time = (mcrs - handler);
	// Üzem közben:
	if (cycle_time < tempo) return false;
	// Léptetés: Az aktuális micro-hoz !
	handler += (cycle_time > (tempo+100) ? cycle_time : tempo);
	return true;
}

void microPWM(uint32_t &handler, uint32_t mcrs, uint8_t pin, double duty, int freq = 1000) {
	uint32_t
		tempo		= (1000000 / MINMAX(freq, 1, 2000)),
		duty_cycle	= (tempo * MINMAX(duty, 0, 1)),
		cycle_time	= (mcrs - handler);
	// Üzem közben:
	if (cycle_time < tempo) {
		digitalWriteFast(pin, (cycle_time < duty_cycle));
	}
	// Léptetés: Az aktuális micro-hoz !
	else handler += (cycle_time > (tempo+100) ? cycle_time : tempo);
}

uint8_t _HOUR_COUNTER = 0;
void microReset(uint32_t mcrs, uint8_t pin, uint8_t hour = 1) {
	if (((mcrs / 1000000) % 3600) == 0) _HOUR_COUNTER++;
	if (_HOUR_COUNTER == hour) {
		delay(100);
		digitalWrite(pin, HIGH);
	}
}

/*
void print64(uint64_t n) {
	String t;
	if (n == 0) t = "0";
	else while (n) {
		uint8_t chr = (n % 10);
		t = String(chr) + t;
		n /= 10;
	}
	Serial.println(t);
}

uint64_t micros64() {
	static uint64_t _m64 = 0;
	static uint32_t _m32 = 0;
	uint32_t m32 = micros();
	_m64 += (m32 - _m32);
	_m32 = m32;
	return _m64;
}*/
