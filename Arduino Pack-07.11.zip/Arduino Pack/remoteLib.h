
String bin_hex(String source) {
	String bin = "", hex = "",
		b[16] = { "0000","0001","0010","0011","0100","0101","0110","0111","1000","1001","1010","1011","1100","1101","1110","1111" },
		h[16] = {    "0",   "1",   "2",   "3",   "4",   "5",   "6",   "7",   "8",   "9",   "A",   "B",   "C",   "D",   "E",   "F" };
	// to Hex:
	if (source.indexOf("bin:") > -1) {
		for (uint8_t i = source.length(); i > 7; i -= 4) {
			bin = source.substring(i-4, i);
			for (uint8_t a = 0; a < 16; a++) {
				if (b[a] == bin) hex = (h[a] + hex);
			}
		}
		return hex;
	}
	// to Bin:
	if (source.indexOf("hex:") > -1) {
		for (uint8_t i = 3; i < source.length(); i++) {
			hex = source[i];
			for (uint8_t a = 0; a < 16; a++) {
				if (h[a] == hex) bin += b[a];
			}
		}
		return bin;
	}
}

//----------------------------------------------------------------------------------------------//

bool getRemoteCode(uint8_t pin, String &code, bool once = false) {

	// Reset !
	if (code != "") code = "";

	// Global vars for this:
	static uint32_t static_mcrs = 0;
	static uint8_t static_state = 2;
	static bool static_once = false;

	// Detect default state:
	if (static_state == 2) {
		int avg_state = 0;
		for (int i = 0; i < 20; i++) {
			delay(10);
			avg_state += int(digitalReadFast(pin));
		}
		static_state = (avg_state < 10 ? 0 : 1);
	}

	// Timer for reset the switch:
	if (static_once and !INSET(micros(), static_mcrs, 100000)) static_once = false;

	// Return on default state:
	if (digitalReadFast(pin) == static_state) return false;

	//--------------------------------------------------------------------------------------->

	// Local vars:
	bool signal = true, started = false, reverse = false;
	uint32_t mcrs = 0, pulse = 0, first_pulse = 0, starter_times[2] = { 2000, 30000 };

	for (ever) {

		// 1.
		static_mcrs = micros();
		// 2.
		if (static_once) break;
		// 3.
		if (mcrs == 0) mcrs = static_mcrs;

		// Default signal:
		if (digitalReadFast(pin) == static_state) {
			if (signal) {
				mcrs = static_mcrs;
				signal = false;
			}
		}
		// Trigger signal for read default pulse time:
		else if (!signal) {
			pulse = (static_mcrs - mcrs);

			// On starter time:
			if (pulse > starter_times[0] and pulse < starter_times[1]) {
				// First starter time:
				if (!started) started = true;
				// On next starter time:
				else {
					if (once) static_once = true;
					break;
				}
			}
			// On binary code:
			else if (started) {
				if (first_pulse == 0) first_pulse = pulse;
				// Alapból egyessel kezdi:
				code += (INSET(pulse, first_pulse, 300) ? "1" : "0");
				// Ha nullával kezdte, akkor fordítva lesz a bináris kód !!!
				if (pulse > (first_pulse + 300)) reverse = true;
			}

			signal = true;
		}

		// Timer for exit loop:
		if ((static_mcrs - mcrs) > starter_times[1]) break;
	}

	// Minimum 12 bit:
	if (code.length() < 12) return false;

	if (reverse) {
		code.replace("1", "2");
		code.replace("0", "1");
		code.replace("2", "0");
	}

	code = bin_hex("bin:" + code);

	return true;
}
