#include "C:\Program Files\Apps\Arduino pack\digitalLib.h"

#define MINMAX(v, n, x) ((v < n) ? n : (v > x) ? x : v)
#define INSET(v, n, x) ((n - x) <= v && (n + x) >= v)
#define ever ;;

#define _D2 2
#define _D3 3
#define _D4 4
#define _D5 5
#define _D6 6
#define _D7 7
#define _D8 8
#define _D9 9
#define _D10 10
#define _D11 11
#define _D12 12
#define _A0 14
#define _A1 15
#define _A2 16
#define _A3 17
#define _A4 18
#define _A5 19
#define _A6 20
#define _A7 21
