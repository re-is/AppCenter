class MicroLib {
private:
public:

	void readSerial(String &res) {
		if (res != "") res = "";
		// Baudrate meghatározása:
		static uint32_t rate = 0;
		if (rate == 0) {
			uint32_t mic = micros();
			Serial.print("Check baudrate");
			for (uint8_t i = 0; i < 100; i++) Serial.print(".");
			Serial.println("");
			rate = ((micros() - mic) / 50);
		}
		// Ha van beírt szöveg:
		if (Serial.available()) {
			uint32_t mcrs = 0, last_mcrs = 0;
			uint8_t avail = 0, last_avail = 0;
			for (ever) {
				mcrs = micros();
				avail = Serial.available();
				if (avail > last_avail) {
					last_mcrs = mcrs;
					last_avail = avail;
				}
				else if (mcrs - last_mcrs > rate) {
					while (Serial.available()) {
						uint8_t decimal = Serial.read();
						if (decimal > 31 and decimal < 123) res += String(char(decimal));
					}
					break;
				}
			}
		}
	}

	bool loop(uint32_t &handler, uint32_t mcrs, uint32_t tempo) {
		// Ciklus: mcrs -> tempo | 0 -> 1000 | 45212335 -> 1000
		uint32_t cycle_time = (mcrs - handler);
		// Üzem közben:
		if (cycle_time < tempo) return false;
		// Léptetés: Az aktuális micro-hoz !
		handler += (((cycle_time - tempo) > tempo) ? cycle_time : tempo);
		return true;
	}

	void pwm(uint32_t &handler, uint32_t mcrs, uint8_t pin, double duty, uint16_t freq = 1000) {
		uint32_t tempo = (1000000 / MINMAX(freq, 1, 2000)), duty_cycle = (tempo * MINMAX(duty, 0, 1)), cycle_time = (mcrs - handler);
		// Léptetés: Az aktuális micro-hoz !
		if (cycle_time >= tempo) handler += (((cycle_time - tempo) > tempo) ? cycle_time : tempo);
		// Üzem közben:
		else digitalWriteFast(pin, (cycle_time < duty_cycle));
	}

	void reset(uint32_t mcrs, uint8_t pin, uint8_t hour = 1) {
		static uint8_t counter = 0;
		static bool rst = false;
		if (mcrs < 3600000000) {
			if (rst) rst = false;
		}
		else if (!rst) {
			counter++;
			if (counter == hour) {
				Serial.println("SETUP");
				digitalWrite(pin, HIGH);
				counter = 0;
			}
			rst = true;
		}
	}

	uint64_t micros64() {
		static uint64_t _m64 = 0;
		static uint32_t _m32 = 0;
		uint32_t m32 = micros();
		_m64 += (m32 - _m32);
		_m32 = m32;
		return _m64;
	}

	void print64(uint64_t n) {
		String t;
		if (n == 0) t = "0";
		else while (n) {
			uint8_t chr = (n % 10);
			t = String(chr) + t;
			n /= 10;
		}
		Serial.println(t);
	}
};
