(function() {

	// Helyi változók:
	var
		kmspico = 'C:\\Program Files\\Apps\\Activator\\app\\kmspico',
		temp = 'C:\\Users\\Admin\\AppData\\Local\\Temp',
		fso = new ActiveXObject('Scripting.FileSystemObject'),
		wss = new ActiveXObject('WScript.Shell'),
		date = new Date(),
		manual = false,
		day = date.getDate(),
		currTime = date.getTime(),
		lastTime = 0,
		year = (date.getFullYear() + '.' + ('0' + (date.getMonth() + 1)).slice(-2) + '.' + date.getDate());


	// Kapcsoló ellenőrzése:
	// Ha van, akkor kézi aktiválás. Ha nincs, akkor automatikus:
	try { manual = (WScript.Arguments(0) !== '') } catch(e) {}


	// Idő lekérése:
	try { lastTime = Number(wss.RegRead('HKCU\\Software\\Apps\\WindowsActivation')) } catch(e) {}


	// Ha kézi vagy ha eltelt 90 nap:
	if (manual || (currTime > (lastTime + (1000 * 60 * 60 * 24 * 90)))) {

		// Jelszavas .rar fájl kibontása:
		wss.Run('"' + kmspico + '\\UnRAR.exe" x -hp"kms" "' + kmspico + '\\KMSpico.rar" "' + temp + '"', 0, true);
		WScript.Sleep(1000);
		// Aktiválás:
		wss.Run('"' + temp + '\\KMSpico\\AutoPico.exe"', 0, true);
		WScript.Sleep(1000);
		// 3mp késleltetés után a kibontott mappa törlése:
		fso.DeleteFolder(temp + '\\KMSpico');
		// Adat fájl készítése:
		var f = fso.CreateTextFile(kmspico + '\\Last Activation.txt', true, false);
		f.WriteLine('Utolsó aktiválás: ' + year);
		f.Close();

		wss.RegWrite('HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run\\MicrosoftActivator', 'wscript.exe "' + kmspico + '\\Activator.js"', 'REG_SZ');
		wss.RegWrite('HKCU\\Software\\Apps\\WindowsActivation', currTime, 'REG_SZ');

	}

})();
