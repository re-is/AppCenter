(new ActiveXObject('WScript.Shell')).Run('"C:\\Program Files\\Apps\\Activator\\app\\activator.bat" manual', 1, false);
