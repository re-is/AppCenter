#ifndef __GeneraLib_h__
#define __GeneraLib_h__ 1

struct GeneraLib {

	void delayMicros(uint32_t n) {
		uint32_t m = micros();
		while (m + n > micros());
	}

	void readSerial(String &res) {
		if (res != "") res = "";
		if (Serial.available() == 0) return;
		static uint16_t speed = 65000;
		if (speed == 65000) {
			Serial.print("Speed checking");
			uint32_t mic = micros();
			for (uint8_t i = 0; i < 100; i++) Serial.print(i < 99 ? "." : "\n");
			speed = ((micros() - mic) / 48); // 34000 : 300 baudrate
		}
		for (ever) {
			if (speed > 50) delayMicros(speed);
			uint8_t decimal = Serial.read();
			if (BETWEEN(decimal, 31, 123)) res += String(char(decimal));
			if (decimal == 255) break;
		}
	}

	void reset(uint8_t pin, uint8_t hour = 1) {
		static uint8_t counter = 0;
		static uint32_t last_mlls = 0;
		uint32_t cycle_time = (millis() - last_mlls), limit = 3600000;
		if (cycle_time < limit) return;
		last_mlls += ((cycle_time - limit < 2) ? limit : cycle_time);
		if (++counter < hour) return;
		digitalWrite(pin, HIGH);
		while(1);
	}



	class LOOP {
	private:
		uint32_t _Mcrs = 0, _Tempo = 0;
	public:

		LOOP(uint32_t ms) {
			_Tempo = (ms * 1000);
		}

		bool run(uint32_t mcrs) {
			// Ciklus:
			uint32_t cycle_time = (mcrs - _Mcrs);
			// Üzem közben:
			if (cycle_time < _Tempo) return false;
			// Léptetés: Az aktuális micro-hoz !
			_Mcrs += ((cycle_time - _Tempo < 50) ? _Tempo : cycle_time);
			return true;
		}
	};



	class PWM {
	private:
		uint8_t _Pin = 0;
		uint32_t _Mcrs = 0;
	public:

		PWM(uint8_t pin) {
			pinModeFast(pin, OUTPUT);
			_Pin = pin;
		}

		void run(uint32_t mcrs, uint16_t freq, double duty) {
			uint32_t
				cycle_time = (mcrs - _Mcrs),
				tempo = (1000000 / MINMAX(freq, 1, 2000)),
				duty_time = (tempo * MINMAX(duty, 0.0, 1.0));

			// Üzem közben:
			if (cycle_time < tempo) fastWrite(_Pin, (cycle_time < duty_time));
			// Léptetés: Az aktuális micro-hoz !
			else _Mcrs += ((cycle_time - tempo < 50) ? tempo : cycle_time);
		}

		void stop() {
			fastWrite(_Pin, 0);
		}
	};
};

#endif
